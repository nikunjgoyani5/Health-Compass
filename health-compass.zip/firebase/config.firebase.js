import admin from "firebase-admin";

admin.initializeApp({
  credential: admin.credential.cert({
    "type": "service_account",
    "project_id": "health-compass-60829",
    "private_key_id": "4b2adca896e33ab22c50ab96e2e0e0be86fa47ee",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7k2pvvdH4l5qK\nBBDQZouYWY09WeE2DDKejwrFWGWVa8EczK1GU8HEMM9EEZaNV7g49KqyieD5/x9y\np6e5ySbfX39Yh/8iAx6vS5baZUANQTdaqEABG44D3AGUePVIhiBcKhKAEiTQSmtM\nuUrSbjIzzCIX6RBee3UVQJ9J8XCWBSR6mXOdRoJLudY/8jsFAady3KCElZTBQvX3\nq8I8kb6vU+hz0CU8TCQOXYP1zvK2BvBfekPmGkeyCGl/5D6ck2ygBVUF1KmG0/3F\nFg9nVSQHpZH1tLzziCmhsOYEUbkEiCNYW3gC3kGszDPQdTWPrVUbf382LsxxXkT+\ndfdbbfSLAgMBAAECggEAAi2XCc8hdgqEn9+mNlVKf61ih3jYtaD0oYS1sk7xdwe2\nSVhTFsL4OAf9ECRIJEIFgJvOs54IP77npZQuzWh5jBR2zRdfLgztOUneaZDNapn8\nQ5A6lgi04HSYjBnPd1UfYRKX/ma3iLekgVKRfNoMuS9AohhxuTcjx+hlMR2dmhBW\nFusfA6afKatRNvm3MGhmOhqcrTacGl+FQe8AEGg+5Ma+/o5/l/QV+bo8QdzfQKNn\ncrIRGu2QN5+yPRxkykWwQfU6HN20bNuneY0w+ZCahsgroFJlrjcoP6GVGP8/ff7c\nK5lSZcI+C6krvAASR+sJ4gJ9oiMwWc16rhC6UBhjUQKBgQD6DrPJXuXBGCYmgMw2\nqwlS7k9JAIiUP8grma9ioOz2h3FKhz2HnhuD1v0sVLHM9di0jAVeH56xPI4eTbCN\nn5mI81OV32xy+xvhRxe6dIQb9z0lcKmLWWY/5orxYyztDiJzvvmLxN72+WbkJirR\n8yOh7qpaxSQjJsy7WaGOs/RLEwKBgQDACJaiPyxWzSZlTc4pUFpYYqFDY/8aag7u\nNYf64zFLrjrUp8gNfKhob9IM6mfKFA9BguJLXqWWu3pXCPLMr3F4JUx3dzRPQACp\nX9Rw86GRhZOun/KiwzpQZ3EQWw5uBm0H6vZGtN4N2FOve0KOrJPb3PrwbLpvGNas\ncjuOY/WnqQKBgQCxbtNF1S+EN4WClqvRMsX38Z+Stm0zfJqlzXR0sKnUOME72ADi\nBV+Sym91EFfljqEJY72/TwKE0uopOIlJxPDmC3rJAvNqFyJuVMrShDDlwybBNVMo\nzPPP7d+zbuMHBpuNs/pQog5wAwJua2LA/RzQn5CDvhVpV/O4EN6harGyvwKBgET1\nUJJmuRdaiAUs0XGIh0jh8iLvD7Z+i2oDExeG6jbRFBM1ROOC9j66mOVGb4rjdS8D\nPxvtmuzr2dzTO81A2zBXxIPJ7KDgzNwFq5X8BvLo0sWMbmcAUDp7SuCisiXUbObA\n+zscy/iQzExhqN7vHhF/4yTfBnvKoZw/UR+qyZYxAoGAfRuuWEwzVddgnK7IDgKc\nBOD32EoM6EFq36RmpbjQ21WyKNvPNTgelMDa4LCAnSNfPewdHn23DXPD7MDNP6hG\nxCzIUtN8x6l7O75vMWZcJmiI2+PsjsPRsAhAOpCsAV1lnQC3SLpI6jEjfUM1Roeh\nsP8kJzSysIwcvHDPKfQHWdQ=\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-fbsvc@health-compass-60829.iam.gserviceaccount.com",
    "client_id": "114720961920568763029",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40health-compass-60829.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  }),
});

export default admin;
