import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import UserModel from "../models/user.model.js";

const updatePrivacySetting = async (req, res) => {
  try {
    const { enableDataSharing, analyticsConsent } = req.body;
    const userId = req.user._id;

    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      {
        $set: {
          "privacySettings.enableDataSharing": enableDataSharing,
          "privacySettings.analyticsConsent": analyticsConsent,
        },
      },
      { new: true, runValidators: true, projection: { privacySettings: 1 } }
    );

    if (!updatedUser) {
      return apiResponse({
        res,
        status: false,
        message: "User not found",
        statusCode: StatusCodes.NOT_FOUND,
      });
    }

    return apiResponse({
      res,
      status: true,
      message: "Privacy setting updated successfully",
      data: updatedUser.privacySettings,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    console.log("Error while updating privacy setting", error);
    return apiResponse({
      res,
      status: false,
      message: "Error while updating privacy setting",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

const getPrivacySetting = async (req, res) => {
  try {
    const userId = req.user._id;

    const user = await UserModel.findById(userId).select(
      "privacySettings"
    );

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User not found",
        statusCode: StatusCodes.NOT_FOUND,
      });
    }

    return apiResponse({
      res,
      status: true,
      message: "Privacy setting fetched successfully",
      data: user,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    console.log("Error while fetching privacy setting", error);
    return apiResponse({
      res,
      status: false,
      message: "Error while fetching privacy setting",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

export default {
  updatePrivacySetting,
  getPrivacySetting,
};
