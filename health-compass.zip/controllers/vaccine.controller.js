import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import VaccineModel from "../models/vaccine.model.js";
import helper from "../helper/common.helper.js";
import enumConfig from "../config/enum.config.js";
import XLSX from "xlsx";
import mongoose from "mongoose";
import fs from "fs";

const cleanString = (str) => (typeof str === "string" ? str.trim() : str);

// --- create vaccine detail ---
const createVaccine = async (req, res) => {
  try {
    const { vaccineName, provider, description } = req.body;

    const findVaccine = await VaccineModel.findOne({ vaccineName, provider });

    if (findVaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "This vaccine is already exist.",
      });
    }

    const newVaccine = {
      vaccineName,
      provider,
      description,
      createdBy: req.user._id,
      createdByAdmin: req.user.role?.includes(enumConfig.userRoleEnum.ADMIN)
        ? true
        : false,
    };

    const result = await VaccineModel.create(newVaccine);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: result,
      message: "Vaccine schedule successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

// Without separate admin and user key
const getVaccine = async (req, res) => {
  const { search = "" } = req.query;
  try {
    const pagination = helper.paginationFun(req.query);
    const searchRegex = new RegExp(search, "i");

    const currentUserId = req.user._id;

    const searchCondition = search
      ? {
          $or: [
            { vaccineName: { $regex: searchRegex } },
            { provider: { $regex: searchRegex } },
          ],
        }
      : {};

    const ownerCondition = {
      $or: [{ createdBy: currentUserId }, { createdByAdmin: true }],
    };

    const combinedFilter = {
      $and: [searchCondition, ownerCondition],
    };

    const totalItems = await VaccineModel.countDocuments(combinedFilter);

    const result = await VaccineModel.find(combinedFilter)
      .populate("createdBy", "fullName email profileImage role")
      .skip(pagination.skip)
      .limit(pagination.limit)
      .sort({ createdByAdmin: -1 });

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems,
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      pagination: paginationData,
      data: result,
      message: "Vaccine fetched successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

// --- update vaccine schedule ---
const updateVaccine = async (req, res) => {
  try {
    const { vaccineId } = req.params;
    const updateFields = req.body;

    const vaccine = await VaccineModel.findById(vaccineId);
    if (!vaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine not found.",
      });
    }

    const isAdmin = req.user.role.includes(enumConfig.userRoleEnum.ADMIN);
    const isCreator = vaccine.createdBy?.toString() === req.user._id.toString();

    // Authorization Check
    if (!isAdmin && !isCreator) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "You are not authorized to update this vaccine.",
      });
    }

    if (updateFields.vaccineName && updateFields.provider) {
      const existingVaccine = await VaccineModel.findOne({
        _id: { $ne: vaccineId },
        vaccineName: updateFields.vaccineName,
        provider: updateFields.provider,
      });

      if (existingVaccine) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.BAD_REQUEST,
          message: "This vaccine already exists.",
        });
      }
    }

    const result = await VaccineModel.findByIdAndUpdate(
      vaccineId,
      { $set: updateFields },
      { new: true }
    );

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: result,
      message: "Vaccine details updated successfully.",
    });
  } catch (error) {
    console.log(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// --- delete vaccine ---
const deleteVaccine = async (req, res) => {
  try {
    const { id } = req.params;
    const vaccine = await VaccineModel.findById(id);

    if (!vaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine not found.",
        data: null,
      });
    }

    const isAdmin = req.user.role?.includes(enumConfig.userRoleEnum.ADMIN);

    // Admin can delete vaccines created by admin
    if (vaccine.createdByAdmin && isAdmin) {
      await VaccineModel.findByIdAndDelete(id);
    }
    // User can delete only their own vaccines
    else if (
      !vaccine.createdByAdmin &&
      vaccine.createdBy.toString() === req.user._id.toString()
    ) {
      await VaccineModel.findByIdAndDelete(id);
    }
    // Not allowed
    else {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.UNAUTHORIZED,
        message: "You are not authorized to delete this vaccine.",
        data: null,
      });
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: null,
      message: "Vaccine deleted successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

// --- bulk import vaccine ---
const bulkImportVaccines = async (req, res) => {
  if (!req.file) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.BAD_REQUEST,
      message: "No file uploaded.",
    });
  }
  const isAdmin = req.user.role?.includes(enumConfig.userRoleEnum.ADMIN);

  try {
    const fileBuffer = req.file.buffer;
    const workbook = XLSX.read(fileBuffer, { type: "buffer" });

    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const vaccines = XLSX.utils.sheet_to_json(sheet);

    const seenInFile = new Set();
    const uniqueVaccines = [];
    const duplicateEntries = [];
    const invalidEntries = [];

    // Step 1: In-file duplication check
    for (let item of vaccines) {
      const key = `${item.vaccineName?.trim().toLowerCase()}|${item.provider
        ?.trim()
        .toLowerCase()}`;
      if (seenInFile.has(key)) {
        duplicateEntries.push({ ...item, reason: "Duplicate in file" });
        continue;
      }
      seenInFile.add(key);
      uniqueVaccines.push(item);
    }

    // Step 2: DB-level duplication check
    const queryOr = uniqueVaccines.map((item) => ({
      createdBy: req.user.id,
      vaccineName: item.vaccineName,
      provider: item.provider,
    }));

    const existingInDB = await VaccineModel.find({ $or: queryOr });

    const finalVaccinesToInsert = [];

    for (let item of uniqueVaccines) {
      const exists = existingInDB.find(
        (dbItem) =>
          dbItem.vaccineName === item.vaccineName &&
          dbItem.provider === item.provider &&
          dbItem.createdBy.toString() === req.user.id
      );

      if (exists) {
        duplicateEntries.push({ ...item, reason: "Already exists in DB" });
      } else {
        finalVaccinesToInsert.push({
          createdBy: req.user.id,
          vaccineName: cleanString(item.vaccineName),
          provider: cleanString(item.provider),
          description: cleanString(item.description) || "",
          createdByAdmin: isAdmin,
        });
      }
    }

    // Step 3: Insert final validated entries
    if (finalVaccinesToInsert.length > 0) {
      await VaccineModel.insertMany(finalVaccinesToInsert);
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      message: `${finalVaccinesToInsert.length} vaccines imported. ${duplicateEntries.length} duplicates skipped. ${invalidEntries.length} invalid entries skipped.`,
      body: {
        imported: finalVaccinesToInsert.length,
        duplicates: duplicateEntries,
        invalids: invalidEntries,
      },
    });
  } catch (error) {
    console.error("Bulk Import Vaccine Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Failed to import vaccines.",
    });
  }
};

const bulkDeleteVaccines = async (req, res) => {
  try {
    const { ids } = req.body;

    // Step 1: Validate Input
    if (!Array.isArray(ids) || ids.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "IDs array is required and should not be empty.",
      });
    }

    // Step 2: Separate valid and invalid ObjectIds
    const validIds = [];
    const invalidIds = [];

    ids.forEach((id) => {
      if (mongoose.Types.ObjectId.isValid(id)) {
        validIds.push(id);
      } else {
        invalidIds.push(id);
      }
    });

    // Step 3: Find existing vaccines
    let foundVaccines = [];
    if (validIds.length > 0) {
      foundVaccines = await VaccineModel.find({ _id: { $in: validIds } });
    }

    const foundIds = foundVaccines.map((v) => v._id.toString());
    const idsNotFound = validIds.filter((id) => !foundIds.includes(id));

    // Step 4: Filter only admin-created vaccines
    const deletableVaccines = foundVaccines.filter(
      (v) => v.createdByAdmin === true
    );
    const deletableIds = deletableVaccines.map((v) => v._id.toString());

    const notDeletableIds = foundVaccines
      .filter((v) => v.createdByAdmin !== true)
      .map((v) => v._id.toString());

    // Step 5: Delete only those created by admin
    let deletedCount = 0;
    if (deletableIds.length > 0) {
      const deleteResult = await VaccineModel.deleteMany({
        _id: { $in: deletableIds },
      });
      deletedCount = deleteResult.deletedCount;
    }

    // Step 6: Return detailed response
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message:
        `${deletedCount} vaccine(s) deleted successfully. ` +
        `${
          invalidIds.length > 0
            ? invalidIds.length + " invalid ID(s) provided. "
            : ""
        }` +
        `${
          idsNotFound.length > 0
            ? idsNotFound.length + " ID(s) not found in the database. "
            : ""
        }` +
        `${
          notDeletableIds.length > 0
            ? notDeletableIds.length +
              " vaccine(s) not created by admin and skipped."
            : ""
        }`,
      body: {
        deletedCount,
        deletedIds: deletableIds,
        idsNotFound,
        notDeletableIds,
        invalidIds,
      },
    });
  } catch (error) {
    console.error("Bulk Delete Vaccine Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Failed to delete vaccines.",
      error: error.message,
    });
  }
};

const importVaccinesFromJSON = async (req, res) => {
  try {
    let vaccines = [];

    if (req.file) {
      const data = fs.readFileSync(req.file.path, "utf8");
      vaccines = JSON.parse(data);
      fs.unlinkSync(req.file.path); // remove file after reading
    } else if (Array.isArray(req.body)) {
      vaccines = req.body;
    } else if (req.body.data) {
      vaccines = JSON.parse(req.body.data);
    }

    if (!Array.isArray(vaccines) || vaccines.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message: "Uploaded JSON must be a non-empty array.",
      });
    }

    const userId = req.user?._id;
    const isAdmin =
      Array.isArray(req.user?.role) && req.user.role.includes("admin");

    const newVaccines = [];

    for (const v of vaccines) {
      const vaccineName = cleanString(v.vaccineName);

      if (!vaccineName) continue;

      const alreadyExists = await VaccineModel.findOne({
        vaccineName: { $regex: new RegExp(`^${vaccineName}$`, "i") },
        createdBy: userId,
      });

      if (alreadyExists) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.CONFLICT,
          data: null,
          message: `Vaccine '${vaccineName}' already exists for this user.`,
        });
      }

      newVaccines.push({
        vaccineName,
        provider: cleanString(v.provider),
        description: cleanString(v.description),
        createdBy: userId,
        createdByAdmin: isAdmin,
      });
    }

    if (newVaccines.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message: "No new vaccines to import.",
      });
    }

    const result = await VaccineModel.insertMany(newVaccines);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: result,
      message: "Vaccines imported successfully.",
    });
  } catch (error) {
    console.error("Vaccine Import Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

export default {
  createVaccine,
  getVaccine,
  updateVaccine,
  deleteVaccine,
  bulkImportVaccines,
  bulkDeleteVaccines,
  importVaccinesFromJSON,
};
