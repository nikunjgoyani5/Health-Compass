import { apiResponse } from "../helper/api-response.helper.js";
import { StatusCodes } from "http-status-codes";
import Supplement from "../models/supplement.model.js";
import XLSX from "xlsx";
import { verifyMedicineDetailsWithOpenAI } from "../utils/gpt.utils.js";
import enumConfig from "../config/enum.config.js";
import mongoose from "mongoose";
import commonHelper from "../helper/common.helper.js";
import fs from "fs";

// Create a new supplement
const createSupplement = async (req, res) => {
  try {
    const isAdmin = req.user.role.includes(enumConfig.userRoleEnum.ADMIN);

    const {
      medicineName,
      dosage,
      description,
      takenForSymptoms,
      associatedRisks,
      price,
      quantity,
      singlePack,
      mfgDate,
      expDate,
    } = req.body;

    // 1. Check already existing
    const existing = await Supplement.findOne({
      medicineName,
      dosage,
      userId: req.user.id,
    });

    if (existing) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "This supplement already exists.",
        data: null,
      });
    }

    // --- Note : Uncomment this block to enable OpenAI verification ---

    // const verification = await verifyMedicineDetailsWithOpenAI({
    //   medicineName,
    //   dosage,
    //   description,
    //   takenForSymptoms,
    //   associatedRisks,
    // });

    // if (!verification.isValid) {
    //   return apiResponse({
    //     res,
    //     status: false,
    //     statusCode: StatusCodes.BAD_REQUEST,
    //     message: verification.message,
    //     data: null,
    //   });
    // }

    const newSupplement = new Supplement({
      userId: req.user.id,
      medicineName,
      dosage,
      description,
      takenForSymptoms,
      associatedRisks,
      price,
      quantity,
      singlePack,
      mfgDate,
      expDate,
      createdByAdmin: isAdmin,
    });

    await newSupplement.save();

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      message: "Supplement added successfully.",
      data: newSupplement,
    });
  } catch (error) {
    console.error("Create Supplement Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      data: null,
    });
  }
};

// UPDATE
const updateSupplement = async (req, res) => {
  try {
    const supplement = await Supplement.findById(req.params.id);
    if (!supplement) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Supplement not found.",
      });
    }

    const isAdmin = req.user.role.includes("admin");
    const isCreator = supplement.userId.toString() === req.user.id.toString();

    if (!isAdmin && !isCreator) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "You are not authorized to update this supplement.",
      });
    }

    // --- Optional: OpenAI Verification Block ---
    // const verification = await verifyMedicineDetailsWithOpenAI({
    //   medicineName: req.body.medicineName,
    //   dosage: req.body.dosage,
    //   description: req.body.description || "",
    //   takenForSymptoms: req.body.takenForSymptoms || "",
    //   associatedRisks: req.body.associatedRisks || ""
    // });

    // if (!verification.isValid) {
    //   return apiResponse({
    //     res,
    //     status: false,
    //     statusCode: StatusCodes.BAD_REQUEST,
    //     message:
    //       "Supplement details seem invalid. Please correct the information.",
    //   });
    // }

    const updated = await Supplement.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Supplement updated.",
      data: updated,
    });
  } catch (err) {
    console.error(err);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Server error",
    });
  }
};

// DELETE
const deleteSupplement = async (req, res) => {
  try {
    const supplement = await Supplement.findById(req.params.id);

    if (!supplement) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Supplement not found.",
        data: null,
      });
    }

    const isAdmin = req.user.role?.includes(enumConfig.userRoleEnum.ADMIN);

    // Admin can delete only admin-created supplements
    if (supplement.createdByAdmin && isAdmin) {
      await Supplement.findByIdAndDelete(req.params.id);
    }

    // Users can delete only their own supplements
    else if (
      !supplement.createdByAdmin &&
      supplement.userId.toString() === req.user.id.toString()
    ) {
      await Supplement.findByIdAndDelete(req.params.id);
    }

    // Not allowed to delete
    else {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "You are not authorized to delete this supplement.",
        data: null,
      });
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Supplement deleted successfully.",
      data: null,
    });
  } catch (err) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Server error",
      data: null,
    });
  }
};

// Get a single supplement by ID
const getSingleSupplement = async (req, res) => {
  try {
    const { id } = req.params;

    const supplement = await Supplement.findOne({
      _id: id,
      userId: req.user.id,
    });

    if (!supplement) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Supplement not found.",
      });
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Supplement fetched successfully.",
      data: supplement,
    });
  } catch (error) {
    console.error("Get Single Supplement Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Server error.",
    });
  }
};

// Get all supplements with search & pagination
// With separate admin and user key
// const getAllSupplements = async (req, res) => {
//   try {
//     const { search = "", page = 1, limit = 10 } = req.query;
//     const userId = req.user.id;
//     const isAdmin = req.user.role.includes(enumConfig.userRoleEnum.ADMIN);
//     const parsedLimit = parseInt(limit);
//     const skip = (parseInt(page) - 1) * parsedLimit;
//     const regex = new RegExp(search, "i");

//     if (isAdmin) {
//       // fetch admin-created supplements
//       const filter = {
//         createdByAdmin: true,
//         ...(search
//           ? {
//               $or: [
//                 { medicineName: regex },
//                 { description: regex },
//                 { takenForSymptoms: regex },
//               ],
//             }
//           : {}),
//       };

//       const totalItems = await Supplement.countDocuments(filter);
//       const supplements = await Supplement.find(filter)
//         .sort({ createdAt: -1 })
//         .skip(skip)
//         .limit(parsedLimit);

//       return apiResponse({
//         res,
//         status: true,
//         statusCode: StatusCodes.OK,
//         message: "Supplements fetched successfully.",
//         data: {
//           page: Number(page),
//           limit: parsedLimit,
//           totalItems,
//           totalPages: Math.ceil(totalItems / parsedLimit),
//           supplements,
//         },
//       });
//     } else {
//       // Fetch both admin-created and user-created separately
//       const adminFilter = {
//         createdByAdmin: true,
//         ...(search
//           ? {
//               $or: [
//                 { medicineName: regex },
//                 { description: regex },
//                 { takenForSymptoms: regex },
//               ],
//             }
//           : {}),
//       };

//       const userFilter = {
//         userId,
//         ...(search
//           ? {
//               $or: [
//                 { medicineName: regex },
//                 { description: regex },
//                 { takenForSymptoms: regex },
//               ],
//             }
//           : {}),
//       };

//       const [adminSupplements, userSupplements, totalAdmin, totalUser] = await Promise.all([
//         Supplement.find(adminFilter).sort({ createdAt: -1 }),
//         Supplement.find(userFilter).sort({ createdAt: -1 }).skip(skip).limit(parsedLimit),
//         Supplement.countDocuments(adminFilter),
//         Supplement.countDocuments(userFilter),
//       ]);

//       return apiResponse({
//         res,
//         status: true,
//         statusCode: StatusCodes.OK,
//         message: "Supplements fetched successfully.",
//         data: {
//           page: Number(page),
//           limit: parsedLimit,
//           totalItems: totalUser,
//           totalPages: Math.ceil(totalUser / parsedLimit),
//           adminSupplements,
//           userSupplements,
//         },
//       });
//     }
//   } catch (error) {
//     return apiResponse({
//       res,
//       status: false,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       message: "Server error.",
//     });
//   }
// };

// Without separate admin and user key
const getAllSupplements = async (req, res) => {
  try {
    const { search = "", page = 1, limit = 10 } = req.query;
    const userId = req.user.id;
    const isAdmin = req.user.role.includes(enumConfig.userRoleEnum.ADMIN);
    const parsedLimit = parseInt(limit);
    const skip = (parseInt(page) - 1) * parsedLimit;
    const regex = new RegExp(search, "i");

    const searchFilter = search
      ? {
          $or: [
            { medicineName: regex },
            { description: regex },
            { takenForSymptoms: regex },
          ],
        }
      : {};

    let finalFilter;

    if (isAdmin) {
      // Admin: fetch only admin-created
      finalFilter = {
        createdByAdmin: true,
        ...searchFilter,
      };
    } else {
      // User: fetch both user-created and admin-created
      finalFilter = {
        $or: [{ createdByAdmin: true }, { userId: userId }],
        ...searchFilter,
      };
    }

    const totalItems = await Supplement.countDocuments(finalFilter);
    const supplements = await Supplement.find(finalFilter)
      .sort({ createdByAdmin: -1 })
      .skip(skip)
      .limit(parsedLimit);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Supplements fetched successfully.",
      data: {
        page: Number(page),
        limit: parsedLimit,
        totalItems,
        totalPages: Math.ceil(totalItems / parsedLimit),
        supplements,
      },
    });
  } catch (error) {
    console.error("Get All Supplements Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Server error.",
    });
  }
};

// Bulk import supplements
const cleanString = (str) => (typeof str === "string" ? str.trim() : str);
const bulkImportSupplements = async (req, res) => {
  if (!req.file) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.BAD_REQUEST,
      message: "No file uploaded.",
    });
  }

  const isAdmin = req.user.role.includes(enumConfig.userRoleEnum.ADMIN);

  try {
    const fileBuffer = req.file.buffer;
    const workbook = XLSX.read(fileBuffer, { type: "buffer" });

    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const supplements = XLSX.utils.sheet_to_json(sheet);

    const seenInFile = new Set();
    const uniqueSupplements = [];
    const duplicateEntries = [];
    const invalidEntries = [];

    // Step 1: In-file duplication check
    for (let item of supplements) {
      const key = `${item.medicineName?.trim().toLowerCase()}|${item.dosage
        ?.trim()
        .toLowerCase()}`;
      if (seenInFile.has(key)) {
        duplicateEntries.push({ ...item, reason: "Duplicate in file" });
        continue;
      }
      seenInFile.add(key);
      uniqueSupplements.push(item);
    }

    // Step 2: DB-level duplication check
    const queryOr = uniqueSupplements.map((item) => ({
      userId: req.user.id,
      medicineName: item.medicineName,
      dosage: item.dosage,
    }));

    const existingInDB = await Supplement.find({ $or: queryOr });

    const finalSupplementsToInsert = [];

    for (let item of uniqueSupplements) {
      const exists = existingInDB.find(
        (dbItem) =>
          dbItem.medicineName === item.medicineName &&
          dbItem.dosage === item.dosage &&
          dbItem.userId.toString() === req.user.id
      );

      if (exists) {
        duplicateEntries.push({ ...item, reason: "Already exists in DB" });
      } else {
        // --- Note : Uncomment this block to enable OpenAI verification ---
        // ⭐ Step 3: Verify with OpenAI

        // const verification = await verifyMedicineDetailsWithOpenAI({
        //   medicineName: item.medicineName,
        //   dosage: item.dosage,
        //   description: item.description || "",
        //   takenForSymptoms: item.takenForSymptoms || "",
        //   associatedRisks: item.associatedRisks || "",
        // });

        // if (!verification.isValid) {
        //   invalidEntries.push({
        //     ...item,
        //     reason: "Invalid details according to OpenAI",
        //   });
        //   continue;
        // }

        // If valid, add to final insert list
        finalSupplementsToInsert.push({
          userId: req.user.id,
          medicineName: cleanString(item.medicineName),
          dosage: cleanString(item.dosage),
          description: cleanString(item.description) || "",
          takenForSymptoms: cleanString(item.takenForSymptoms) || "",
          associatedRisks: cleanString(item.associatedRisks) || "",
          price: item.price || 0,
          quantity: item.quantity || 0,
          singlePack: cleanString(item.singlePack) || 0,
          mfgDate: item.mfgDate ? new Date(item.mfgDate) : null,
          expDate: item.expDate ? new Date(item.expDate) : null,
          createdByAdmin: isAdmin,
        });
      }
    }

    // Step 4: Insert final validated entries
    if (finalSupplementsToInsert.length > 0) {
      await Supplement.insertMany(finalSupplementsToInsert);
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      message: `${finalSupplementsToInsert.length} supplements imported. ${duplicateEntries.length} duplicates skipped. ${invalidEntries.length} invalid entries skipped.`,
      body: {
        imported: finalSupplementsToInsert.length,
        duplicates: duplicateEntries,
        invalids: invalidEntries,
      },
    });
  } catch (error) {
    console.error("Bulk Import Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Failed to import supplements.",
    });
  }
};

const bulkDeleteSupplements = async (req, res) => {
  try {
    const { ids } = req.body;

    // Step 1: Validate Input
    if (!Array.isArray(ids) || ids.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "IDs array is required and should not be empty.",
      });
    }

    // Step 2: Separate valid and invalid ObjectIds
    const validIds = [];
    const invalidIds = [];

    ids.forEach((id) => {
      if (mongoose.Types.ObjectId.isValid(id)) {
        validIds.push(id);
      } else {
        invalidIds.push(id);
      }
    });

    // Step 3: Find existing supplements (only with valid IDs)
    let foundSupplements = [];
    if (validIds.length > 0) {
      foundSupplements = await Supplement.find({ _id: { $in: validIds } });
    }

    const foundIds = foundSupplements.map((s) => s._id.toString());
    const idsNotFound = validIds.filter((id) => !foundIds.includes(id));

    // Step 4: Filter admin-created supplements for deletion
    const deletableSupplements = foundSupplements.filter(
      (s) => s.createdByAdmin === true
    );
    const deletableIds = deletableSupplements.map((s) => s._id.toString());

    const notDeletableIds = foundSupplements
      .filter((s) => s.createdByAdmin !== true)
      .map((s) => s._id.toString());

    // Step 5: Delete only admin-created supplements
    let deletedCount = 0;
    if (deletableIds.length > 0) {
      const deleteResult = await Supplement.deleteMany({
        _id: { $in: deletableIds },
      });
      deletedCount = deleteResult.deletedCount;
    }

    // Step 6: Return detailed response
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message:
        `${deletedCount} supplement(s) deleted successfully. ` +
        `${
          invalidIds.length > 0 ? invalidIds.length + " invalid ID(s). " : ""
        }` +
        `${
          idsNotFound.length > 0
            ? idsNotFound.length + " ID(s) not found. "
            : ""
        }` +
        `${
          notDeletableIds.length > 0
            ? notDeletableIds.length +
              " supplement(s) not created by admin and skipped."
            : ""
        }`,
      body: {
        deletedCount,
        deletedIds: deletableIds,
        idsNotFound,
        notDeletableIds,
        invalidIds,
      },
    });
  } catch (error) {
    console.error("Bulk Delete Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Failed to delete supplements.",
      error: error.message,
    });
  }
};

// Fetch suppliment stock status for login users
const getStockStatus = async (req, res) => {
  try {
    const supplements = await Supplement.find({ userId: req.user.id }).sort({
      createdAt: -1,
    });

    const result = supplements.map((item) => {
      let stockStatus = "In Stock";

      if (item.quantity >= 10) {
        stockStatus = "In Stock";
      } else if (item.quantity > 0 && item.quantity < 6) {
        stockStatus = "Running Low";
      } else if (item.quantity == 0) {
        stockStatus = "Out of Stock";
      }

      return {
        _id: item._id,
        medicineName: item.medicineName,
        dosage: item.dosage,
        quantity: item.quantity,
        unit: item.unit, // if you store units like mg, mcg
        stockStatus,
      };
    });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      message: "Supplement stock fetched successfully.",
      status: true,
      data: result,
    });
  } catch (error) {
    console.error(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Add quantity
const addQuantity = async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity } = req.body;

    const findSuppliment = await Supplement.findOne({
      _id: id,
      userId: req.user.id,
    });
    if (!findSuppliment) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Medicine not found",
        status: false,
        data: null,
      });
    }

    findSuppliment.quantity += quantity;
    await findSuppliment.save();

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Quantity added successfully",
      data: {
        supplimentId: findSuppliment._id,
        quantity: findSuppliment.quantity,
      },
    });
  } catch (error) {
    console.error("Add Quantity Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      data: null,
    });
  }
};

const importSupplimentFromJSON = async (req, res) => {
  try {
    let supplements = [];

    if (req.file) {
      const data = fs.readFileSync(req.file.path, "utf8");
      supplements = JSON.parse(data);
      fs.unlinkSync(req.file.path);
    } else if (Array.isArray(req.body)) {
      supplements = req.body;
    } else if (req.body.data) {
      supplements = JSON.parse(req.body.data);
    }

    if (!Array.isArray(supplements) || supplements.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message: "Uploaded JSON must be a non-empty array.",
      });
    }

    const userId = req.user?._id;
    const isAdmin =
      Array.isArray(req.user?.role) && req.user.role.includes("admin");

    const newSupplements = [];

    for (const item of supplements) {
      const medicineName = cleanString(item.medicineName);

      if (!medicineName) continue;

      const alreadyExists = await Supplement.findOne({
        medicineName: { $regex: new RegExp(`^${medicineName}$`, "i") },
        userId,
      });

      if (alreadyExists) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.CONFLICT,
          data: null,
          message: `Supplement '${medicineName}' already exists for this user.`,
        });
      }

      newSupplements.push({
        userId,
        medicineName,
        dosage: cleanString(item.dosage),
        description: cleanString(item.description),
        takenForSymptoms: cleanString(item.takenForSymptoms),
        associatedRisks: cleanString(item.associatedRisks),
        price: Number(item.price),
        quantity: Number(item.quantity),
        singlePack: cleanString(item.singlePack),
        mfgDate: new Date(item.mfgDate),
        expDate: new Date(item.expDate),
        createdByAdmin: isAdmin,
      });
    }

    const result = await Supplement.insertMany(newSupplements);
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      message: `${result.length} supplements imported successfully.`,
      data: result,
    });
  } catch (error) {
    console.error("Import Supplement from JSON Error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Failed to import supplements from JSON.",
      data: null,
    });
  }
};

export default {
  addQuantity,
  createSupplement,
  updateSupplement,
  deleteSupplement,
  getSingleSupplement,
  getAllSupplements,
  getStockStatus,
  bulkImportSupplements,
  bulkDeleteSupplements,
  importSupplimentFromJSON,
};
