import { apiResponse } from "../helper/api-response.helper.js";
import { StatusCodes } from "http-status-codes";
import activityModel from "../models/userActivity.model.js";
import helper from "../helper/common.helper.js";

const getActivityByUser = async (req, res) => {
    try {
        const userId = req.user.id;
        const { page = 1, limit = 10, category, activityType, status } = req.query;

        const userActivityDoc = await activityModel.findOne({ userId });

        if (!userActivityDoc) {
            return apiResponse({
                res,
                status: true,
                message: "No activity found for this user.",
                statusCode: StatusCodes.OK,
                data: [],
            });
        }

        const activities = [];

        for (const [cat, logs] of userActivityDoc.activities.entries()) {
            if (category && cat !== category) continue;

            logs.forEach(log => {
                let include = true;

                if (activityType && log.activityType !== activityType) include = false;
                if (typeof status !== "undefined" && String(log.status) !== String(status)) include = false;

                if (include) {
                    activities.push({
                        category: cat,
                        ...log.toObject()
                    });
                }
            });
        }

        // Sort by latest first
        activities.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        // Apply pagination
        const { limit: pageLimit, skip } = helper.paginationFun({ page, limit });
        const paginated = activities.slice(skip, skip + pageLimit);
        const pagination = helper.paginationDetails({ page, totalItems: activities.length, limit });

        return apiResponse({
            res,
            status: true,
            message: "User activity retrieved successfully.",
            statusCode: StatusCodes.OK,
            data: {
                ...pagination,
                lastLogin: userActivityDoc.lastLogin,
                activity: paginated
            }
        });

    } catch (error) {
        console.error("Error while fetching user activity:", error);
        return apiResponse({
            res,
            status: false,
            statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
            data: null,
            message: "Internal server error.",
        });
    }
};

export default {
    getActivityByUser
};