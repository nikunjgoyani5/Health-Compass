import CaregiverNote from "../models/caregiverNotes.model.js";
import UserModel from "../models/user.model.js";
import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import helper from "../helper/common.helper.js";
import mongoose from "mongoose";

const addCaregiverNote = async (req, res) => {
  try {
    const caregiverId = req.user.id;
    const { userId, title, note } = req.body;

    const caregiver = await UserModel.findById(caregiverId)
      .select("iCareFor")
      .lean();

    const isCaregiver = caregiver?.iCareFor?.some(
      (id) => String(id) === String(userId)
    );

    if (!isCaregiver) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "You are not a caregiver for this user.",
      });
    }

    const newNote = await CaregiverNote.create({
      caregiver: caregiverId,
      user: userId,
      title,
      note,
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      message: "Caregiver note added successfully.",
      data: newNote,
    });
  } catch (error) {
    console.error("Error adding caregiver note:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// const getCaregiverNotesForMe = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { caregiverId, date, page = 1, limit = 10 } = req.query;

//     if (caregiverId)
//       console.log("📌 Specific Caregiver ID Requested:", caregiverId);
//     if (date) console.log("📅 Date Filter Requested:", date);

//     const user = await UserModel.findById(userId).select("myCaregivers").lean();
//     if (!user) {
//       return apiResponse({
//         res,
//         status: false,
//         statusCode: StatusCodes.NOT_FOUND,
//         message: "User not found.",
//       });
//     }

//     let filter = {
//       user: new mongoose.Types.ObjectId(userId),
//     };

//     if (caregiverId) {
//       const isMyCaregiver = user.myCaregivers.some(
//         (id) => String(id) === String(caregiverId)
//       );
//       if (!isMyCaregiver) {
//         return apiResponse({
//           res,
//           status: false,
//           statusCode: StatusCodes.FORBIDDEN,
//           message: "This caregiver is not authorized for your data.",
//         });
//       }
//       filter.caregiver = new mongoose.Types.ObjectId(caregiverId);
//     } else {
//       filter.caregiver = {
//         $in: user.myCaregivers.map((id) => new mongoose.Types.ObjectId(id)),
//       };
//     }

//     if (date) {
//       const [year, month, day] = date.split("/").map((val) => parseInt(val));
//       const start = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
//       const end = new Date(Date.UTC(year, month - 1, day, 23, 59, 59));
//       filter.createdAt = { $gte: start, $lte: end };
//     }

//     console.log("🧾 Final Query Filter:", filter);

//     const skip = (parseInt(page) - 1) * parseInt(limit);
//     const notes = await CaregiverNote.find(filter)
//       .populate("caregiver", "fullName email profileImage")
//       .sort({ createdAt: -1 })
//       .skip(skip)
//       .limit(parseInt(limit));

//     const totalCount = await CaregiverNote.countDocuments(filter);

//     return apiResponse({
//       res,
//       status: true,
//       statusCode: StatusCodes.OK,
//       message: "Caregiver notes fetched successfully.",
//       data: notes,
//       pagination: {
//         total: totalCount,
//         page: parseInt(page),
//         limit: parseInt(limit),
//         totalPages: Math.ceil(totalCount / limit),
//       },
//     });
//   } catch (error) {
//     console.error("❌ Error fetching caregiver notes:", error);
//     return apiResponse({
//       res,
//       status: false,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       message: "Internal server error.",
//     });
//   }
// };

const getCaregiverNotesForMe = async (req, res) => {
  try {
    const userId = req.user.id;
    const { caregiverId, date } = req.query;

    if (caregiverId)
      console.log("📌 Specific Caregiver ID Requested:", caregiverId);
    if (date) console.log("📅 Date Filter Requested:", date);

    const user = await UserModel.findById(userId).select("myCaregivers").lean();
    if (!user) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "User not found.",
      });
    }

    let filter = { user: new mongoose.Types.ObjectId(userId) };

    if (caregiverId) {
      const isMyCaregiver = user.myCaregivers.some(
        (id) => String(id) === String(caregiverId)
      );
      if (!isMyCaregiver) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.FORBIDDEN,
          message: "This caregiver is not authorized for your data.",
        });
      }
      filter.caregiver = new mongoose.Types.ObjectId(caregiverId);
    } else {
      filter.caregiver = {
        $in: user.myCaregivers.map((id) => new mongoose.Types.ObjectId(id)),
      };
    }

    if (date) {
      const [year, month, day] = date.split("/").map(Number);
      const start = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
      const end = new Date(Date.UTC(year, month - 1, day, 23, 59, 59));
      filter.createdAt = { $gte: start, $lte: end };
    }

    const pagination = helper.paginationFun(req.query);

    const notes = await CaregiverNote.find(filter)
      .populate("caregiver", "fullName email profileImage")
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit);

    const totalCount = await CaregiverNote.countDocuments(filter);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: totalCount,
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Caregiver notes fetched successfully.",
      data: notes,
      pagination: paginationData,
    });
  } catch (error) {
    console.error("❌ Error fetching caregiver notes:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// const getCaregiverNotesISent = async (req, res) => {
//   try {
//     const caregiverId = req.user.id;
//     const { date, page = 1, limit = 10, userId } = req.query;

//     console.log("🩺 Logged-in Caregiver ID:", caregiverId);
//     if (date) console.log("📅 Date Filter Requested:", date);
//     if (userId) console.log("🎯 Filtering by specific userId:", userId);

//     let filter = {
//       caregiver: new mongoose.Types.ObjectId(caregiverId),
//     };

//     if (userId) {
//       filter.user = new mongoose.Types.ObjectId(userId);
//     }

//     if (date) {
//       const [year, month, day] = date.split("/").map(Number);
//       const start = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
//       const end = new Date(Date.UTC(year, month - 1, day, 23, 59, 59));
//       filter.createdAt = { $gte: start, $lte: end };
//     }

//     console.log("🔍 Final Query Filter (as caregiver):", filter);

//     const skip = (parseInt(page) - 1) * parseInt(limit);

//     const notes = await CaregiverNote.find(filter)
//       .populate("user", "fullName email profileImage")
//       .sort({ createdAt: -1 })
//       .skip(skip)
//       .limit(parseInt(limit))
//       .lean();

//     const totalCount = await CaregiverNote.countDocuments(filter);

//     const caregiverInfo = await UserModel.findById(caregiverId)
//       .select("fullName email profileImage")
//       .lean();

//     const enrichedNotes = notes.map(
//       ({ caregiver, ...noteWithoutCaregiver }) => ({
//         ...noteWithoutCaregiver,
//         you: caregiverInfo,
//       })
//     );

//     return apiResponse({
//       res,
//       status: true,
//       statusCode: StatusCodes.OK,
//       message: "Notes you sent as a caregiver fetched successfully.",
//       data: enrichedNotes,
//       pagination: {
//         total: totalCount,
//         page: parseInt(page),
//         limit: parseInt(limit),
//         totalPages: Math.ceil(totalCount / limit),
//       },
//     });
//   } catch (error) {
//     console.error("❌ Error fetching sent notes:", error);
//     return apiResponse({
//       res,
//       status: false,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       message: "Internal server error.",
//     });
//   }
// };

const getCaregiverNotesISent = async (req, res) => {
  try {
    const caregiverId = req.user.id;
    const { date, userId } = req.query;

    console.log("🩺 Logged-in Caregiver ID:", caregiverId);
    if (date) console.log("📅 Date Filter Requested:", date);
    if (userId) console.log("🎯 Filtering by specific userId:", userId);

    let filter = { caregiver: new mongoose.Types.ObjectId(caregiverId) };

    if (userId) {
      filter.user = new mongoose.Types.ObjectId(userId);
    }

    if (date) {
      const [year, month, day] = date.split("/").map(Number);
      const start = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
      const end = new Date(Date.UTC(year, month - 1, day, 23, 59, 59));
      filter.createdAt = { $gte: start, $lte: end };
    }

    const pagination = helper.paginationFun(req.query);

    const notes = await CaregiverNote.find(filter)
      .populate("user", "fullName email profileImage")
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit)
      .lean();

    const totalCount = await CaregiverNote.countDocuments(filter);

    const caregiverInfo = await UserModel.findById(caregiverId)
      .select("fullName email profileImage")
      .lean();

    const enrichedNotes = notes.map(
      ({ caregiver, ...noteWithoutCaregiver }) => ({
        ...noteWithoutCaregiver,
        you: caregiverInfo,
      })
    );

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: totalCount,
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Notes you sent as a caregiver fetched successfully.",
      data: enrichedNotes,
      pagination: paginationData,
    });
  } catch (error) {
    console.error("❌ Error fetching sent notes:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

export default {
  addCaregiverNote,
  getCaregiverNotesForMe,
  getCaregiverNotesISent,
};
