import HealthScoreModel from "../models/healthScore.model.js";
import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";

const addHealthScore = async (req, res) => {
  try {
    const { score } = req.body;
    const userId = req.user.id;

    const payload = {
      userId: userId,
      score,
    };

    const healthScore = await HealthScoreModel.create(payload);

    return apiResponse({
      res,
      status: true,
      message: "Health score added successfully",
      data: healthScore,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    console.log("Error while adding health score", error);
    return apiResponse({
      res,
      status: false,
      message: "Error while adding health score",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

const getHealthScore = async (req, res) => {
  try {
    const userId = req.user.id;

    const scores = await HealthScoreModel.find({ userId }).sort({
      createdAt: -1,
    });

    return apiResponse({
      res,
      status: true,
      message: "Health scores retrieved successfully",
      data: scores,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Error while retrieving health scores",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

export default {
  addHealthScore,
  getHealthScore,
};
