import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import QuizModel from "../models/quiz.model.js";
import ResultModel from "../models/result.model.js";
import enumConfig from "../config/enum.config.js";
import QuestionModel from "../models/question.model.js";
import helper from "../helper/common.helper.js";

const createQuiz = async (req, res) => {
  try {
    const data = req.body;
    data.createdBy = req.user._id;

    const findTitle = await QuizModel.findOne({ title: data.title });
    if (findTitle) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message: "This title is already exist.",
      });
    }

    const createQuiz = await QuizModel.create(data);
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: createQuiz,
      message: "Quiz created successfully.",
    });
  } catch (error) {
    console.log(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

const getQuizForAdmin = async (req, res) => {
  try {
    const pagination = helper.paginationFun(req.query);

    const result = await QuizModel.find({ createdBy: req.user.id })
      .populate("createdBy", "email fullName profileImage role")
      .skip(pagination.skip)
      .limit(pagination.limit)
      .sort({ createdAt: -1 });

    let count = await QuizModel.countDocuments({ createdBy: req.user.id });
    let paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: count,
    });
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      pagination: paginationData,
      data: result,
      message: "Quiz fetch successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

const getUserQuizzes = async (req, res) => {
  try {
    const userId = req.user._id;
    const pagination = helper.paginationFun(req.query);

    const quizzes = await QuizModel.find()
      .skip(pagination.skip)
      .limit(pagination.limit)
      .sort({ createdAt: -1 });

    const resultList = await Promise.all(
      quizzes.map(async (quiz) => {
        const result = await ResultModel.findOne({
          quiz: quiz._id,
          attemptBy: userId,
        }).sort({ createdAt: -1 });

        let status = "Not Started";
        let percentage = 0;
        let timeTaken = 0;

        if (result) {
          if (
            result.progressStatus ===
              enumConfig.progressStatusEnums.IN_PROGRESS ||
            result.resultStatus === enumConfig.resultStatusEnums.PENDING
          ) {
            status = "Active";
            timeTaken = Math.floor(
              (Date.now() - new Date(result.createdAt)) / 1000
            );
          } else if (
            result.progressStatus === enumConfig.progressStatusEnums.COMPLETED
          ) {
            status = "Completed";
            percentage = result.percentage;
            timeTaken = result.timeTaken;
          } else if (
            result.progressStatus === enumConfig.progressStatusEnums.TIMEOUT
          ) {
            status = "Restart";
            percentage = 0;
            timeTaken = 0;
          }
        }

        return {
          _id: quiz._id,
          title: quiz.title,
          totalQuestions: quiz.totalQuestions,
          timeLimit: quiz.timeLimit,
          status,
          percentage,
          timeTaken,
        };
      })
    );

    let count = await QuizModel.countDocuments(resultList);
    let paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: count,
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Quiz status fetched successfully",
      pagination: paginationData,
      data: resultList,
    });
  } catch (error) {
    console.error("getUserQuizzes error:", error);
    return apiResponse({
      res,
      status: false,
      message: "Something went wrong",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

const updateQuiz = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;
    const find = await QuizModel.findById(id);
    if (!find) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        data: null,
        message: "Quiz not found.",
      });
    }

    const isStarted = await ResultModel.find({
      quiz: id,
      progressStatus: enumConfig.progressStatusEnums.IN_PROGRESS,
    });

    if (isStarted.length > 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message:
          "Quiz cannot be updated because it has already been started by users.",
      });
    }

    const result = await QuizModel.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true }
    );

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: result,
      message: "Quiz updated successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

const deleteQuiz = async (req, res) => {
  try {
    const { id } = req.params;
    const find = await QuizModel.findById(id);
    if (!find) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        data: null,
        message: "Quiz not found.",
      });
    }

    const isStarted = await ResultModel.find({
      quiz: id,
      progressStatus: enumConfig.progressStatusEnums.IN_PROGRESS,
    });

    if (isStarted.length > 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
        message:
          "Quiz cannot be updated because it has already been started by users.",
      });
    }

    await QuizModel.findByIdAndDelete(id);
    await QuestionModel.deleteMany({ quiz: id, createdBy: req.user.id });
    await ResultModel.deleteMany({ quiz: id });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: null,
      message: "Quiz deleted successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

export default {
  createQuiz,
  getUserQuizzes,
  getQuizForAdmin,
  updateQuiz,
  deleteQuiz,
};
