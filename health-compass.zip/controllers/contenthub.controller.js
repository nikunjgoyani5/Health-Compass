import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import ContentHubModel from "../models/contenthub.model.js";
import fileUploadService from "../services/file.upload.service.js";
import enumConfig from "../config/enum.config.js";
// import helper from "../helper/common.helper.js";
import UserModel from "../models/user.model.js";

// --- create content hub with different types ---
const createContentHub = async (req, res) => {
  try {
    const data = req.body;
    data.createdBy = req.user._id;
    const files = req.files || [];

    if (data.doctorId) {
      const doctor = await UserModel.findOne({
        _id: data.doctorId,
        role: { $in: [enumConfig.userRoleEnum.DOCTOR] },
      });
      if (!doctor) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.NOT_FOUND,
          message: "Doctor not found.",
        });
      }
    }

    // 1. Upload main image (image)
    const imageFile = files.find((file) => file.fieldname === "image");
    data.image = imageFile
      ? await fileUploadService.uploadFile({
          buffer: imageFile.buffer,
          mimetype: imageFile.mimetype,
        })
      : null;

    // 2. Upload main video
    const mainVideoFile = files.find((file) => file.fieldname === "video");
    data.video = mainVideoFile
      ? await fileUploadService.uploadFile({
          buffer: mainVideoFile.buffer,
          mimetype: mainVideoFile.mimetype,
        })
      : null;

    const result = await ContentHubModel.create(data);

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      status: true,
      data: result,
      message: "Content hub created successfully.",
    });
  } catch (error) {
    console.error(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      data: null,
      message: "Internal server error",
    });
  }
};

// --- get content hub by type ---
const getContent = async (req, res) => {
  try {
    const filter = {};
    const { type, id } = req.query;

    if (type) filter.type = type;

    // const pagination = helper.paginationFun(req.query);

    let current = null;
    let list = [];
    let count = 0;

    const isSpecialType = type === "health_tips" || type === "featured_videos";

    if (isSpecialType && id) {
      // Get the current content
      current = await ContentHubModel.findOne({ _id: id, ...filter }).populate(
        "doctorId",
        "fullName email qualifications profileImage"
      );

      // Get all other content except the current one
      list = await ContentHubModel.find({
        ...filter,
        _id: { $ne: id },
      })
        .populate("doctorId", "fullName email qualifications profileImage")
        .sort({ createdAt: -1 });

      return apiResponse({
        res,
        status: true,
        statusCode: StatusCodes.OK,
        message: "Content fetched successfully.",
        body: {
          current: current || {},
          list: list || [],
        },
      });
    }

    const data = await ContentHubModel.find(filter)
      .populate("doctorId", "fullName email qualifications profileImage")
      .sort({ createdAt: -1 });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Content fetched successfully.",
      body: data,
    });
  } catch (error) {
    console.error("getContent error:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// --- update content hub and add files and update single file ---
const updateContentHub = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;
    const files = req.files || [];

    const findContent = await ContentHubModel.findById(id);
    if (!findContent) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Content not found.",
        data: null,
      });
    }

    if (data.doctorId) {
      const doctor = await UserModel.findOne({
        _id: data.doctorId,
        role: { $in: [enumConfig.userRoleEnum.DOCTOR] },
      });
      if (!doctor) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.NOT_FOUND,
          message: "Doctor not found.",
        });
      }
    }

    // ---------- Handle Image Upload ----------
    const imageFile = files.find((file) => file.fieldname === "image");
    if (imageFile) {
      if (findContent.image) {
        await fileUploadService.deleteFile({ url: findContent.image });
      }
      data.image = await fileUploadService.uploadFile({
        buffer: imageFile.buffer,
        mimetype: imageFile.mimetype,
      });
    }

    // ---------- Handle Featured Videos ----------
    if (findContent.type === enumConfig.contentHubTypeEnums.FEATURED_VIDEOS) {
      const videoFile = files.find((file) => file.fieldname === "video");
      if (videoFile) {
        if (findContent.video) {
          await fileUploadService.deleteFile({ url: findContent.video });
        }
        data.video = await fileUploadService.uploadFile({
          buffer: videoFile.buffer,
          mimetype: videoFile.mimetype,
        });
      }
    }

    // ---------- Handle Health QnA ----------
    else if (findContent.type === enumConfig.contentHubTypeEnums.HEALTH_QNA) {
      try {
        if (typeof data.qna === "string") data.qna = JSON.parse(data.qna);
      } catch (err) {
        console.error("Invalid QnA JSON:", err);
        data.qna = [];
      }

      if (Array.isArray(data.qna)) {
        data.qna = [...(findContent.qna || []), ...data.qna];
      } else {
        data.qna = findContent.qna || [];
      }
    }

    // ---------- Save Updated Content ----------
    const result = await ContentHubModel.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true }
    );

    return apiResponse({
      res,
      status: true,
      message: "Content updated successfully.",
      statusCode: StatusCodes.OK,
      data: result,
    });
  } catch (error) {
    console.error(error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      data: null,
    });
  }
};

// --- delete record ---
const deleteRecord = async (req, res) => {
  try {
    const { id } = req.params;

    const findContent = await ContentHubModel.findById(id);
    if (!findContent) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Content not found.",
        data: null,
      });
    }

    // Delete main image if exists
    if (findContent.image) {
      await fileUploadService.deleteFile({ url: findContent.image });
    }

    // Delete video if exists
    if (findContent.video) {
      await fileUploadService.deleteFile({ url: findContent.video });
    }

    // Finally delete the document
    await ContentHubModel.findByIdAndDelete(id);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Content and associated files deleted successfully.",
      data: null,
    });
  } catch (error) {
    console.error(error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      data: null,
    });
  }
};

export default {
  createContentHub,
  getContent,
  updateContentHub,
  deleteRecord,
};
