import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import FeedbackModel from "../models/feedback.model.js";
import helper from "../helper/common.helper.js";
import moment from "moment";

const createFeedback = async (req, res) => {
  try {
    const data = req.body;
    data.createdBy = req.user._id;

    const result = await FeedbackModel.create(data);
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: result,
      message:
        "Your feedback has been submitted successfully. Thank you for your contribution.",
    });
  } catch (error) {
    console.log(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

const getFeedbacks = async (req, res) => {
  try {
    const filter = {};
    const { tag, fullName, fromDate, toDate } = req.query;

    if (tag) {
      const tagArray = Array.isArray(tag) ? tag : tag.split(",");
      filter.tag = { $in: tagArray };
    }

    if (fromDate || toDate) {
      filter.createdAt = {};

      if (fromDate) {
        const from = new Date(fromDate);
        if (isNaN(from.getTime())) {
          throw new Error("Invalid fromDate. Must be a valid UTC date string.");
        }
        filter.createdAt.$gte = from;
      }

      if (toDate) {
        const to = new Date(toDate);
        if (isNaN(to.getTime())) {
          throw new Error("Invalid toDate. Must be a valid UTC date string.");
        }
        filter.createdAt.$lte = to;
      }
    }

    const pagination = helper.paginationFun(req.query);

    let fetchFeedbacks = await FeedbackModel.find(filter)
      .populate("createdBy", "fullName email profileImage")
      .skip(pagination.skip)
      .limit(pagination.limit)
      .sort({ createdAt: -1 });

    if (fullName) {
      const lowerFullName = fullName.toLowerCase();
      fetchFeedbacks = fetchFeedbacks.filter((fb) =>
        fb.createdBy?.fullName?.toLowerCase().includes(lowerFullName)
      );
    }

    const count = await FeedbackModel.countDocuments(filter);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: count,
    });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Feedback fetched successfully",
      pagination: paginationData,
      data: fetchFeedbacks,
    });
  } catch (error) {
    console.log(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

const deleteFeedback = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await FeedbackModel.findByIdAndDelete(id);
    if (!result) {
      return apiResponse({
        res,
        statusCode: StatusCodes.NOT_FOUND,
        status: false,
        message: "Feedback not found.",
      });
    }
    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Feedback deleted successfully",
      data: null,
    });
  } catch (error) {
    console.log(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

export default { createFeedback, getFeedbacks, deleteFeedback };
