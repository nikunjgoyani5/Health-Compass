import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import userServices from "../services/user.service.js";
import helper from "../helper/common.helper.js";
import UserModel from "../models/user.model.js";
import MedicineSchedule from "../models/medicine.schedual.model.js";
import VaccineSchedule from "../models/vaccine.schedule.model.js";
import VaccineModel from "../models/vaccine.model.js";
import DoctorAvailability from "../models/availability.model.js";
import enums from "../config/enum.config.js";
import Telemedicine from "../models/telemedicine.model.js";
import mongoose from "mongoose";
import MedicineScheduleModel from "../models/medicine.schedual.model.js";
import enumConfig from "../config/enum.config.js";

// ---- Get All User Profile -----
const getAllUserProfile = async (req, res) => {
  try {
    const { role, isBlocked, id, search, page = 1, limit = 10 } = req.query;

    const query = { is_deleted: false };

    // Always exclude ADMIN role
    query.role = { $ne: enums.userRoleEnum.ADMIN };

    // If specific role is requested and it's not ADMIN, apply it
    if (role && role !== enums.userRoleEnum.ADMIN) {
      query.role = { $eq: role };
    }

    if (isBlocked !== undefined) {
      if (isBlocked === "true") query.isBlocked = true;
      else if (isBlocked === "false") query.isBlocked = false;
    }

    if (id) query._id = id;

    if (search) {
      const searchRegex = new RegExp(search, "i");
      query.$or = [
        { fullName: { $regex: searchRegex } },
        { email: { $regex: searchRegex } },
        { phoneNumber: { $regex: searchRegex } },
        { specialization: { $regex: searchRegex } },
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [users, totalItems] = await Promise.all([
      UserModel.find(query)
        .skip(skip)
        .limit(parseInt(limit))
        .sort({ createdAt: -1 }),
      UserModel.countDocuments(query),
    ]);

    const filteredUsers = users.map((user) => {
      const { password, otp, otpExpiresAt, ...rest } = user.toObject();
      return rest;
    });

    return apiResponse({
      res,
      status: true,
      message: "Users fetched successfully.",
      statusCode: StatusCodes.OK,
      data: filteredUsers,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        totalItems,
        totalPages: Math.ceil(totalItems / limit),
      },
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch users.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

// ---- Block And Unblock User Profile -----
const blockAndUnblockUserProfile = async (req, res) => {
  try {
    const { id } = req.params;
    const { isBlocked } = req.body;
    const adminId = req.user.id;

    const user = await userServices.findOne({ _id: id, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User not found.",
        statusCode: StatusCodes.NOT_FOUND,
      });
    }

    // Update the user's block status
    await userServices.updateOne(
      { _id: id },
      {
        isBlocked: isBlocked,
        blockedBy: isBlocked ? adminId : null,
      }
    );

    return apiResponse({
      res,
      status: true,
      message: `User has been ${
        isBlocked ? "blocked" : "unblocked"
      } successfully.`,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to update user block status.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

const getUserMedicineSchedules = async (req, res) => {
  try {
    const { userId, dateFrom, dateTo, doseStatus, medicineName, hospitalName } =
      req.query;

    const matchStage = {};

    if (userId) {
      matchStage.userId = new mongoose.Types.ObjectId(userId);
    }

    if (medicineName) {
      matchStage.medicineName = new mongoose.Types.ObjectId(medicineName);
    }

    if (hospitalName) {
      matchStage.hospitalName = { $regex: new RegExp(hospitalName, "i") };
    }

    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      {
        $unwind: {
          path: "$userDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "supplements", // Adjust this to your actual collection name if it's different
          localField: "medicineName",
          foreignField: "_id",
          as: "medicineDetails",
        },
      },
      {
        $unwind: {
          path: "$medicineDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      { $unwind: "$doseLogs" },
      { $unwind: "$doseLogs.doses" },
    ];

    // Date filter on doseLogs.date
    if (dateFrom || dateTo) {
      const from = dateFrom ? new Date(dateFrom) : new Date("1970-01-01");
      const to = dateTo ? new Date(dateTo) : new Date();
      from.setHours(0, 0, 0, 0);
      to.setHours(23, 59, 59, 999);

      pipeline.push({
        $match: {
          "doseLogs.date": {
            $gte: from,
            $lte: to,
          },
        },
      });
    }

    // Dose status filter
    if (doseStatus) {
      pipeline.push({
        $match: {
          "doseLogs.doses.status": doseStatus,
        },
      });
    }

    pipeline.push({
      $group: {
        _id: "$_id",
        userId: { $first: "$userId" },
        userName: { $first: "$userDetails.fullName" },
        medicineId: { $first: "$medicineName" },
        medicineName: { $first: "$medicineDetails.medicineName" },
        hospitalName: { $first: "$hospitalName" },
        dosage: { $first: "$dosage" },
        quantity: { $first: "$quantity" },
        price: { $first: "$price" },
        startDate: { $first: "$startDate" },
        endDate: { $first: "$endDate" },
        totalDosesPerDay: { $first: "$totalDosesPerDay" },
        createdAt: { $first: "$createdAt" },
        updatedAt: { $first: "$updatedAt" },
        filteredDoses: {
          $push: {
            date: "$doseLogs.date",
            time: "$doseLogs.doses.time",
            status: "$doseLogs.doses.status",
            isReminderSent: "$doseLogs.doses.isReminderSent",
          },
        },
      },
    });

    pipeline.push({ $sort: { startDate: -1 } });

    // Pagination
    const pagination = helper.paginationFun(req.query);
    const paginatedPipeline = [
      ...pipeline,
      { $skip: pagination.skip },
      { $limit: pagination.limit },
    ];

    const [schedules, totalItemsAgg] = await Promise.all([
      MedicineSchedule.aggregate(paginatedPipeline),
      MedicineSchedule.aggregate(pipeline),
    ]);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: totalItemsAgg.length,
    });

    return apiResponse({
      res,
      status: true,
      message: "Filtered medicine schedules fetched successfully.",
      statusCode: StatusCodes.OK,
      data: schedules,
      pagination: paginationData,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch medicine schedules.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

const getUserVaccineSchedules = async (req, res) => {
  try {
    const { userId, vaccineName, doseStatus, dateFrom, dateTo } = req.query;

    const matchStage = {};

    if (userId) {
      matchStage.scheduleBy = new mongoose.Types.ObjectId(userId);
    }

    if (doseStatus) {
      matchStage.scheduleStatus = doseStatus;
    }

    if (dateFrom || dateTo) {
      const from = dateFrom ? new Date(dateFrom) : new Date("1970-01-01");
      const to = dateTo ? new Date(dateTo) : new Date();
      from.setHours(0, 0, 0, 0);
      to.setHours(23, 59, 59, 999);
      matchStage.date = { $gte: from, $lte: to };
    }

    // vaccineName filter → resolve vaccine IDs
    if (vaccineName) {
      const vaccines = await VaccineModel.find({
        vaccineName: { $regex: new RegExp(vaccineName, "i") },
      }).select("_id");

      const vaccineIds = vaccines.map((v) => v._id);
      matchStage.vaccineId = { $in: vaccineIds };
    }

    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: "users",
          localField: "scheduleBy",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      {
        $unwind: {
          path: "$userDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "vaccines",
          localField: "vaccineId",
          foreignField: "_id",
          as: "vaccineDetails",
        },
      },
      {
        $unwind: {
          path: "$vaccineDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $project: {
          _id: 1,
          date: 1,
          doseTime: 1,
          scheduleStatus: 1,
          createdAt: 1,
          updatedAt: 1,
          "userDetails._id": 1,
          "userDetails.fullName": 1,
          "userDetails.email": 1,
          "vaccineDetails._id": 1,
          "vaccineDetails.vaccineName": 1,
          "vaccineDetails.provider": 1,
        },
      },
      { $sort: { date: -1 } },
    ];

    // Pagination
    const pagination = helper.paginationFun(req.query);
    const paginatedPipeline = [
      ...pipeline,
      { $skip: pagination.skip },
      { $limit: pagination.limit },
    ];

    // ✅ Ensure you call the correct model here
    const [schedules, totalItemsAgg] = await Promise.all([
      VaccineSchedule.aggregate(paginatedPipeline),
      VaccineSchedule.aggregate(pipeline),
    ]);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: totalItemsAgg.length,
    });

    return apiResponse({
      res,
      status: true,
      message: "Vaccine schedules fetched successfully.",
      statusCode: StatusCodes.OK,
      data: schedules,
      pagination: paginationData,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch vaccine schedules.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

const getDoctorAvailability = async (req, res) => {
  try {
    const { doctorId, day, startTime, endTime } = req.query;
    const pagination = helper.paginationFun(req.query);

    const matchStage = {};

    if (doctorId) {
      matchStage.doctorId = new mongoose.Types.ObjectId(doctorId);
    }

    const pipeline = [{ $match: matchStage }, { $unwind: "$availability" }];

    if (day) {
      pipeline.push({
        $match: {
          "availability.day": { $regex: new RegExp(`^${day}$`, "i") },
        },
      });
    }

    pipeline.push({ $unwind: "$availability.shift" });

    if (startTime) {
      pipeline.push({
        $match: {
          "availability.shift.startTime": startTime,
        },
      });
    }

    if (endTime) {
      pipeline.push({
        $match: {
          "availability.shift.endTime": endTime,
        },
      });
    }

    pipeline.push({
      $group: {
        _id: {
          doctorId: "$doctorId",
          day: "$availability.day",
        },
        shifts: {
          $push: "$availability.shift",
        },
      },
    });

    pipeline.push({
      $group: {
        _id: "$_id.doctorId",
        availability: {
          $push: {
            day: "$_id.day",
            shift: "$shifts",
          },
        },
      },
    });

    pipeline.push({
      $lookup: {
        from: "users",
        localField: "_id",
        foreignField: "_id",
        as: "doctorDetails",
      },
    });

    pipeline.push({ $unwind: "$doctorDetails" });

    pipeline.push({
      $project: {
        _id: 1,
        doctorId: "$_id",
        doctorName: "$doctorDetails.fullName",
        doctorProfilePicture: "$doctorDetails.profileImage",
        doctorinviteCode: "$doctorDetails.inviteCode",
        availability: 1,
      },
    });

    pipeline.push({ $sort: { doctorName: 1 } });

    const paginatedPipeline = [
      ...pipeline,
      { $skip: pagination.skip },
      { $limit: pagination.limit },
    ];

    const [data, totalData] = await Promise.all([
      DoctorAvailability.aggregate(paginatedPipeline),
      DoctorAvailability.aggregate(pipeline),
    ]);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: totalData.length,
    });

    return apiResponse({
      res,
      status: true,
      message: "Doctor availabilities fetched successfully.",
      statusCode: StatusCodes.OK,
      data,
      pagination: paginationData,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch doctor availabilities.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

const getTelemedicineAppointments = async (req, res) => {
  try {
    const {
      userId,
      doctorId,
      appointmentDate,
      appointmentType,
      status,
      wasSuccessful,
      startDate,
      endDate,
    } = req.query;

    const matchStage = {};

    if (userId) {
      matchStage.userId = new mongoose.Types.ObjectId(userId);
    }

    if (doctorId) {
      matchStage.doctorId = new mongoose.Types.ObjectId(doctorId);
    }

    if (appointmentDate) {
      const date = new Date(appointmentDate);
      const from = new Date(date.setHours(0, 0, 0, 0));
      const to = new Date(date.setHours(23, 59, 59, 999));
      matchStage.appointmentDate = { $gte: from, $lte: to };
    }

    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);

      if (!isNaN(start) && !isNaN(end)) {
        const startOfDay = new Date(start.setHours(0, 0, 0, 0));
        const endOfDay = new Date(end.setHours(23, 59, 59, 999));

        matchStage.appointmentDate = {
          $gte: startOfDay,
          $lte: endOfDay,
        };
      }
    }

    if (appointmentType) {
      matchStage.appointmentType = appointmentType;
    }

    if (status) {
      matchStage.status = status;
    }

    if (wasSuccessful === "true" || wasSuccessful === "false") {
      matchStage["videoCall.wasSuccessful"] = wasSuccessful === "true";
    }

    const pagination = helper.paginationFun(req.query);

    const pipeline = [
      { $match: matchStage },

      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      { $unwind: { path: "$userDetails", preserveNullAndEmptyArrays: true } },

      {
        $lookup: {
          from: "users",
          localField: "doctorId",
          foreignField: "_id",
          as: "doctorDetails",
        },
      },
      { $unwind: { path: "$doctorDetails", preserveNullAndEmptyArrays: true } },

      {
        $project: {
          _id: 1,
          appointmentType: 1,
          appointmentDate: 1,
          appointmentStartTime: 1,
          appointmentEndTime: 1,
          status: 1,
          wasSuccessful: "$videoCall.wasSuccessful",
          createdAt: 1,
          updatedAt: 1,
          user: {
            id: "$userDetails._id",
            name: "$userDetails.fullName",
            profilePicture: "$userDetails.profileImage",
            inviteCode: "$userDetails.inviteCode",
          },
          doctor: {
            id: "$doctorDetails._id",
            name: "$doctorDetails.fullName",
            profilePicture: "$doctorDetails.profileImage",
            inviteCode: "$doctorDetails.inviteCode",
          },
        },
      },

      { $sort: { appointmentDate: -1, appointmentStartTime: 1 } },
    ];

    const paginatedPipeline = [
      ...pipeline,
      { $skip: pagination.skip },
      { $limit: pagination.limit },
    ];

    const [appointments, allData] = await Promise.all([
      Telemedicine.aggregate(paginatedPipeline),
      Telemedicine.aggregate(pipeline),
    ]);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: allData.length,
    });

    return apiResponse({
      res,
      status: true,
      message: "Telemedicine appointments fetched successfully.",
      statusCode: StatusCodes.OK,
      data: appointments,
      pagination: paginationData,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch telemedicine appointments.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

// ------ Assign Role To User ------
const assignRoleToUser = async (req, res) => {
  try {
    const { userId, role } = req.body;

    const user = await UserModel.findOne({ _id: userId, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User not found.",
        statusCode: StatusCodes.NOT_FOUND,
      });
    }

    if (user.role.includes(role)) {
      return apiResponse({
        res,
        status: false,
        message: `This User already has role '${role}'.`,
        statusCode: StatusCodes.BAD_REQUEST,
      });
    }

    user.role = [...new Set([...user.role, role])];

    await user.save();

    const { password, otp, otpExpiresAt, ...safeUser } = user.toObject();

    return apiResponse({
      res,
      status: true,
      message: `Role '${role}' assigned successfully.`,
      data: safeUser,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to assign role.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

// ------ Remove Role From User ------
const removeRoleFromUser = async (req, res) => {
  try {
    const { userId, role } = req.body;

    const user = await UserModel.findOne({ _id: userId, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User not found.",
        statusCode: StatusCodes.NOT_FOUND,
      });
    }

    if (!user.role.includes(role)) {
      return apiResponse({
        res,
        status: false,
        message: `This User does not have role '${role}'.`,
        statusCode: StatusCodes.BAD_REQUEST,
      });
    }

    if (user.role.length === 1) {
      return apiResponse({
        res,
        status: false,
        message: "User must have at least one role.",
        statusCode: StatusCodes.BAD_REQUEST,
      });
    }

    user.role = user.role.filter((r) => r !== role);
    await user.save();

    const { password, otp, otpExpiresAt, secretKey, ...safeUser } =
      user.toObject();

    return apiResponse({
      res,
      status: true,
      message: `Role '${role}' removed successfully.`,
      data: safeUser,
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to remove role.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      error: error.message,
    });
  }
};

const getMedicineUsageByAdmin = async (req, res) => {
  try {
    const { userId, page = 1, limit = 10 } = req.query;
    const filter = userId ? { userId } : {};

    const schedules = await MedicineScheduleModel.find(filter)
      .populate("medicineName", "medicineName")
      .lean();

    const usageMap = new Map();

    schedules.forEach((schedule) => {
      const medName = schedule.medicineName?.medicineName || "Unknown";
      let takenCount = 0;

      schedule.doseLogs?.forEach((day) => {
        day.doses?.forEach((dose) => {
          if (dose.status === enumConfig.scheduleStatusEnums.TAKEN) {
            takenCount++;
          }
        });
      });

      if (takenCount > 0) {
        usageMap.set(medName, (usageMap.get(medName) || 0) + takenCount);
      }
    });

    // Convert to array
    let usageArray = Array.from(usageMap.entries()).map(
      ([medicineName, takenCount]) => ({
        medicineName,
        takenCount,
      })
    );

    // Sort descending
    usageArray.sort((a, b) => b.takenCount - a.takenCount);

    // Max taken for percentage
    const maxTaken = Math.max(...usageArray.map((item) => item.takenCount), 0);

    const usageWithPercentage = usageArray.map((item) => ({
      ...item,
      usagePercentage:
        maxTaken > 0
          ? ((item.takenCount / maxTaken) * 100).toFixed(2) + "%"
          : "0.00%",
    }));

    // Apply pagination
    const { skip, limit: parsedLimit } = helper.paginationFun({ page, limit });
    const paginatedData = usageWithPercentage.slice(skip, skip + parsedLimit);

    const pagination = helper.paginationDetails({
      page,
      totalItems: usageWithPercentage.length,
      limit: parsedLimit,
    });

    return apiResponse({
      res,
      status: true,
      data: paginatedData,
      pagination,
      message: userId
        ? `Medicine usage for user ${userId} fetched successfully`
        : "Top used medicines across all users fetched successfully",
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch medicine usage.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

const getVaccineUsageByAdmin = async (req, res) => {
  try {
    const { userId, page = 1, limit = 10 } = req.query;
    const filter = userId ? { scheduleBy: userId } : {};

    const schedules = await VaccineSchedule.find(filter)
      .populate("vaccineId", "vaccineName")
      .lean();

    if (!schedules.length) {
      return apiResponse({
        res,
        status: true,
        data: [],
        pagination: helper.paginationDetails({ page, totalItems: 0, limit }),
        message: "No vaccine usage data found.",
        statusCode: StatusCodes.OK,
      });
    }

    const usageMap = new Map();

    for (const schedule of schedules) {
      const vaccineName = schedule.vaccineId?.vaccineName || "Unknown";

      if (schedule.scheduleStatus === enumConfig.scheduleStatusEnums.TAKEN) {
        usageMap.set(vaccineName, (usageMap.get(vaccineName) || 0) + 1);
      }
    }

    const usageData = Array.from(usageMap.entries()).map(
      ([vaccineName, takenCount]) => ({
        vaccineName,
        takenCount,
      })
    );

    const maxTaken = Math.max(...usageData.map((item) => item.takenCount), 0);

    const finalData = usageData.map((item) => ({
      ...item,
      usagePercentage:
        maxTaken > 0
          ? ((item.takenCount / maxTaken) * 100).toFixed(2) + "%"
          : "0.00%",
    }));

    finalData.sort((a, b) => b.takenCount - a.takenCount);

    const { skip, limit: parsedLimit } = helper.paginationFun({ page, limit });
    const paginatedData = finalData.slice(skip, skip + parsedLimit);

    const pagination = helper.paginationDetails({
      page,
      totalItems: finalData.length,
      limit: parsedLimit,
    });

    return apiResponse({
      res,
      status: true,
      data: paginatedData,
      pagination,
      message: userId
        ? "User's vaccine usage fetched successfully."
        : "All users' vaccine usage fetched successfully.",
      statusCode: StatusCodes.OK,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      message: "Failed to fetch vaccine usage.",
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
    });
  }
};

export default {
  getAllUserProfile,
  blockAndUnblockUserProfile,
  getUserMedicineSchedules,
  getUserVaccineSchedules,
  getDoctorAvailability,
  getTelemedicineAppointments,
  assignRoleToUser,
  removeRoleFromUser,
  getMedicineUsageByAdmin,
  getVaccineUsageByAdmin,
};
