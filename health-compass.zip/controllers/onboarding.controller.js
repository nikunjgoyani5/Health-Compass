import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import Onboarding from "../models/onboarding.model.js";

const createOnboarding = async (req, res) => {
  try {
    const data = req.body;

    const findOnboarding = await Onboarding.findOne({ userId: req.user._id });
    if (findOnboarding) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Onboarding entry already exists.",
      });
    }

    data.userId = req.user._id;
    const onboarding = await Onboarding.create(data);

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      status: true,
      data: onboarding,
      message: "Onboarding entry created successfully.",
    });
  } catch (error) {
    console.error(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Error creating onboarding entry.",
    });
  }
};

const getOnboarding = async (req, res) => {
  try {
    const onboarding = await Onboarding.findOne({ userId: req.user._id });

    if (!onboarding) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Onboarding entry not found.",
      });
    }

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      data: onboarding,
      message: "Onboarding entry fetched successfully.",
    });
  } catch (error) {
    console.error(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Error fetching onboarding entry.",
    });
  }
};

const updateOnboarding = async (req, res) => {
  try {
    const updatedOnboarding = await Onboarding.findOneAndUpdate(
      { userId: req.user._id },
      { $set: req.body },
      { new: true }
    );

    if (!updatedOnboarding) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Onboarding entry not found.",
      });
    }

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      data: updatedOnboarding,
      message: "Onboarding entry updated successfully.",
    });
  } catch (error) {
    console.error(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Error updating onboarding entry.",
    });
  }
};

export default {
  createOnboarding,
  getOnboarding,
  updateOnboarding,
};
