import bcrypt from "bcrypt";
import { apiResponse } from "../helper/api-response.helper.js";
import enums from "../config/enum.config.js";
import config from "../config/config.js";
import helper from "../helper/common.helper.js";
import { StatusCodes } from "http-status-codes";
import userService from "../services/user.service.js";
import emailService from "../services/email.service.js";
import jwt from "jsonwebtoken";
import admin from "../firebase/config.firebase.js";
import axios from "axios";
import activityService from "../services/userActivity.service.js";
import enumConfig from "../config/enum.config.js";
import UserModel from "../models/user.model.js";

// For verify token
const verifyToken = async (req, res) => {
  try {
    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      message: "Token is verify successfully.",
      status: true,
      data: null,
    });
  } catch (error) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// For email registration
const registerByEmail = async (req, res) => {
  try {
    const { email, password, fullName, role } = req.body;

    let user = await userService.findOne({ email, is_deleted: false }, true);

    const { otp, otpExpiresAt } = helper.generateOTP();

    if (user) {
      if (user.is_verified) {
        return apiResponse({
          res,
          status: false,
          message: "Email ID already in use",
          statusCode: StatusCodes.BAD_REQUEST,
          data: null,
        });
      } else {
        await emailService.sendOTPEmail({
          email,
          otp,
          otpExpiresAt,
          fullName: fullName || user.fullName,
        });
        await userService.update(user._id, { otp, otpExpiresAt });
      }
    } else {
      const hashPassword = await bcrypt.hash(password, 10);
      const newUser = {
        email,
        password: hashPassword,
        provider: enums.authProviderEnum.EMAIL,
        otp,
        otpExpiresAt,
        fullName,
        inviteCode: await helper.generateInviteCode(),
        is_verified: false,
        role,
      };

      await emailService.sendOTPEmail({ email, otp, otpExpiresAt, fullName });
      await userService.create(newUser);
    }

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      status: true,
      message:
        "Registration complete! Check your email for the verification OTP",
      data: null,
    });
  } catch (error) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For verify email otp
const verifyEmailOtp = async (req, res) => {
  try {
    const { email, otp } = req.body;

    let user = await userService.findOne({ email, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "Invalid email or user does not exist",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    if (user.otpExpiresAt && user.otpExpiresAt < new Date()) {
      return apiResponse({
        res,
        status: false,
        message: "OTP has expired",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    if (user.otp !== otp) {
      return apiResponse({
        res,
        status: false,
        message: "Invalid OTP",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    user = await userService.update(
      { email, is_deleted: false },
      { otp: null, otpExpiresAt: null, is_verified: true, otpVerified: true }
    );

    const filteredUser = helper.filteredUser(user);

    const isAdmin = user.role?.includes(enumConfig.userRoleEnum.ADMIN);
    const isPending =
      user.superadminApproveStatus ===
      enumConfig.superadminApproveStatusEnum.PENDING;

    if (isAdmin && isPending) {
      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "OTP verified successfully! Please wait for approval.",
        data: {
          user: filteredUser,
        },
      });
    }

    // Only generate and return token if not pending approval
    const token = await helper.generateToken({ userId: user._id });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "OTP verified successfully!",
      data: {
        token: token,
        user: filteredUser,
      },
    });
  } catch (error) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For resend email otp
const resendEmailOtp = async (req, res) => {
  try {
    const { email } = req.body;

    let user = await userService.findOne({ email: email, is_deleted: false });
    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User does not exist",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    const { otp, otpExpiresAt } = helper.generateOTP();

    await emailService.sendOTPEmail({
      email,
      otp,
      otpExpiresAt,
      fullName: user.fullName,
    });

    await userService.update(
      { email: email, is_deleted: false },
      { otp, otpExpiresAt }
    );

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: `OTP has been resent successfully to mail!`,
      data: null,
    });
  } catch (error) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For email login
const loginByEmail = async (req, res) => {
  try {
    const { email, password, role } = req.body;

    let user = await userService.findOne({ email, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Invalid email or user does not exist",
      });
    }

    // Blocked by admin
    if (user.isBlocked) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Your account is blocked by the admin.",
      });
    }

    // Check for superadmin approval only for ADMIN users
    const isAdmin =
      role?.includes(enumConfig.userRoleEnum.ADMIN) ||
      user.role?.includes(enumConfig.userRoleEnum.ADMIN);

    if (
      isAdmin &&
      user.superadminApproveStatus ===
        enumConfig.superadminApproveStatusEnum.REJECTED
    ) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "Login failed! Your account has been rejected by the owner.",
      });
    }

    if (
      isAdmin &&
      user.superadminApproveStatus !==
        enumConfig.superadminApproveStatusEnum.APPROVED
    ) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message:
          "Please wait for approval. You'll receive an email once approved.",
      });
    }

    // Not verified via OTP
    if (!user.is_verified) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Please verify OTP to activate your account.",
      });
    }

    if (!user.password) {
      return apiResponse({
        res,
        status: false,
        message:
          "You have already created an account using Google. Please use Google login to continue.",
        statusCode: StatusCodes.BAD_REQUEST,
      });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.UNAUTHORIZED,
        message: "Invalid password",
      });
    }

    user.provider = enumConfig.authProviderEnum.EMAIL;
    user.providerId = null;
    await user.save();

    // Successful login
    const token = await helper.generateToken({ userId: user._id });
    const filteredUser = helper.filteredUser(user);
    // Create user activity log for login
    // await activityService.createActivity({
    //   userId: user._id,
    //   email: user.email,
    //   category: enumConfig.activityCategoryEnum.AUTH,
    //   activityType: enumConfig.activityTypeEnum.LOGIN,
    //   description: "User logged in",
    //   status: true,
    // })

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Login successful",
      data: {
        token,
        user: filteredUser,
      },
    });
  } catch (error) {
    console.log(error);

    // Create user activity log for login failure
    // await activityService.createActivity({
    //   email: req.body.email,
    //   category: enumConfig.activityCategoryEnum.AUTH,
    //   activityType: enumConfig.activityTypeEnum.LOGIN,
    //   description: "Login failed",
    //   status: false,
    //   error: error,
    //   errorMessage: error.message
    // });

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For forgot password
const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    let user = await userService.findOne({ email, is_deleted: false });

    if (!user || user.is_verified === false) {
      return apiResponse({
        res,
        status: false,
        message: "User not found",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    if (user.isBlocked) {
      return apiResponse({
        res,
        status: false,
        message:
          "You cannot change password because your account is blocked by admin",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    const { otp, otpExpiresAt } = helper.generateOTP();

    await emailService.sendOTPEmail({ email, otp, fullName: user.fullName });
    await userService.update(user._id, { otp, otpExpiresAt });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "OTP sent successfully!",
      data: null,
    });
  } catch (error) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For reset password
const resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    let user = await userService.findOne({ email, is_deleted: false });

    if (!user) {
      return apiResponse({
        res,
        status: false,
        message: "User not found",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    if (!user.otpVerified) {
      return apiResponse({
        res,
        status: false,
        message: "Please verify OTP before resetting password",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    if (user.isBlocked) {
      return apiResponse({
        res,
        status: false,
        message:
          "You cannot change password because your account is blocked by admin",
        statusCode: StatusCodes.BAD_REQUEST,
        data: null,
      });
    }

    const hashPassword = await bcrypt.hash(newPassword, 10);

    await userService.update(
      { _id: user._id },
      { password: hashPassword, otpVerified: false }
    );

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Password reset successfully!",
      data: null,
    });
  } catch (error) {
    console.error("Error in resetPassword:", error);

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

// For google login/registration
// const loginByGoogle = async (req, res) => {
//   try {
//     const { email, profileImage } = req.body;

//     let user = await userService.findOne({ email, is_deleted: false });

//     if (!user) {
//       const newUser = {
//         email,
//         provider: enums.authProviderEnum.GOOGLE,
//         profileImage: profileImage || null,
//         is_verified: true,
//       };

//       user = await userService.create(newUser);
//     } else {
//       // if (user.provider !== enums.authProviderEnum.GOOGLE) {
//       //   return apiResponse({
//       //     res,
//       //     status: false,
//       //     message: "Email ID already in use with another provider",
//       //     statusCode: StatusCodes.BAD_REQUEST,
//       //     data: null,
//       //   });
//       // }

//       user = await userService.update(
//         { email },
//         {
//           profileImage: profileImage ? profileImage : user.profileImage,
//           provider: enums.authProviderEnum.GOOGLE,
//         }
//       );
//     }

//     const jwtToken = jwt.sign(
//       { userId: user._id, email: user.email },
//       config.jwt.secretKey,
//       {
//         expiresIn: config.jwt.expiresIn || "7days",
//       }
//     );

//     const filteredUser = helper.filteredUser(user);

//     return apiResponse({
//       res,
//       statusCode: StatusCodes.OK,
//       status: true,
//       message: "Google login successful",
//       data: {
//         token: jwtToken,
//         user: filteredUser,
//       },
//     });
//   } catch (error) {
//     console.error("Error during Google login:", error);
//     return apiResponse({
//       res,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       status: false,
//       message: "Invalid Token or expired.",
//       data: null,
//     });
//   }
// };

// For verify recaptcha
const verifyRecaptcha = async (req, res) => {
  try {
    const { token } = req.body;

    const response = await axios.post(
      `https://www.google.com/recaptcha/api/siteverify`,
      null,
      {
        params: {
          secret: config.google.recaptcha_secret_key,
          response: token,
        },
      }
    );

    if (response.data.success) {
      return apiResponse({
        res,
        status: true,
        statusCode: StatusCodes.OK,
        message: "reCAPTCHA verified successfully",
        data: null,
      });
    } else {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Failed reCAPTCHA verification",
        data: null,
      });
    }
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// For google login/registration
const loginByGoogle = async (req, res) => {
  try {
    const { token } = req.body;
    const decodedToken = await admin.auth().verifyIdToken(token);

    const { name, email, picture, uid: providerId } = decodedToken;

    let user = await UserModel.findOne({ email, is_deleted: false });

    if (!user) {
      const newUser = {
        fullName: name,
        email,
        profileImage: picture ? picture : null,
        provider: enums.authProviderEnum.GOOGLE,
        providerId,
        is_verified: true,
        inviteCode: await helper.generateInviteCode(),
      };

      user = await userService.create(newUser);
    } else {
      if (user.provider === enums.authProviderEnum.EMAIL) {
        await userService.update(
          { email },
          {
            provider: enums.authProviderEnum.GOOGLE,
            providerId,
          }
        );
      } else {
        user = await userService.update(
          { email },
          {
            profileImage: picture ? picture : user.profileImage,
            provider: enums.authProviderEnum.GOOGLE,
            providerId,
          }
        );
      }
    }

    const jwtToken = jwt.sign(
      { userId: user._id, email: user.email },
      config.jwt.secretKey,
      {
        expiresIn: config.jwt.expiresIn || "7days",
      }
    );

    const filteredUser = helper.filteredUser(user);

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Google login successful",
      data: {
        token: jwtToken,
        user: filteredUser,
      },
    });
  } catch (error) {
    console.error("Error during Google login:", error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Invalid Token or expired.",
      data: null,
    });
  }
};

// // For apple login/registration
// const loginByApple = async (req, res) => {
//   try {
//     const { token } = req.body;
//     const decodedToken = await admin.auth().verifyIdToken(token);

//     const { email, uid: providerId } = decodedToken;

//     let user = await userService.findOne({ email, isDeleted: false });

//     if (!user) {
//       const generatedEmail = email || `${providerId}@appleid.com`;

//       const newUser = {
//         email: generatedEmail,
//         provider: enums.authProviderEnum.APPLE,
//         providerId,
//         isVerified: true,
//       };

//       user = await userService.create(newUser);
//     } else {
//       await userService.update(
//         { email },
//         {
//           provider: enums.authProviderEnum.APPLE,
//           providerId,
//         }
//       );
//     }

//     const jwtToken = jwt.sign(
//       { userId: user._id, email: user.email },
//       config.jwt.secretKey,
//       {
//         expiresIn: config.jwt.expiresIn || "7days",
//       }
//     );

//     return apiResponse({
//       res,
//       statusCode: StatusCodes.OK,
//       status: true,
//       message: "Apple login successful",
//       data: {
//         token: jwtToken,
//         user,
//       },
//     });
//   } catch (error) {
//     console.error("Error during Apple login:", error);
//     return apiResponse({
//       res,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       status: false,
//       message: "Invalid token or expired.",
//       data: null,
//     });
//   }
// };

export default {
  verifyToken,
  registerByEmail,
  loginByEmail,
  forgotPassword,
  verifyEmailOtp,
  resendEmailOtp,
  verifyToken,
  resetPassword,
  loginByGoogle,
  verifyRecaptcha,
};
