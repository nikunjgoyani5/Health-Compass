import moment from "moment";
import MedicineSchedule from "../models/medicine.schedual.model.js";
import { apiResponse } from "../helper/api-response.helper.js";
import { StatusCodes } from "http-status-codes";
import enumConfig from "../config/enum.config.js";
import Supplement from "../models/supplement.model.js";
import helper from "../helper/common.helper.js";
import caregiverAccessUser from "../middleware/caregiver-access.middleware.js";

// Create a new medicine schedule
const createSchedule = async (req, res) => {
  try {
    const {
      medicineName,
      quantity,
      startDate,
      endDate,
      doseTimes,
      totalDosesPerDay,
    } = req.body;

    console.log("💊 Request body:", req.body);

    const isValidStartDate = helper.validateFutureDate(startDate);
    const isValidEndDate = helper.validateFutureDate(endDate);

    if (!isValidStartDate || !isValidEndDate) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Selected date must be today or a future date.",
        status: false,
        data: null,
      });
    }

    const medicine = await Supplement.findById(medicineName);
    if (!medicine) {
      console.log("❌ Medicine not found for ID:", medicineName);
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Medicine not found",
        status: false,
        data: null,
      });
    }
    console.log("✅ Medicine found:", medicine.medicineName);

    const isExisting = await MedicineSchedule.findOne({
      medicineName,
      userId: req.user.id,
      $or: [
        {
          startDate: { $lte: endDate },
          endDate: { $gte: startDate },
        },
      ],
    });

    if (isExisting) {
      console.log(
        "⚠️ Existing schedule found for overlapping dates:",
        isExisting
      );
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "A schedule for this user and date range already exists.",
        data: null,
      });
    }

    const isCreatedByUser = await Supplement.findOne({
      _id: medicineName,
      createdByAdmin: false,
      userId: req.user.id,
    });

    if (isCreatedByUser) {
      console.log(
        "👤 Supplement created by user. Available quantity:",
        isCreatedByUser.quantity
      );
      if (quantity > isCreatedByUser.quantity) {
        console.log("❌ Requested quantity exceeds available:", quantity);
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.BAD_REQUEST,
          message: `Only ${isCreatedByUser.quantity} item available. Please reduce your quantity.`,
          data: null,
        });
      }
    }

    const start = moment(startDate);
    const end = moment(endDate);
    const today = moment();

    let status = "inactive";
    if (today.isSameOrAfter(start, "day") && today.isSameOrBefore(end, "day")) {
      status = "active";
    }
    console.log("📆 Schedule status:", status);

    const doseLogs = [];
    for (let m = moment(start); m.diff(end, "days") <= 0; m.add(1, "days")) {
      const doses = doseTimes.map((time) => ({
        time,
        status: enumConfig.scheduleStatusEnums.PENDING,
        isReminderSent: false,
      }));

      doseLogs.push({
        date: m.toDate(),
        doses,
      });
    }
    console.log(
      "🗓️ Dose logs generated for schedule from",
      startDate,
      "to",
      endDate
    );

    const schedule = new MedicineSchedule({
      userId: req.user.id,
      medicineName,
      quantity,
      startDate,
      endDate,
      totalDosesPerDay,
      doseLogs,
      status,
    });

    await schedule.save();
    console.log("✅ Schedule saved successfully:", schedule._id);

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      message: "Schedual created successfully.",
      status: true,
      data: schedule,
    });
  } catch (error) {
    console.error("🔥 Error in createSchedule:", error);

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Get all schedules for a user
const getScheduleByUser = async (req, res) => {
  try {
    const requesterId = req.user.id;
    const targetUserId = req.params.userId || req.query.userId || requesterId;

    const hasAccess = await caregiverAccessUser(requesterId, targetUserId);

    console.log("🔐 Caregiver Access Granted:", hasAccess);

    if (!hasAccess) {
      return apiResponse({
        res,
        statusCode: StatusCodes.FORBIDDEN,
        status: false,
        message: "Access denied. You are not authorized to view this data.",
      });
    }

    const pagination = helper.paginationFun(req.query);
    const today = new Date();

    const inactiveSchedules = await MedicineSchedule.find({
      userId: targetUserId,
      status: "inactive",
    });

    for (const schedule of inactiveSchedules) {
      const { startDate, endDate } = schedule;
      if (startDate <= today && today <= endDate) {
        schedule.status = "active";
        await schedule.save();
      } else if (today > endDate) {
        schedule.status = "ended";
        await schedule.save();
      }
    }

    const schedules = await MedicineSchedule.find({ userId: targetUserId })
      .populate("medicineName", "medicineName price dosage")
      .select("-doseLogs.doses.isReminderSent")
      .skip(pagination.skip)
      .limit(pagination.limit)
      .sort({ createdAt: -1 });

    const count = await MedicineSchedule.countDocuments({
      userId: targetUserId,
    });

    console.log("📊 Total Schedules Found:", count);

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: count,
    });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      message: "Schedule fetched successfully.",
      status: true,
      pagination: paginationData,
      data: schedules,
    });
  } catch (error) {
    console.error("❌ Error fetching schedule:", error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// update status
const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const isExisting = await MedicineSchedule.findById(id);
    if (!isExisting) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Medicine schedule not found.",
        data: null,
      });
    }

    isExisting.status = status;
    await isExisting.save();

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      message: "Status updated successfully.",
      status: true,
      data: isExisting,
    });
  } catch (error) {
    console.log(error);

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Update dose status and reduce quantity if 'taken'
const updateDoseStatus = async (req, res) => {
  try {
    const { scheduleId } = req.params;
    const { date, time, status } = req.body;

    const schedule = await MedicineSchedule.findById(scheduleId);
    if (!schedule)
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Schedule not found",
        status: false,
        data: null,
      });

    const log = schedule.doseLogs.find(
      (d) =>
        moment(d.date).format("YYYY-MM-DD") ===
        moment(date).format("YYYY-MM-DD")
    );
    if (!log)
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message:
          "No dose log found for the selected date. Please ensure the schedule is correct.",
        status: false,
        data: null,
      });

    const dose = log.doses.find((t) => t.time === time);
    if (!dose)
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: `No dose found for the time "${time}". Please verify the time and try again.`,
        status: false,
        data: null,
      });

    if (dose.status === enumConfig.scheduleStatusEnums.PENDING) {
      dose.status = status;
      if (status === enumConfig.scheduleStatusEnums.TAKEN) {
        const findMedicine = await Supplement.findOne({
          _id: schedule.medicineName,
          createdByAdmin: false,
          userId: req.user.id,
        });
        if (findMedicine) {
          if (findMedicine.quantity <= 0) {
            return apiResponse({
              res,
              statusCode: StatusCodes.BAD_REQUEST,
              message:
                "Supplement quantity is zero. Please refill before taking a dose.",
              status: false,
              data: null,
            });
          }
          findMedicine.quantity -= 1;
          await findMedicine.save();
        }
      }
    } else if (dose.status === enumConfig.scheduleStatusEnums.MISSED) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message:
          "This dose was missed. Please ensure to take it at the next scheduled time.",
        status: false,
        data: null,
      });
    } else if (dose.status === enumConfig.scheduleStatusEnums.TAKEN) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message:
          "This dose has already been taken. You cannot update the status again.",
        status: false,
        data: null,
      });
    }

    await schedule.save();
    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: schedule,
      message: "Dose status updated successfully",
    });
  } catch (err) {
    console.log(err);

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Get dose logs
const getDoseLogs = async (req, res) => {
  try {
    const { scheduleId } = req.params;

    const schedule = await MedicineSchedule.findById(scheduleId).select(
      "-doseLogs.doses.isReminderSent"
    );
    if (!schedule)
      return apiResponse({
        res,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Schedule not found.",
        status: false,
        data: null,
      });
    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      message: "Dose logs fetch successfully.",
      status: true,
      data: schedule.doseLogs,
    });
  } catch (err) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Get todays doses
const getTodaysDoses = async (req, res) => {
  try {
    const requesterId = req.user.id;
    const targetUserId = req.params.userId || req.query.userId || requesterId;

    const hasAccess = await caregiverAccessUser(requesterId, targetUserId);

    console.log("🔐 Caregiver Access Granted:", hasAccess);

    if (!hasAccess) {
      return apiResponse({
        res,
        statusCode: StatusCodes.FORBIDDEN,
        status: false,
        message: "Access denied. You are not authorized to view this data.",
      });
    }
    const today = moment().format("YYYY-MM-DD");

    const schedules = await MedicineSchedule.find({
      userId: targetUserId,
    }).select("-doseLogs.doses.isReminderSent");

    const todayDoses = [];

    for (const schedule of schedules) {
      const todayLog = schedule.doseLogs.find(
        (log) => moment(log.date).format("YYYY-MM-DD") === today
      );

      const findMedication = await Supplement.findById(
        schedule.medicineName
      ).lean();

      if (todayLog && findMedication) {
        todayDoses.push({
          scheduleId: schedule._id,
          medicineName: findMedication.medicineName,
          dosage: findMedication.dosage,
          date: todayLog.date,
          doses: todayLog.doses.map((dose) => ({
            ...dose._doc,
            note:
              dose.status === "missed"
                ? "You missed this dose. Please take it as soon as possible."
                : `${findMedication.description}`,
          })),
        });
      }
    }

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: todayDoses,
      message: "Doses fetched successfully.",
    });
  } catch (error) {
    console.error("Error in getTodaysDoses:", error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Get doses with quantity
const getAllDosesWithQuantity = async (req, res) => {
  try {
    const userId = req.user.id;

    const schedules = await MedicineSchedule.find({ userId })
      .populate("medicineName", "medicineName dosage price")
      .select("-doseLogs.doses.isReminderSent");

    const result = schedules.map((schedule) => ({
      scheduleId: schedule._id,
      medicineName: schedule.medicineName,
      startDate: schedule.startDate,
      endDate: schedule.endDate,
      totalDosesPerDay: schedule.totalDosesPerDay,
      quantityRemaining: schedule.quantity,
      doseLogs: schedule.doseLogs,
    }));

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: result,
      message: "Doses fetch successfully.",
    });
  } catch (err) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Add medicine quantity
const addMedicineQuantity = async (req, res) => {
  try {
    const { scheduleId } = req.params;
    const { quantity } = req.body;

    if (!quantity || quantity <= 0) {
      return apiResponse({
        res,
        status: false,
        data: null,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Quantity to add must be greater than 0",
      });
    }

    const schedule = await MedicineSchedule.findById(scheduleId);
    if (!schedule) {
      return apiResponse({
        res,
        status: false,
        data: null,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Schedule not found",
      });
    }

    // --- check if suppliment created by login user ---
    const isCreatedByUser = await Supplement.findOne({
      _id: schedule.medicineName,
      createdByAdmin: false,
      userId: req.user.id,
    });

    if (!isCreatedByUser) {
      return apiResponse({
        res,
        status: false,
        data: null,
        statusCode: StatusCodes.NOT_FOUND,
        message: "You are not authorised to update this quantity.",
      });
    }

    if (
      isCreatedByUser &&
      schedule.quantity + quantity > isCreatedByUser.quantity
    ) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: `Total quantity after addition (${
          schedule.quantity + quantity
        }) exceeds available supplement quantity (${
          isCreatedByUser.quantity
        }).`,
        data: null,
      });
    }
    schedule.quantity += quantity;
    await schedule.save();

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      message: "Quantity added successfully",
      data: {
        scheduleId: schedule._id,
        newQuantity: schedule.quantity,
      },
    });
  } catch (err) {
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

// Get doses by date
const getDosesByDate = async (req, res) => {
  try {
    const userId = req.user.id;
    const { date } = req.query;

    if (!date || !moment(date, "YYYY-MM-DD", true).isValid()) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        status: false,
        message: "Invalid or missing date. Use format YYYY-MM-DD.",
        data: null,
      });
    }

    // ✅ Populate from Supplement model
    const schedules = await MedicineSchedule.find({ userId }).populate(
      "medicineName",
      "medicineName description takenForSymptoms associatedRisks"
    );

    const dosesByDate = [];

    schedules.forEach((schedule) => {
      const log = schedule.doseLogs.find(
        (entry) => moment(entry.date).format("YYYY-MM-DD") === date
      );

      if (log) {
        dosesByDate.push({
          scheduleId: schedule._id,
          medicine: {
            name: schedule.medicineName?.medicineName || "Unknown",
            description: schedule.medicineName?.description || "",
            takenForSymptoms: schedule.medicineName?.takenForSymptoms || "",
            associatedRisks: schedule.medicineName?.associatedRisks || "",
          },
          date: log.date,
          doses: log.doses,
        });
      }
    });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: dosesByDate,
      message: `Doses for ${date} fetched successfully.`,
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      data: null,
    });
  }
};

// Create medicine schedule by bot
const createMedicineScheduleByBot = async (req, res) => {
  try {
    const {
      medicineName,
      quantity,
      startDate,
      endDate,
      doseTimes,
      totalDosesPerDay,
    } = req.body;

    const findMedicine = await Supplement.findOne({ medicineName });
    if (!findMedicine) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "This given medicine is not found.",
        status: false,
        data: null,
      });
    }

    const isExisting = await MedicineSchedule.findOne({
      medicineName: findMedicine._id,
      userId: req.user.id,
      $or: [
        {
          startDate: { $lte: endDate },
          endDate: { $gte: startDate },
        },
      ],
    });

    if (isExisting) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "A schedule for this user and date range already exists.",
        data: null,
      });
    }

    const isCreatedByUser = await Supplement.findOne({
      _id: findMedicine._id,
      createdByAdmin: false,
      userId: req.user.id,
    });

    if (isCreatedByUser && quantity > isCreatedByUser.quantity) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: `Only ${isCreatedByUser.quantity} item available. Please reduce your quantity.`,
        data: null,
      });
    }

    const start = moment(startDate);
    const end = moment(endDate);
    const today = moment();

    // Determine status: active if today is between start and end, else inactive
    let status = "inactive";
    if (today.isSameOrAfter(start, "day") && today.isSameOrBefore(end, "day")) {
      status = "active";
    }

    const doseLogs = [];

    for (let m = moment(start); m.diff(end, "days") <= 0; m.add(1, "days")) {
      const doses = doseTimes.map((time) => ({
        time,
        status: enumConfig.scheduleStatusEnums.PENDING,
        isReminderSent: false,
      }));

      doseLogs.push({
        date: m.toDate(),
        doses,
      });
    }

    const schedule = new MedicineSchedule({
      userId: req.user.id,
      medicineName: findMedicine._id,
      quantity,
      startDate,
      endDate,
      totalDosesPerDay,
      doseLogs,
      status,
    });

    await schedule.save();

    return apiResponse({
      res,
      statusCode: StatusCodes.CREATED,
      message: "Schedual created successfully.",
      status: true,
      data: schedule,
    });
  } catch (error) {
    console.log(error);

    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error",
      status: false,
      data: null,
    });
  }
};

export default {
  createSchedule,
  getScheduleByUser,
  updateDoseStatus,
  getDoseLogs,
  getTodaysDoses,
  getAllDosesWithQuantity,
  addMedicineQuantity,
  getDosesByDate,
  updateStatus,
  createMedicineScheduleByBot,
};
