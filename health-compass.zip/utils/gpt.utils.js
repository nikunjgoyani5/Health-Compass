import { OpenAI } from "openai";
import * as chrono from "chrono-node";
import { DateTime } from "luxon";
import { z } from "zod";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const normalizeDate = (inputText) => {
  try {
    const parsed = chrono.parseDate(inputText, new Date(), {
      forwardDate: true,
    });
    if (!parsed) return null;
    return parsed.toISOString().split("T")[0]; 
  } catch (err) {
    console.error("❌ Failed to normalize date:", inputText, err);
    return null;
  }
};

export const getHealthGPTResponse = async (input, options = {}) => {
  try {
    if (typeof input !== "string") {
      throw new Error("getHealthGPTResponse expects a string input.");
    }

    const messages = [
      {
        role: "system",
        content: `
You are HealthBot, a highly skilled healthcare and medicine expert.

You provide clear, accurate, and professional advice on:
- Symptoms
- Common diseases
- Over-the-counter (OTC) medicines
- First aid guidance
- Fitness, exercise, and wellness routines
- Diet and nutrition plans
- Mental health support

Important Instructions:
- You must suggest actual **safe over-the-counter medicines** for minor conditions like fever, headache, cold, stomach pain, etc.
- If multiple options exist, suggest the **best 1-2 medicines** with basic dosage guidance (like "once every 6 hours" or "after food"), but avoid giving exact mg dosages unless very common.
- For any critical or emergency symptoms (severe chest pain, heavy bleeding, seizures), advise immediate hospitalization.
- Use simple, professional, and caring language.
- Do not force users to see a doctor for minor health issues unless symptoms are severe or worsening.
- Your role is to act like a real medicine advisor.
        `,
      },
      {
        role: "user",
        content: input,
      },
    ];

    console.log("📨 Health GPT Messages:", JSON.stringify(messages, null, 2));

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // keep it gpt-4 if available
      messages,
      temperature: options.temperature ?? 0.5,
      max_tokens: options.max_tokens ?? 700,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
    });
    console.log("🧠 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

    const result = response.choices?.[0]?.message?.content?.trim() || "";
    console.log("🧠 Health GPT Final Reply:", result);

    return result;
  } catch (error) {
    console.error(
      "❌ Health GPT Error (Full):",
      error.response?.data || error.message
    );
    throw new Error("Failed to generate Health GPT response.");
  }
};

// export const detectMainIntentWithOpenAI = async (inputText) => {
//   const SYSTEM_PROMPT = `
// You are HealthBot, an intelligent medical assistant. Your job is to classify the user's intent into one of the following **precise categories**.

// Here are the supported intents:

// 1. create_medicine_schedule — User wants to start, create, or set up a regular medicine schedule.
// 2. create_vaccine_schedule — User wants to plan or book a vaccine schedule (with a date and time).
// 3. check_medicine_schedule — User wants to know which medicines are scheduled today or in the future.
// 4. check_vaccine_schedule — User wants to know about upcoming vaccine appointments.
// 5. create_vaccine — User wants to **add a new vaccine** to the system (e.g., vaccine name, provider, description). This is NOT for scheduling.
// 6. create_supplement — User wants to **add/register a new supplement** or medicine product to the system (e.g., name, dosage, price, mfg/exp date). This is NOT for scheduling.
// 7. general_query — Anything else (e.g., symptoms, lifestyle, general health info, irrelevant topics).
// 8. generate_health_score — User wants the bot to ask questions and give a personalized health score based on their responses and also wants to view their health score.

// 🧠 Examples:
// - "I want to schedule my blood pressure medicine." → create_medicine_schedule
// - "Can you remind me which vaccine I have tomorrow?" → check_vaccine_schedule
// - "I want to add a new vaccine called Hepatitis B" → create_vaccine
// - "Add a supplement called Ashwagandha 500mg to my list" → create_supplement
// - "When do I take my morning pill?" → check_medicine_schedule
// - "Book my Covid vaccine for next Monday" → create_vaccine_schedule
// - "What are symptoms of dengue?" → general_query
// - "Can you give me a health score?" → generate_health_score
// - "Can you give me my health score?" → generate_health_score

// ✅ Return only this JSON format:
// { "intent": "one of the above intents" }

// ❌ Do NOT explain anything. Do NOT return anything outside the JSON block.
// `;

//   try {
//     const res = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: [
//         { role: "system", content: SYSTEM_PROMPT },
//         { role: "user", content: inputText },
//       ],
//       temperature: 0,
//       max_tokens: 20,
//     });

//     const raw = res.choices[0].message.content.trim();
//     return JSON.parse(raw);
//   } catch (err) {
//     console.error("❌ Failed to parse main intent:", err);
//     return { intent: "general_query" };
//   }
// };

const VALID_INTENTS = [
  "create_medicine_schedule",
  "create_vaccine_schedule",
  "check_medicine_schedule",
  "check_vaccine_schedule",
  "create_vaccine",
  "create_supplement",
  "general_query",
  "generate_health_score",
];

const responseSchema = z.object({
  intent: z.enum(VALID_INTENTS),
});

export const detectMainIntentWithOpenAI = async (inputText) => {
  const SYSTEM_PROMPT = `
You are HealthBot, an intelligent medical assistant. Classify the user's intent into **one of the following categories only**:

1. create_medicine_schedule — User wants to create/set up a medicine schedule.
2. create_vaccine_schedule — User wants to schedule a vaccine (date/time).
3. check_medicine_schedule — User wants to check upcoming/present medicine timings.
4. check_vaccine_schedule — User wants to check upcoming vaccine appointments.
5. create_vaccine — User wants to add a new vaccine to the system (NOT for scheduling).
6. create_supplement — User wants to add/register a new supplement (NOT for scheduling).
7. general_query — Anything else (symptoms, lifestyle, irrelevant, health info).
8. generate_health_score — User wants a health score based on bot questions.

If the user talks about **"medicine"** or a **specific drug name**, then:
- If the user mentions scheduling, dose time, frequency, or when to take it → intent is **create_medicine_schedule**
- Otherwise, if they just mention adding/storing/registering a medicine → intent is **create_supplement**

🧠 Examples:
- "Add Paracetamol to my daily schedule" → create_medicine_schedule
- "Add medicine Paracetamol" → create_supplement
- "Add Vitamin D supplement to my list" → create_supplement
- "When should I take my pills?" → create_medicine_schedule

✅ Return EXACTLY this JSON format:
{ "intent": "one of the above intents" }

❌ Do NOT explain anything. Do NOT include extra text.
`;

  const fallbackIntent = { intent: "general_query" };

  try {
    const res = await openai.chat.completions.create({
      model: "gpt-4", // or "gpt-4o"
      temperature: 0,
      max_tokens: 20,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: inputText },
      ],
    });

    const raw = res.choices?.[0]?.message?.content?.trim();
    if (!raw) return fallbackIntent;

    const parsed = JSON.parse(raw);
    const validated = responseSchema.safeParse(parsed);
    if (validated.success) {
      return validated.data;
    }

    // Soft fallback
    const fallbackMatch = raw.match(/"intent"\s*:\s*"([^"]+)"/i);
    const intent = fallbackMatch?.[1];
    if (VALID_INTENTS.includes(intent)) {
      return { intent };
    }

    return fallbackIntent;
  } catch (err) {
    console.error("❌ Failed to detect main intent:", err);
    return fallbackIntent;
  }
};


export const verifyMedicineDetailsWithOpenAI = async ({
  medicineName,
  dosage,
  description,
  takenForSymptoms,
  associatedRisks,
}) => {
  const prompt = `
    You are a medical expert. Verify if the following supplement details seem realistic, medically valid, and correct:
    Medicine Name: ${medicineName}
    Dosage: ${dosage}
    Description: ${description}
    Taken For Symptoms: ${takenForSymptoms}
    Associated Risks: ${associatedRisks}
    Respond only with:
    - "VALID" if everything seems realistic and correct.
    - "INVALID" if any information looks wrong, fake, or not medically appropriate.
  `;

  try {
    // Request OpenAI to verify the details
    const gptResponse = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });

    console.log({ gptResponse });

    const verificationResult = gptResponse.choices[0].message.content.trim();
    console.log({ verificationResult });

    if (verificationResult !== "VALID") {
      return {
        isValid: false,
        message:
          "Supplement details seem invalid. Please correct the information.",
      };
    }

    return { isValid: true, message: "Supplement details are valid." };
  } catch (error) {
    console.error("OpenAI Verification Error:", error);
    throw new Error("Error verifying supplement details with OpenAI.");
  }
};

export const detectScheduleIntentWithOpenAI = async (inputText) => {
  const today = new Date().toISOString().split("T")[0];

  const SYSTEM_PROMPT = `
You are HealthBot, a smart and precise medical assistant. Today’s date is ${today}.

You only handle **medicine schedules** (vaccination not included for now).

Your task:
- Understand if the user is asking about:
  1. Medicine schedule for a date (today, tomorrow, or specific date)
  2. Dose status (e.g., how many doses taken, remaining)
  3. Or if it's a general medical question

Response Instructions:
- If user is asking about a medicine schedule for a date, respond:
  {
    "action": "check_schedule",
    "date": "YYYY-MM-DD"
  }

- If user is asking about taken or pending doses, respond:
  {
    "action": "dose_status",
    "date": "YYYY-MM-DD"
  }

- If it's something else unrelated to schedule/doses, respond:
  {
    "action": "general_query"
  }

Important:
- Only use valid JSON format.
- Never explain, never include extra text.
`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: inputText },
      ],
      temperature: 0.7,
      max_tokens: 100,
    });

    const raw = response.choices[0].message.content.trim();

    try {
      const json = JSON.parse(raw);
      console.log("🗕️ Schedule Intent Detected:", json);
      return json;
    } catch (err) {
      console.error("❌ Failed to parse schedule intent JSON:", raw);
      return { action: "general_query" };
    }
  } catch (error) {
    console.error("❌ Error in detectScheduleIntentWithOpenAI:", error);
    throw new Error("Failed to detect schedule intent.");
  }
};

export const detectMedicineIntentWithOpenAI = async (inputText) => {
  const today = new Date().toISOString().split("T")[0];

  const SYSTEM_PROMPT = `
You are HealthBot, a smart and precise medical assistant. Today’s date is ${today}.

You only handle **medicine information-related queries** from the user's supplement list.

Your job:
Detect if the user is asking about:
1. A specific field related to a medicine (e.g., dosage, quantity, risks, expiry, etc.)
2. A quantity check like "Is any medicine less than 30 in quantity?"
3. A request to list all medicines
4. Or if it's a general health-related question

Response Format:
- If user is asking about a specific field of a medicine:
{
  "action": "medicine_info",
  "medicineName": "Levothyroxine",
  "type": "dosage" // possible types: dosage, quantity, description, symptoms, risks, expiry, mfg, price, singlePack
}

- If user is asking whether any medicine quantity is below a threshold:
{
  "action": "quantity_check",
  "threshold": 30
}

- If user is asking to list all medicines:
{
  "action": "list_medicines"
}

- If it's something general or unrelated to medicines:
{
  "action": "general_query"
}

Examples:
Input: "What is Levothyroxine used for?"
Output: { "action": "medicine_info", "medicineName": "Levothyroxine", "type": "symptoms" }

Input: "How many tablets of Omeprazole do I have left?"
Output: { "action": "medicine_info", "medicineName": "Omeprazole", "type": "quantity" }

Input: "Is the quantity of any medicine less than 30?"
Output: { "action": "quantity_check", "threshold": 30 }

Input: "List all my medicines"
Output: { "action": "list_medicines" }

Important:
- Only return valid JSON.
- Do NOT add any explanation or surrounding text.
`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: inputText },
      ],
      temperature: 0.3,
      max_tokens: 100,
    });

    const raw = response.choices[0].message.content.trim();

    try {
      const json = JSON.parse(raw);
      console.log("📂 Medicine Intent Detected:", json);
      return json;
    } catch (err) {
      console.error("❌ Failed to parse medicine intent JSON:", raw);
      return { action: "general_query" };
    }
  } catch (error) {
    console.error("❌ Error in detectMedicineIntentWithOpenAI:", error);
    throw new Error("Failed to detect medicine intent.");
  }
};

export const detectVaccineIntentWithOpenAI = async (inputText) => {
  const today = new Date().toISOString().split("T")[0];

  const SYSTEM_PROMPT = `
You are HealthBot, a smart assistant that handles only vaccination schedules. Today’s date is ${today}.

Understand if the user is asking for:
1. Vaccination schedule for a date (today, tomorrow, or a specific date)

Return format:
{
  "action": "check_vaccine_schedule",
  "date": "YYYY-MM-DD"
}

If it's not a vaccine-related query, return:
{
  "action": "not_vaccine_query"
}

Strict rules:
- Only return valid JSON.
- Never explain or include extra content.
`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: inputText },
      ],
      temperature: 0.3,
      max_tokens: 100,
    });

    const raw = response.choices[0].message.content.trim();

    try {
      const json = JSON.parse(raw);
      console.log("💉 Vaccine Intent Detected:", json);
      return json;
    } catch (err) {
      console.error("❌ Failed to parse vaccine intent JSON:", raw);
      return { action: "not_vaccine_query" };
    }
  } catch (error) {
    console.error("❌ Error in detectVaccineIntentWithOpenAI:", error);
    throw new Error("Failed to detect vaccine intent.");
  }
};

export const normalizeUserInput = async (rawInput) => {
  const SYSTEM_PROMPT = `
You are a powerful conversational assistant that helps rephrase user input into clear, natural, human-like English while preserving the original meaning.

🧠 Instructions:
- Understand the user's intent even if the message is short, broken, or written in mixed Hindi-English.
- Fix grammar, spelling, and structure, but do not change the message's meaning.
- NEVER fabricate, assume, or add content.
- If the input is already clear and short (e.g., "yes", "two", "create a vaccine"), keep it as is.
- If the input is vague or incomplete (e.g., "ok", "hmm", "idk"), return the input unchanged.

Return ONLY the improved message — no explanation, no markdown.
`;

  const skipNormalization = (text) => {
    const safeInputs = [
      "yes",
      "no",
      "ok",
      "cancel",
      "stop",
      "exit",
      "continue",
      "start",
      "restart",
      "1",
      "2",
      "3",
      "4",
      "one",
      "two",
      "three",
      "four",
      "create a vaccine",
      "health score",
    ];
    return safeInputs.includes(text.trim().toLowerCase());
  };

  try {
    if (skipNormalization(rawInput)) {
      return rawInput.trim();
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: rawInput },
      ],
      temperature: 0.3,
      max_tokens: 100,
    });

    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error("❌ Error in normalizeUserInput:", error);
    return rawInput; // fallback to raw input
  }
};

// export const detectCreateMedicineScheduleIntentWithOpenAI = async (
//   messageHistory = [],
//   collected = {}
// ) => {
//   const today = new Date().toISOString().split("T")[0];

//   const SYSTEM_PROMPT = `
// You are HealthBot, a caring assistant helping users schedule their medicine.

// 📆 Today's date is: ${today}

// Collect the following:
// - medicineName (e.g., "Vitamin C")
// - totalDosesPerDay (1, 2, etc.)
// - doseTimes (["9:00 AM", "9:00 PM"])
// - startDate (e.g., "tomorrow", "next Monday", or "YYYY-MM-DD")
// - endDate (same format as above)

// Already collected:
// ${JSON.stringify(collected, null, 2)}

// Conversation:
// ${
//   Array.isArray(messageHistory)
//     ? messageHistory
//         .map((m) => `${m.role.toUpperCase()}: ${m.message}`)
//         .join("\n")
//     : ""
// }

// 🧠 Rules:
// - If user switches topic (e.g., talks about symptoms), return:
//   {
//     "collected": {},
//     "nextStep": "exit",
//     "ask": "It looks like you're talking about something else. Should I cancel medicine schedule creation?"
//   }

// - Never allow past dates for startDate or endDate.
// - If totalDosesPerDay = 2 but only 1 doseTime given, ask for remaining time.
// - If all fields are valid, return nextStep = "done".

// ✅ Respond ONLY in this format:
// {
//   "collected": {
//     "medicineName": "optional string",
//     "totalDosesPerDay": optional number,
//     "doseTimes": ["optional times"],
//     "startDate": "optional YYYY-MM-DD",
//     "endDate": "optional YYYY-MM-DD"
//   },
//   "nextStep": "medicineName | totalDosesPerDay | doseTimes | startDate | endDate | done | exit",
//   "ask": "friendly message"
// }
// `;

//   try {
//     const formattedMessages = [
//       {
//         role: "system",
//         content: [{ type: "text", text: SYSTEM_PROMPT }],
//       },
//       ...(Array.isArray(messageHistory) ? messageHistory : []).map((msg) => ({
//         role: msg.role === "bot" ? "assistant" : msg.role,
//         content: [{ type: "text", text: msg.message }],
//       })),
//     ];

//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: formattedMessages,
//       temperature: 0.4,
//       max_tokens: 800,
//     });

//     const raw = response.choices?.[0]?.message?.content?.trim();
//     console.log("🧪 GPT Raw Response (medicine):", raw);

//     let parsed;

//     try {
//       parsed = JSON.parse(raw);
//     } catch (parseErr) {
//       console.error("❌ Failed to parse JSON:", raw);
//       return {
//         collected,
//         nextStep: "error",
//         ask: "Sorry, I didn’t understand that. Can you rephrase?",
//       };
//     }

//     const normalizeDate = (input) => {
//       const parsedDate = chrono.parseDate(input, { timezone: "Asia/Kolkata" });
//       if (!parsedDate) return null;
//       const iso = parsedDate.toISOString().split("T")[0];
//       return iso >= today ? iso : null;
//     };

//     if (parsed.collected?.startDate) {
//       const validStart = normalizeDate(parsed.collected.startDate);
//       if (validStart) {
//         parsed.collected.startDate = validStart;
//       } else {
//         parsed.nextStep = "startDate";
//         parsed.ask =
//           "⚠️ That date is in the past. Please provide a valid start date.";
//       }
//     }

//     if (parsed.collected?.endDate) {
//       const validEnd = normalizeDate(parsed.collected.endDate);
//       if (validEnd) {
//         parsed.collected.endDate = validEnd;
//       } else {
//         parsed.nextStep = "endDate";
//         parsed.ask =
//           "⚠️ That end date is in the past. Please provide a valid one.";
//       }
//     }

//     // ⏱ Validate dose count
//     if (
//       parsed.collected?.totalDosesPerDay &&
//       parsed.collected?.doseTimes &&
//       parsed.collected.doseTimes.length < parsed.collected.totalDosesPerDay
//     ) {
//       const remaining =
//         parsed.collected.totalDosesPerDay - parsed.collected.doseTimes.length;
//       parsed.nextStep = "doseTimes";
//       parsed.ask = `🕒 You've provided ${parsed.collected.doseTimes.length} time(s), but you said you take ${parsed.collected.totalDosesPerDay} doses per day. Please provide ${remaining} more time(s).`;
//     }

//     return parsed;
//   } catch (error) {
//     console.error(
//       "❌ Error in detectCreateMedicineScheduleIntentWithOpenAI:",
//       error
//     );
//     return {
//       collected,
//       nextStep: "error",
//       ask: "Sorry, I didn’t understand that. Can you rephrase?",
//     };
//   }
// };

// 📦 utils/gpt.utils.js
export const detectCreateMedicineScheduleIntentWithOpenAI = async (
  messageHistory = [],
  collected = {}
) => {
  const today = new Date().toISOString().split("T")[0];

  const SYSTEM_PROMPT = `
You are HealthBot, a caring assistant helping users schedule their medicine.

📆 Today's date is: ${today}

Collect the following:
- medicineName (e.g., "Vitamin C")
- totalDosesPerDay (1, 2, etc.)
- doseTimes (["9:00 AM", "9:00 PM"])
- startDate (e.g., "tomorrow", "next Monday", or "YYYY-MM-DD")
- endDate (same format as above)

Already collected:
${JSON.stringify(collected, null, 2)}

Conversation:
$${Array.isArray(messageHistory)
    ? messageHistory.map((m) => `${m.role.toUpperCase()}: ${m.message}`).join("\n")
    : ""}

🧠 Rules:
- If user switches topic (e.g., talks about symptoms), return:
  {
    "collected": {},
    "nextStep": "exit",
    "ask": "It looks like you're talking about something else. Should I cancel medicine schedule creation?"
  }

- Never allow past dates for startDate or endDate.
- If totalDosesPerDay = 2 but only 1 doseTime given, ask for remaining time.
- If all fields are valid, return nextStep = "done".

✅ Respond ONLY in this format:
{
  "collected": {
    "medicineName": "optional string",
    "totalDosesPerDay": optional number,
    "doseTimes": ["optional times"],
    "startDate": "optional YYYY-MM-DD",
    "endDate": "optional YYYY-MM-DD"
  },
  "nextStep": "medicineName | totalDosesPerDay | doseTimes | startDate | endDate | done | exit",
  "ask": "friendly message"
}
`;

  try {
    const formattedMessages = [
      {
        role: "system",
        content: [{ type: "text", text: SYSTEM_PROMPT }],
      },
      ...((Array.isArray(messageHistory) ? messageHistory : []).map((msg) => ({
        role: msg.role === "bot" ? "assistant" : msg.role,
        content: [{ type: "text", text: msg.message }],
      }))),
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: formattedMessages,
      temperature: 0.4,
      max_tokens: 800,
    });

    const raw = response.choices?.[0]?.message?.content?.trim();
    console.log("🧪 GPT Raw Response (medicine):", raw);

    let parsed;

    try {
      parsed = JSON.parse(raw);
    } catch (parseErr) {
      console.error("❌ Failed to parse JSON:", raw);
      return {
        collected,
        nextStep: "error",
        ask: "Sorry, I didn’t understand that. Can you rephrase?",
      };
    }

    const normalizeDate = (input) => {
      const parsedDate = chrono.parseDate(input, { timezone: "Asia/Kolkata" });
      if (!parsedDate) return null;
      const iso = parsedDate.toISOString().split("T")[0];
      return iso >= today ? iso : null;
    };

    if (parsed.collected?.startDate) {
      const validStart = normalizeDate(parsed.collected.startDate);
      if (validStart) {
        parsed.collected.startDate = validStart;
      } else {
        parsed.nextStep = "startDate";
        parsed.ask = "⚠️ That date is in the past. Please provide a valid start date.";
      }
    }

    if (parsed.collected?.endDate) {
      const validEnd = normalizeDate(parsed.collected.endDate);
      if (validEnd) {
        parsed.collected.endDate = validEnd;
      } else {
        parsed.nextStep = "endDate";
        parsed.ask = "⚠️ That end date is in the past. Please provide a valid one.";
      }
    }

    if (
      parsed.collected?.totalDosesPerDay &&
      parsed.collected?.doseTimes &&
      parsed.collected.doseTimes.length < parsed.collected.totalDosesPerDay
    ) {
      const remaining = parsed.collected.totalDosesPerDay - parsed.collected.doseTimes.length;
      parsed.nextStep = "doseTimes";
      parsed.ask = `🕒 You've provided ${parsed.collected.doseTimes.length} time(s), but you said you take ${parsed.collected.totalDosesPerDay} doses per day. Please provide ${remaining} more time(s).`;
    }

    const requiredFields = ["medicineName", "totalDosesPerDay", "doseTimes", "startDate", "endDate"];
    const stillMissing = requiredFields.filter((f) => !parsed.collected?.[f]);

    if (stillMissing.length >= 1 && parsed.nextStep !== "exit") {
      const humanReadable = stillMissing.map((f) =>
        f === "medicineName"
          ? "medicine name"
          : f === "totalDosesPerDay"
          ? "total doses per day"
          : f === "doseTimes"
          ? "dose times"
          : f === "startDate"
          ? "start date"
          : f === "endDate"
          ? "end date"
          : f
      );

      parsed.nextStep = stillMissing[0];
      parsed.ask = `💊 Please provide the following to create your medicine schedule:\n👉 ${humanReadable.join(", ")}.`;
    }

    return parsed;
  } catch (error) {
    console.error("❌ Error in detectCreateMedicineScheduleIntentWithOpenAI:", error);
    return {
      collected,
      nextStep: "error",
      ask: "Sorry, I didn’t understand that. Can you rephrase?",
    };
  }
};


// export const detectCreateVaccineScheduleIntentWithOpenAI = async (
//   messageHistory = [],
//   collected = {}
// ) => {
//   const today = new Date().toISOString().split("T")[0];

//   const SYSTEM_PROMPT = `
// You are HealthBot, a kind and helpful assistant that helps users schedule vaccinations. Today's date is ${today}.

// Your job is to collect these 3 fields to complete a vaccine schedule:
// 1. vaccineName (e.g., "Hepatitis B", "Covid-19")
// 2. date (can be natural language like "tomorrow", "June 21", "in 3 days")
// 3. doseTime (e.g., "10:30 AM", "2 PM")

// Already collected:
// ${JSON.stringify(collected, null, 2)}

// Recent conversation:
// ${
//   Array.isArray(messageHistory)
//     ? messageHistory
//         .map((m) => `${m.role.toUpperCase()}: ${m.message}`)
//         .join("\n")
//     : ""
// }

// 🧠 Instructions:
// - Detect if the user wants to schedule a vaccine. If not, return: { nextStep: "exit" }
// - If only one or two fields are provided, ask friendly follow-up for missing ones.
// - Validate the date: it must be today or future. If it's in the past, ask:
//   "📅 The date you mentioned is in the past. Please provide a valid future date."
// - If all 3 fields are available, return nextStep = "done".
// - Do not ask multiple things at once.

// ⚠️ Respond ONLY with this strict JSON:
// {
//   "collected": {
//     "vaccineName": "optional string",
//     "date": "optional string",
//     "doseTime": "optional string"
//   },
//   "nextStep": "vaccineName | date | doseTime | done | exit",
//   "ask": "friendly follow-up question"
// }
// `.trim();

//   try {
//     const formattedMessages = [
//       {
//         role: "system",
//         content: [{ type: "text", text: SYSTEM_PROMPT }],
//       },
//       ...(Array.isArray(messageHistory) ? messageHistory : []).map((msg) => ({
//         role: msg.role === "bot" ? "assistant" : msg.role,
//         content: [{ type: "text", text: msg.message }],
//       })),
//     ];

//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: formattedMessages,
//       temperature: 0.4,
//       max_tokens: 600,
//     });

//     const raw = response.choices?.[0]?.message?.content?.trim();

//     try {
//       const parsed = JSON.parse(raw);

//       if (parsed.collected?.date) {
//         const isoDate = normalizeDate(parsed.collected.date);
//         if (isoDate) {
//           const userDate = new Date(isoDate);
//           const now = new Date();
//           now.setHours(0, 0, 0, 0);

//           if (userDate < now) {
//             return {
//               collected: {
//                 ...parsed.collected,
//                 date: undefined,
//               },
//               nextStep: "date",
//               ask: "📅 The date you gave seems to be in the past. Can you please give a valid future date for the vaccine schedule?",
//             };
//           }

//           parsed.collected.date = isoDate;
//         }
//       }

//       console.log("💉 Vaccine Schedule Intent:", parsed);
//       return parsed;
//     } catch (err) {
//       console.error("❌ Failed to parse vaccine schedule JSON:", raw);
//       return {
//         collected,
//         nextStep: "error",
//         ask: "Sorry, I didn’t catch that. Could you rephrase your input?",
//       };
//     }
//   } catch (error) {
//     console.error(
//       "❌ Error in detectCreateVaccineScheduleIntentWithOpenAI:",
//       error
//     );
//     throw new Error("Failed to process vaccine schedule intent.");
//   }
// };

export const detectCreateVaccineScheduleIntentWithOpenAI = async (
  messageHistory = [],
  collected = {}
) => {
  const today = new Date().toISOString().split("T")[0];
  const safeHistory = Array.isArray(messageHistory) ? messageHistory : [];

  const SYSTEM_PROMPT = `
You are HealthBot, a kind and helpful assistant that helps users schedule vaccinations. Today's date is ${today}.

Your job is to collect these 3 fields to complete a vaccine schedule:
1. vaccineName (e.g., "Hepatitis B", "Covid-19")
2. date (can be natural language like "tomorrow", "June 21", "in 3 days")
3. doseTime (e.g., "10:30 AM", "2 PM")

Already collected:
${JSON.stringify(collected, null, 2)}

Recent conversation:
${
  Array.isArray(messageHistory)
    ? messageHistory.map((m) => `${m.role.toUpperCase()}: ${m.message}`).join("\n")
    : ""
}

🧠 Instructions:
- If the user is not talking about vaccine scheduling, return:
{
  "collected": {},
  "nextStep": "exit",
  "ask": "It looks like you're talking about something else. Should I cancel vaccine schedule creation?"
}

- If more than one required field is missing, ask for them together in one sentence.
- If all 3 fields are filled, set nextStep = "done".
- If the date is in the past, return:
{
  "collected": { "vaccineName": "...", "doseTime": "..." },
  "nextStep": "date",
  "ask": "📅 The date you mentioned is in the past. Please provide a valid future date."
}

✅ Output format (strictly JSON):
{
  "collected": {
    "vaccineName": "optional string",
    "date": "optional string",
    "doseTime": "optional string"
  },
  "nextStep": "vaccineName | date | doseTime | done | exit",
  "ask": "Your next message to the user"
}
`.trim();

  try {
    const formattedMessages = [
      {
        role: "system",
        content: [{ type: "text", text: SYSTEM_PROMPT }],
      },
      ...safeHistory.map((msg) => ({
        role: msg.role === "bot" ? "assistant" : msg.role,
        content: [{ type: "text", text: msg.message }],
      })),
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: formattedMessages,
      temperature: 0.4,
      max_tokens: 600,
    });

    const raw = response.choices?.[0]?.message?.content?.trim();

    try {
      const parsed = JSON.parse(raw);

      // Normalize and validate date
      if (parsed.collected?.date) {
        const isoDate = normalizeDate(parsed.collected.date);
        if (isoDate) {
          const userDate = new Date(isoDate);
          const now = new Date();
          now.setHours(0, 0, 0, 0);

          if (userDate < now) {
            return {
              collected: {
                ...parsed.collected,
                date: undefined,
              },
              nextStep: "date",
              ask: "📅 The date you gave seems to be in the past. Can you please give a valid future date for the vaccine schedule?",
            };
          }

          parsed.collected.date = isoDate;
        }
      }

      // Batching for missing required fields
      const requiredFields = ["vaccineName", "date", "doseTime"];
      const stillMissing = requiredFields.filter((f) => !parsed.collected?.[f]);

      if (stillMissing.length >= 1 && parsed.nextStep !== "exit") {
        const humanReadable = stillMissing.map((f) =>
          f === "vaccineName"
            ? "vaccine name"
            : f === "date"
            ? "vaccination date"
            : f === "doseTime"
            ? "vaccination time"
            : f
        );

        parsed.nextStep = stillMissing[0];
        parsed.ask = `📝 Please provide the following details to schedule the vaccine:\n👉 ${humanReadable.join(", ")}.`;
      }

      console.log("💉 Vaccine Schedule Intent:", parsed);
      return parsed;
    } catch (err) {
      console.error("❌ Failed to parse vaccine schedule JSON:", raw);
      return {
        collected,
        nextStep: "error",
        ask: "Sorry, I didn’t catch that. Could you rephrase your input?",
      };
    }
  } catch (error) {
    console.error("❌ Error in detectCreateVaccineScheduleIntentWithOpenAI:", error);
    throw new Error("Failed to process vaccine schedule intent.");
  }
};

// export const detectCreateVaccineIntentWithOpenAI = async (
//   messageHistory = [],
//   collected = {}
// ) => {
//   const SYSTEM_PROMPT = `
// You are HealthBot, helping users add new vaccines to their health records.

// You must collect:
// - vaccineName (required): e.g., "Covid-19"
// - provider (required): e.g., "Pfizer", "Merck"
// - description (optional): Only include if user provides it

// Already collected:
// ${JSON.stringify(collected, null, 2)}

// Full chat history:
// ${
//   Array.isArray(messageHistory)
//     ? messageHistory.map((m) => `[${m.role}]: ${m.message}`).join("\n")
//     : ""
// }

// Instructions:
// - If the user starts discussing a **different topic** (like symptoms, diseases, pain, fever, or supplement-related terms), assume they are switching context.
// - In that case, return:
// {
//   "collected": {},
//   "nextStep": "exit",
//   "ask": "It looks like you're talking about something else. Should I cancel vaccine creation?"
// }

// ✅ Respond only with valid JSON in this format:
// {
//   "collected": {
//     "vaccineName": "...",
//     "provider": "...",
//     "description": "..."
//   },
//   "nextStep": "vaccineName | provider | description | done | exit",
//   "ask": "your message to the user"
// }
// `.trim();

//   try {
//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: [
//         { role: "system", content: SYSTEM_PROMPT },
//         ...messageHistory.map((m) => ({
//           role: m.role === "bot" ? "assistant" : m.role,
//           content: m.message,
//         })),
//       ],
//       temperature: 0.4,
//       max_tokens: 600,
//     });

//     const raw = response.choices[0].message.content.trim();

//     if (!raw.startsWith("{")) {
//       throw new Error("Not a JSON response");
//     }

//     const parsed = JSON.parse(raw);
//     console.log("💉 Vaccine Create Intent:", parsed);
//     return parsed;
//   } catch (error) {
//     console.error("❌ Failed to parse vaccine creation intent:", error);
//     return {
//       collected: {},
//       nextStep: "exit",
//       ask: "It looks like you're talking about something else. Should I cancel vaccine creation?",
//     };
//   }
// };

export const detectCreateVaccineIntentWithOpenAI = async (
  messageHistory = [],
  collected = {}
) => {
  const safeHistory = Array.isArray(messageHistory) ? messageHistory : [];

  const SYSTEM_PROMPT = `
You are HealthBot, helping users add new vaccines to their health records.

You must collect:
- vaccineName (required): e.g., "Covid-19"
- provider (required): e.g., "Pfizer", "Merck"
- description (optional): Only include if user provides it

Already collected:
${JSON.stringify(collected, null, 2)}

Full chat history:
${
  Array.isArray(messageHistory)
    ? messageHistory.map((m) => `${m.role.toUpperCase()}: ${m.message}`).join("\n")
    : ""
}

Instructions:
- If the user starts discussing a different topic (e.g. symptoms, diseases, pain, fever, supplement-related terms), assume context switch.
- In that case, return:
  {
    "collected": {},
    "nextStep": "exit",
    "ask": "It looks like you're talking about something else. Should I cancel vaccine creation?"
  }

- If both required fields are missing, ask for both together.
  Example: "Please share the name of the vaccine and the provider."
- If only one required field is missing, ask for that one clearly.
- If only optional field is missing, ask optionally.
- If all required fields are present, set nextStep = "done".

✅ ONLY respond with valid JSON like:
{
  "collected": {
    "vaccineName": "...",
    "provider": "...",
    "description": "..."
  },
  "nextStep": "vaccineName | provider | description | done | exit",
  "ask": "your message to the user"
}
`.trim();

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...safeHistory.map((m) => ({
          role: m.role === "bot" ? "assistant" : m.role,
          content: m.message,
        })),
      ],
      temperature: 0.4,
      max_tokens: 600,
    });

    const raw = response.choices[0].message.content.trim();
    if (!raw.startsWith("{")) throw new Error("Not a JSON response");

    const parsed = JSON.parse(raw);
    console.log("💉 Vaccine Create Intent:", parsed);

    // Force batching if vaccineName or provider are missing
    const requiredFields = ["vaccineName", "provider"];
    const stillMissing = requiredFields.filter((f) => !parsed.collected?.[f]);

    if (stillMissing.length >= 1 && parsed.nextStep !== "exit") {
      const humanReadable = stillMissing.map((f) =>
        f === "vaccineName"
          ? "vaccine name"
          : f === "provider"
          ? "provider name"
          : f
      );

      parsed.nextStep = stillMissing[0];
      parsed.ask = `📝 Please provide the following info to continue:\n👉 ${humanReadable.join(", ")}.`;
    }

    return parsed;
  } catch (error) {
    console.error("❌ Failed to parse vaccine creation intent:", error);
    return {
      collected: {},
      nextStep: "exit",
      ask: "It looks like you're talking about something else. Should I cancel vaccine creation?",
    };
  }
};

// export const detectCreateSupplementIntentWithOpenAI = async (
//   messageHistory = [],
//   collected = {}
// ) => {
//   const SYSTEM_PROMPT = `
// You are HealthBot, helping users create a new supplement (medicine) entry.

// 📌 Required fields:
// - medicineName (string)
// - dosage (e.g., "500mg")
// - price (number)
// - quantity (number)
// - singlePack (true/false)
// - mfgDate (e.g., "today", "2025-06-21", "next Monday", "in 3 days")
// - expDate (e.g., "in 1 year", "2026-01-01", "next year May")

// 📌 Optional:
// - description
// - takenForSymptoms
// - associatedRisks

// Already collected:
// ${JSON.stringify(collected, null, 2)}

// Recent conversation:
// ${messageHistory.map((m) => `${m.role.toUpperCase()}: ${m.message}`).join("\n")}

// 🧠 Instructions:
// - Collect missing fields step-by-step.
// - Be friendly and clear. If the topic clearly changes (like user asks about symptoms or a different action), set "nextStep": "exit".
// - In that case, return:
//   {
//     "collected": {},
//     "nextStep": "exit",
//     "ask": "It looks like you're talking about something else. Should I cancel vaccine schedule creation?"
//   }
// - If all required fields are filled, set "nextStep": "done"
// - Ask in a warm, conversational tone.

// 🚫 Do not explain or return anything except a valid JSON block.

// ✅ Return ONLY in this format:
// {
//   "collected": {
//     "medicineName": "optional string",
//     "dosage": "optional string",
//     "price": optional number,
//     "quantity": optional number,
//     "singlePack": optional boolean,
//     "mfgDate": "optional string",
//     "expDate": "optional string",
//     "description": "optional string",
//     "takenForSymptoms": "optional string",
//     "associatedRisks": "optional string"
//   },
//   "nextStep": "medicineName | dosage | price | quantity | singlePack | mfgDate | expDate | description | takenForSymptoms | associatedRisks | done | exit",
//   "ask": "Your next question to the user"
// }
// `.trim();

//   try {
//     const formattedMessages = [
//       {
//         role: "system",
//         content: [{ type: "text", text: SYSTEM_PROMPT }],
//       },
//       ...(Array.isArray(messageHistory) ? messageHistory : []).map((msg) => ({
//         role: msg.role === "bot" ? "assistant" : msg.role,
//         content: [{ type: "text", text: msg.message }],
//       })),
//     ];

//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: formattedMessages,
//       temperature: 0.4,
//       max_tokens: 700,
//     });

//     const raw = response.choices?.[0]?.message?.content?.trim();

//     try {
//       const parsed = JSON.parse(raw);
//       console.log("🧪 Supplement Intent:", parsed);

//       // Normalize natural language dates to ISO format
//       if (parsed.collected.mfgDate) {
//         const parsedMfg = normalizeDate(parsed.collected.mfgDate);
//         if (parsedMfg) parsed.collected.mfgDate = parsedMfg;
//       }
//       if (parsed.collected.expDate) {
//         const parsedExp = normalizeDate(parsed.collected.expDate);
//         if (parsedExp) parsed.collected.expDate = parsedExp;
//       }

//       return parsed;
//     } catch (err) {
//       console.error("❌ Failed to parse supplement JSON:", raw);
//       return {
//         collected,
//         nextStep: "error",
//         ask: "Sorry, I didn’t understand that. Could you repeat?",
//       };
//     }
//   } catch (error) {
//     console.error("❌ Error in detectCreateSupplementIntentWithOpenAI:", error);
//     throw new Error("Failed to process supplement creation intent.");
//   }
// };

export const detectCreateSupplementIntentWithOpenAI = async (
  messageHistory = [],
  collected = {}
) => {
  const SYSTEM_PROMPT = `
You are HealthBot, helping users create a new supplement (medicine) entry.

📌 Required fields:
- medicineName (string)
- dosage (e.g., "500mg")
- price (number)
- quantity (number)
- singlePack (true/false)
- mfgDate (e.g., "today", "2025-06-21", "next Monday", "in 3 days")
- expDate (e.g., "in 1 year", "2026-01-01", "next year May")

📌 Optional:
- description
- takenForSymptoms
- associatedRisks

Already collected:
${JSON.stringify(collected, null, 2)}

Recent conversation:
${messageHistory.map((m) => `${m.role.toUpperCase()}: ${m.message}`).join("\n")}

🧠 Instructions:
- If more than one required field is missing, ask for all of them together in a single sentence.
- If only one required field is missing, ask just that one.
- If user gives some of the required fields, ask again only for the remaining ones.
- If all required fields are filled, set nextStep = "done".
- 🚫 If the user changes the topic (e.g., asking about pain, symptoms, what to do), then set nextStep = "exit".
- Do NOT mix health advice with supplement creation. Exit cleanly if context changed.

🚫 ONLY return JSON like below:
{
  "collected": {
    "medicineName": "optional string",
    "dosage": "optional string",
    "price": optional number,
    "quantity": optional number,
    "singlePack": optional boolean,
    "mfgDate": "optional string",
    "expDate": "optional string",
    "description": "optional string",
    "takenForSymptoms": "optional string",
    "associatedRisks": "optional string"
  },
  "nextStep": "medicineName | dosage | price | quantity | singlePack | mfgDate | expDate | description | takenForSymptoms | associatedRisks | done | exit",
  "ask": "Next question to user"
}
`.trim();

  try {
    const formattedMessages = [
      {
        role: "system",
        content: [{ type: "text", text: SYSTEM_PROMPT }],
      },
      ...messageHistory.map((msg) => ({
        role: msg.role === "bot" ? "assistant" : msg.role,
        content: [{ type: "text", text: msg.message }],
      })),
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: formattedMessages,
      temperature: 0.4,
      max_tokens: 700,
    });

    const raw = response.choices?.[0]?.message?.content?.trim();

    try {
      const parsed = JSON.parse(raw);
      console.log("💊 Supplement Intent:", parsed);

      // 🚪 Exit if detected
      if (parsed.nextStep === "exit") {
        return {
          collected: {},
          nextStep: "exit",
          ask: null,
        };
      }

      // ✅ Normalize dates
      if (parsed.collected.mfgDate) {
        const normMfg = normalizeDate(parsed.collected.mfgDate);
        if (normMfg) parsed.collected.mfgDate = normMfg;
      }

      if (parsed.collected.expDate) {
        const normExp = normalizeDate(parsed.collected.expDate);
        if (normExp) parsed.collected.expDate = normExp;
      }

      // ✅ Confirm booleans if unclear
      if (
        parsed.collected.singlePack !== undefined &&
        typeof parsed.collected.singlePack !== "boolean"
      ) {
        const suggestedValue =
          String(parsed.collected.singlePack).toLowerCase() === "true";
        draftCache[userId].suggestedField = "singlePack";
        draftCache[userId].suggestedValue = suggestedValue;
        return {
          collected,
          nextStep: "singlePack",
          ask: `💡 Just to confirm, did you mean **${suggestedValue}** for "singlePack"? Reply with "yes" or give another value.`,
        };
      }

      // ✅ Force batching if still missing
      const requiredFields = [
        "medicineName",
        "dosage",
        "price",
        "quantity",
        "singlePack",
        "mfgDate",
        "expDate",
      ];

      const stillMissing = requiredFields.filter(
        (field) => !parsed.collected?.[field]
      );

      if (stillMissing.length >= 1) {
        const humanReadable = stillMissing.map((f) =>
          f
            .replace("medicineName", "name of the supplement")
            .replace("dosage", "dosage")
            .replace("price", "price")
            .replace("quantity", "quantity")
            .replace("singlePack", "whether it’s sold in a single pack (yes/no)")
            .replace("mfgDate", "manufacture date")
            .replace("expDate", "expiry date")
        );

        parsed.nextStep = stillMissing[0];
        parsed.ask = `📋 Please provide the following details to continue:\n👉 ${humanReadable.join(", ")}.`;
      }

      return parsed;
    } catch (err) {
      console.error("❌ Failed to parse supplement JSON:", raw);
      return {
        collected,
        nextStep: "error",
        ask: "Sorry, I didn’t understand that. Could you rephrase?",
      };
    }
  } catch (error) {
    console.error("❌ Error in detectCreateSupplementIntentWithOpenAI:", error);
    throw new Error("Failed to process supplement creation intent.");
  }
};


// export const detectCreateHealthRecordIntentWithOpenAI = async (
//   inputText,
//   collected = {},
//   previousScore = null
// ) => {
//   // Merge new answer if inputText is a number (user's answer to previous question)
//   let answers = { ...collected };
//   let answeredCount = Object.keys(answers).length;

//   // If inputText is a number (1-4) and not the initial trigger, add it as the next answer
//   if (/^[1-4]$/.test(inputText.trim()) && answeredCount < 10) {
//     answers[answeredCount + 1] = inputText.trim();
//     answeredCount = Object.keys(answers).length;
//   }

//   const SYSTEM_PROMPT = `You are HealthBot, an intelligent and empathetic health assessment AI assistant.

//   Instructions:
//   - Your goal is to help users assess their overall health by asking exactly 10 **unique** and **diverse** health-related questions, one at a time.
//   - Each question must cover a different area of health (e.g. physical activity, sleep, diet, hydration, mental wellness, stress, screen time, social life, posture, preventive care).
//   - Do **not** repeat topics or ask similar questions with different wording.
//   - Each question must have 4 distinct options, numbered 1 through 4.
//   - Questions should be advanced, helpful.
//   - Avoid technical language, use clear and friendly tone.
//   - Always ask the next **unanswered** and **unique-topic** question.
//   - Ask in the user’s preferred language.
//   - Use a motivational and supportive tone.

//   Scoring:
//   - Option 1 = 2.5 points
//   - Option 2 = 5 points
//   - Option 3 = 7.5 points
//   - Option 4 = 10 points
//   - Maximum total score = 100 points

//   Answer Handling:
// - Accept user responses in any **format** or **language** (e.g., "1", "one", "Two", "FOUR", "तीन", "चार", etc.).
// - Normalize and interpret answers that clearly match options 1 to 4.
// - If the input clearly maps to one of the options (1–4), proceed to the next question.
// - If the input is **invalid or unclear**, do **not** proceed. Instead, respond with:
//   "❌ I couldn’t understand your response. Please reply with a valid option (1 to 4)."
// - Do not repeat the previous question unless asked — only notify the user about the invalid input.

//   After 10 answers:
//   - Calculate the total score by summing all selected answers’ scores.
//   - If a previous score is provided, include it as "previousScore".
//   - Compare previous and current score:
//       - Start the message with: “Previous Score: X, Current Score: Y.”
//       - State if the score increased, decreased, or stayed the same.
//       - Provide a clear status (Low, Medium, High) and friendly suggestions for improvement or maintenance.

//   Score Ranges:
//   - 0–40 (Low): Recommend improvements in lifestyle (exercise, sleep, diet, water, stress).
//   - 41–70 (Medium): Encourage consistency; suggest 1–2 focus areas for improvement.
//   - 71–100 (High): Praise good health; suggest maintenance habits (checkups, mindfulness, etc.).

//   Also:
//   - Provide personalized suggestions based on answer trends.
//       - If physical activity is low → recommend light daily walks.
//       - If hydration is low → suggest a daily water reminder app.
//       - If stress is high → recommend breathing or journaling exercises.
//       - If social engagement is low → recommend connecting with loved ones.

//   Reply format:
//   - When fewer than 10 answers: Respond ONLY with the next question and 4 options.
//   - When all 10 answers are received: Respond ONLY with a raw JSON like below (no markdown, no extra text):

//   {
//     "score": "<current score as string>",
//     "previousScore": "<previous score as string>",
//     "message": "<Begin with 'Previous Score: X, Current Score: Y.' Then give score trend, current health assessment, and clear advice>"
//   }

//   Question format:
//   1. [question text]
//   1. [Option 1]
//   2. [Option 2]
//   3. [Option 3]
//   4. [Option 4]

//   Important: Each option must appear on a **new line** directly under the question.
//   `;

//   try {
//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       messages: [
//         { role: "system", content: SYSTEM_PROMPT },
//         {
//           role: "user",
//           content:
//             answeredCount === 10
//               ? `Here are my responses: ${JSON.stringify(answers)}${
//                   previousScore
//                     ? ` and my previous score was ${previousScore}`
//                     : ""
//                 }`
//               : `Ask question number ${answeredCount + 1}`,
//         },
//       ],
//       temperature: 0.7,
//       max_tokens: 800,
//     });

//     const raw = response.choices[0].message.content.trim();
//     console.log("✅ Raw response from OpenAI:", raw);

//     if (answeredCount === 10) {
//       try {
//         const parsed = JSON.parse(raw);
//         console.log("✅ Parsed JSON response:", parsed);
//         return {
//           score: parsed.score.toString(),
//           message: parsed.message || "Thanks for completing the assessment!",
//         };
//       } catch (err) {
//         console.error("❌ JSON parsing failed:", err);
//         return {
//           score: "0",
//           message: "Sorry, I couldn't process that. Please try again.",
//         };
//       }
//     } else {
//       // Just return the next question
//       return {
//         questionNumber: answeredCount + 1,
//         question: raw,
//         answers, // return current answers for debugging if needed
//       };
//     }
//   } catch (error) {
//     console.error("❌ Error in health score assessment:", error);
//     return {
//       score: "0",
//       message: "Sorry, I couldn't process that. Please try again.",
//     };
//   }
// };

export const detectCreateHealthRecordIntentWithOpenAI = async (
  inputText,
  collected = {},
  previousScore = null
) => {
  let answers = { ...collected };
  let answeredCount = Object.keys(answers).length;

  const normalizeInput = (input = "") => {
    const cleaned = input.trim().toLowerCase();
    if (/^(one|1|ek|१|१\.|١)$/i.test(cleaned)) return "1";
    if (/^(two|2|do|२|٢)$/i.test(cleaned)) return "2";
    if (/^(three|3|teen|३|٣)$/i.test(cleaned)) return "3";
    if (/^(four|4|char|चार|٤)$/i.test(cleaned)) return "4";
    return null;
  };

  const normalizedInput = normalizeInput(inputText);

  if (normalizedInput && answeredCount < 10) {
    answers[answeredCount + 1] = normalizedInput;
    answeredCount = Object.keys(answers).length;
  }

  const SYSTEM_PROMPT = `
You are HealthBot, an intelligent and empathetic health assessment AI assistant.

🧠 Instructions:
- Ask users 10 unique health-related multiple-choice questions (MCQs), one at a time.
- Use 10 distinct domains: activity, sleep, diet, hydration, mental health, stress, screen time, social life, posture, preventive care.
- Each must have exactly 4 options (1 to 4), with no domain repetition.
- Use a friendly, motivational tone.
- Accept answers in multiple languages and formats (e.g., “1”, “one”, “तीन”, “FOUR”).

📉 Scoring:
- 1 = 2.5 pts
- 2 = 5 pts
- 3 = 7.5 pts
- 4 = 10 pts

📤 Final Report:
- Once all 10 responses are collected:
  1. Sum the score.
  2. Compare with previousScore (if provided).
  3. Output JSON only:
  {
    "score": "<string>",
    "previousScore": "<string>",
    "message": "<score change summary + status (Low/Medium/High) + health tips>"
  }

🚫 IMPORTANT:
If the user changes topic (e.g., "how do I cancel supplement?"), respond ONLY with:
{
  "nextStep": "exit",
  "ask": "It seems like you've changed the topic. Should I stop the health assessment?"
}

✅ Response Rules:
- If less than 10 answers → return ONLY next question string.
- If 10 answers → return ONLY JSON as described above.
- NEVER explain format. Never return markdown.
`.trim();

  try {
    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content:
          answeredCount === 10
            ? `Here are my answers: ${JSON.stringify(answers)}${
                previousScore
                  ? ` and my previous score was ${previousScore}`
                  : ""
              }`
            : inputText,
      },
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages,
      temperature: 0.5,
      max_tokens: 800,
    });

    const raw = response.choices[0]?.message?.content?.trim();
    console.log("🧪 Raw GPT Response:", raw);

    // If GPT returned structured JSON
    if (raw.startsWith("{")) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed?.nextStep === "exit") {
          return parsed;
        }

        if (answeredCount === 10) {
          return {
            score: parsed.score.toString(),
            previousScore: parsed.previousScore || previousScore || null,
            message:
              parsed.message || "✅ Your health score has been calculated.",
          };
        }
      } catch (e) {
        console.error("❌ JSON Parse Error:", e);
        return {
          score: "0",
          message: "Sorry, something went wrong. Please try again.",
        };
      }
    }

    // GPT returned a plain next question
    if (answeredCount < 10) {
      return {
        questionNumber: answeredCount + 1,
        question: raw,
        answers,
      };
    }

    // Fallback
    return {
      score: "0",
      message: "⚠️ Something went wrong. Please try again.",
    };
  } catch (error) {
    console.error("❌ detectCreateHealthRecordIntentWithOpenAI error:", error);
    return {
      score: "0",
      message:
        "Sorry, I couldn't process your request. Please try again later.",
    };
  }
};
