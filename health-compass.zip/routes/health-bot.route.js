import express from "express";
import { verifyToken } from "../middleware/verify-token.middleware.js";
import controller from "../controllers/health-bot.controller.js";
import validation from "../validations/health-bot.validation.js";
import validate from "../middleware/validate.middleware.js";

const route = express.Router();

route.post(
  "/chat",
  verifyToken,
  validate(validation.chatWithHealthBot),
  controller.chatWithHealthBot
);

export default route;