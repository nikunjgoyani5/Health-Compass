import express from "express";
import validate from "../middleware/validate.middleware.js";
import PrivacyAndDataValidation from "../validations/privacyAndData.validation.js";
import { verifyToken } from "../middleware/verify-token.middleware.js";
import { checkPermission } from "../middleware/verify-role.middleware.js";
import enumConfig from "../config/enum.config.js";
import controller from "../controllers/privacyAndData.controller.js";
import privacyAndDataValidation from "../validations/privacyAndData.validation.js";

const route = express.Router();

route.patch(
    "/update",
    verifyToken,
    // checkPermission([enumConfig.userRoleEnums.ADMIN]),
    validate(privacyAndDataValidation.savePrivacySetting),
    controller.updatePrivacySetting
)

route.get(
    "/get",
    verifyToken,
    // checkPermission([enumConfig.userRoleEnums.ADMIN]),
    controller.getPrivacySetting
)


export default route;