import mongoose from "mongoose";

const planSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      enum: ["FreeTrial", "Pro"],
      required: true,
    },
    storageLimit: {
      type: Number,
      required: true,
    },
    features: {
      sharing: {
        type: Boolean,
        default: false,
      },
      collaboration: {
        type: Boolean,
        default: false,
      },
      expirationDays: {
        type: Number,
        default: null,
      },
    },
    price: {
      type: Number,
      default: 0,
    },
    billingCycle: {
      type: String,
      enum: ["monthly", "yearly", null],
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Plan", planSchema);
