import mongoose from "mongoose";

const userPlanSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    planId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Plan",
      required: true,
    },
    startDate: {
      type: Date,
      default: Date.now,
    },
    endDate: {
      type: Date,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    autoRenew: {
      type: Boolean,
      default: false, 
    },
    paymentStatus: {
      type: String,
      enum: ["paid", "unpaid", "free"],
      default: "free",
    },
  },
  { timestamps: true }
);

// module.exports = mongoose.model("UserPlan", userPlanSchema);

const UserPlan = mongoose.model("UserPlan", userPlanSchema);
export default UserPlan;
