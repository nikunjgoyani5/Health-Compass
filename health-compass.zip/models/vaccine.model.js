import mongoose from "mongoose";

const mongooseSchema = new mongoose.Schema(
  {
    vaccineName: {
      type: String,
      default: null,
    },
    provider: {
      type: String,
      default: null,
    },
    description: {
      type: String,
      default: null,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    createdByAdmin: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

const VaccineModel = mongoose.model("Vaccine", mongooseSchema);
export default VaccineModel;
