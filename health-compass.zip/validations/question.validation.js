import Joi from "joi";

const optionsSchema = Joi.object({
  A: Joi.string().required(),
  B: Joi.string().required(),
  C: Joi.string().required(),
  D: Joi.string().required(),
});

const createQuestion = {
  body: Joi.object().keys({
    quiz: Joi.string().hex().length(24).required(),
    questionText: Joi.string().required(),
    options: optionsSchema.required(),
    correctAnswer: Joi.string().valid("A", "B", "C", "D").required(),
  }),
};

const updateQuestion = {
  body: Joi.object().keys({
    quiz: Joi.string().hex().length(24),
    questionText: Joi.string(),
    options: optionsSchema,
    correctAnswer: Joi.string().valid("A", "B", "C", "D"),
  }),
};

export default {
  createQuestion,
  updateQuestion,
};
