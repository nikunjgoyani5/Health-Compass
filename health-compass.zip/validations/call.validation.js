import Joi from "joi";

const validateTwilioCall = {
  body: Joi.object({
    CallSid: Joi.string().required(),
    From: Joi.string().required(),
    To: Joi.string().required(),
  }),
};

const validateWebRTCConnect = {
  body: Joi.object({
    callSid: Joi.string().required(),
    webRTCClientId: Joi.string().required(),
  }),
};

export default {
  validateTwilioCall,
  validateWebRTCConnect,
};
