import Joi from "joi";

const savePrivacySetting = {
  body: Joi.object().keys({
    enableDataSharing: Joi.boolean().required(),
    analyticsConsent: Joi.boolean().required(),
  }),
};

export default {
  savePrivacySetting,
};
