import Joi from "joi";
import enums from "../config/enum.config.js";

const sendRequest = {
  body: Joi.object().keys({
    receiver: Joi.string().required(),
  }),
};

const updateRequestStatus = {
  params: Joi.object().keys({
    requestId: Joi.string().required(),
  }),
  body: Joi.object().keys({
    status: Joi.string()
      .valid(
        enums.requestStatusEnum.PENDING,
        enums.requestStatusEnum.ACCEPTED,
        enums.requestStatusEnum.REJECTED
      )
      .required(),
  }),
};

export default {
  sendRequest,
  updateRequestStatus,
};
