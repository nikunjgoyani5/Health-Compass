import Joi from "joi";

const chatWithHealthBot = {
  body: Joi.object().keys({
    message: Joi.string().required(),
    chatId: Joi.string().optional(),
  }),
};

export default { chatWithHealthBot };