import { de } from "chrono-node";
import Joi from "joi";

const stringOrArray = Joi.alternatives().try(
  Joi.array().items(Joi.string()),
  Joi.string()
);

const updateDoctorDetails = {
  body: Joi.object().keys({
    fullName: Joi.string(),
    email: Joi.string().email(),
    experience: Joi.number(),
    phoneNumber: Joi.number(),
    profileImage: Joi.string(),
    description: Joi.string(),
    specialization: stringOrArray,
    qualifications: stringOrArray,
  }),
};

const addDoctor = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
    fullName: Joi.string().optional(),
    experience: Joi.number().optional(),
    phoneNumber: Joi.number().optional(),
    description: Joi.string().optional(),
    profileImage: Joi.string(),
    specialization: stringOrArray,
  }),
};

export default {
  addDoctor,
  updateDoctorDetails,
};
