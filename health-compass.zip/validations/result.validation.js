import Joi from "joi";

const submitAnswer = {
  body: Joi.object().keys({
    questionId: Joi.string().required(),
    selectedOption: Joi.string().required(),
  }),
};

export default {
  submitAnswer,
};
