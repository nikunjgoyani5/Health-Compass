import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const verifyToken = {
  body: Joi.object().keys({
    token: Joi.string().required(),
  }),
};

const registerByEmail = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
    fullName: Joi.string().required(),
    role: Joi.array(),
  }),
};

const verifyEmailOtp = {
  body: Joi.object().keys({
    otp: Joi.number().strict().required(),
    email: Joi.string().email().required(),
  }),
};

const resendEmailOtp = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const loginByEmail = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
    role: Joi.array(),
  }),
};

const forgotPassword = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const resetPassword = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
    newPassword: Joi.string().required(),
    conformNewPassword: Joi.string().valid(Joi.ref("newPassword")).required(),
  }),
};

const loginByGoogle = {
  body: Joi.object({
    email: Joi.string().required(),
    profileImage: Joi.string().optional(),
  }),
};

const verifyRecaptcha = {
  body: Joi.object().keys({
    token: Joi.string().required().messages({
      "string.base": "Recaptcha token must be a string",
      "any.required": "Recaptcha token is required",
      "string.empty": "Recaptcha token cannot be empty",
    }),
  }),
};

export default {
  verifyToken,
  registerByEmail,
  loginByEmail,
  forgotPassword,
  resendEmailOtp,
  verifyEmailOtp,
  resetPassword,
  loginByGoogle,
  verifyRecaptcha,
};
