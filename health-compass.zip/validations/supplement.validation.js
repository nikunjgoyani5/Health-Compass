import Joi from "joi";

const addNewSupplementValidation = {
  body: Joi.object().keys({
    medicineName: Joi.string().required().label("Medicine Name"),
    dosage: Joi.string().required().label("Dosage"),
    description: Joi.string().allow("").label("Description"),
    takenForSymptoms: Joi.string().allow("").label("Taken For Symptoms"),
    associatedRisks: Joi.string().allow("").label("Associated Risks"),
    price: Joi.number().strict().min(0).required().label("Price"),
    quantity: Joi.number()
      .strict()
      .integer()
      .min(1)
      .required()
      .label("Quantity"),
    singlePack: Joi.string().required().label("Single Pack"),
    mfgDate: Joi.date().required().label("MFG Date"),
    expDate: Joi.date()
      .greater(Joi.ref("mfgDate"))
      .required()
      .label("EXP Date"),
  }),
};

const updateSupplementValidation = {
  body: Joi.object().keys({
    medicineName: Joi.string(),
    dosage: Joi.string(),
    description: Joi.string().allow(""),
    takenForSymptoms: Joi.string().allow(""),
    associatedRisks: Joi.string().allow(""),
    price: Joi.number().min(0),
    quantity: Joi.number().integer().min(1),
    singlePack: Joi.string().allow(""),
    mfgDate: Joi.date(),
    expDate: Joi.date(),
  }),
};

const addQuantityValidation = {
  body: Joi.object().keys({
    quantity: Joi.number().integer().required(),
  }),
};

export default {
  addNewSupplementValidation,
  updateSupplementValidation,
  addQuantityValidation,
};
