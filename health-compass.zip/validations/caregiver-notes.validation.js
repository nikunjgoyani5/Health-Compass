import Joi from "joi";

const addNote = {
  body: Joi.object().keys({
    userId: Joi.string().required(),
    title: Joi.string().required(),
    note: Joi.string().required(),
  }),
};

export default {
  addNote,
};
