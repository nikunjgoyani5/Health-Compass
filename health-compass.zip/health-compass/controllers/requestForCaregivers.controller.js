import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import RequestModel from "../models/requestForCaregivers.model.js";
import UserModel from "../models/user.model.js";
import enums from "../config/enum.config.js";

export const socketHandler = (io, socket) => {
  const enrichUser = (user) => {
    return {
      _id: user._id,
      email: user.email,
      fullName: user.fullName,
      profileImage: user.profileImage,
      inviteCode: user.inviteCode,
    };
  };

  socket.on("request:send", async (data) => {
    try {
      const { receiverId } = data;
      const senderId = socket?.user?._id;

      if (receiverId === String(senderId)) {
        return socket.emit(
          "request:send:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.BAD_REQUEST,
            message: "You cannot send a caregiver request to yourself.",
          })
        );
      }

      const [sender, receiver] = await Promise.all([
        UserModel.findById(senderId).lean(),
        UserModel.findById(receiverId).lean(),
      ]);

      if (!sender || !receiver) {
        return socket.emit(
          "request:send:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.NOT_FOUND,
            message: "One of the users was not found.",
          })
        );
      }

      const alreadyExists =
        sender.iCareFor?.includes(receiver._id) ||
        receiver.myCaregivers?.includes(sender._id);

      if (alreadyExists) {
        return socket.emit(
          "request:send:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.CONFLICT,
            message: "You are already in a caregiver relationship.",
          })
        );
      }

      const existingRequest = await RequestModel.findOne({
        sender: senderId,
        receiver: receiverId,
        status: enums.requestStatusEnum.PENDING,
      });

      if (existingRequest) {
        return socket.emit(
          "request:send:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.CONFLICT,
            message: "Caregiver request already pending.",
          })
        );
      }

      const request = await RequestModel.create({
        sender: senderId,
        receiver: receiverId,
        status: enums.requestStatusEnum.PENDING,
      });

      const responsePayload = {
        _id: request._id,
        sender: enrichUser(sender),
        receiver: enrichUser(receiver),
        status: request.status,
        createdAt: request.createdAt,
      };

      socket.emit(
        "request:send:success",
        apiResponse({
          status: true,
          statusCode: StatusCodes.CREATED,
          message: "Caregiver request sent successfully.",
          data: responsePayload,
        })
      );

      io.to(receiverId.toString()).emit(
        "request:incoming",
        apiResponse({
          status: true,
          statusCode: StatusCodes.OK,
          message: "New caregiver request received.",
          data: responsePayload,
        })
      );
    } catch (err) {
      console.error("Caregiver request send error:", err);
      socket.emit(
        "request:send:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
          message: "Failed to send caregiver request.",
        })
      );
    }
  });

  socket.on("request:updateStatus", async (data) => {
    try {
      const { requestId, status } = data;
      const request = await RequestModel.findById(requestId);

      if (!request) {
        return socket.emit(
          "request:updateStatus:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.NOT_FOUND,
            message: "Request not found.",
          })
        );
      }

      if (request.status !== enums.requestStatusEnum.PENDING) {
        return socket.emit(
          "request:updateStatus:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.CONFLICT,
            message: `Request is already ${request.status.toLowerCase()}.`,
          })
        );
      }

      if (status === enums.requestStatusEnum.REJECTED) {
        await RequestModel.findByIdAndDelete(requestId);
        return socket.emit(
          "request:updateStatus:success",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Request rejected successfully.",
            data: { requestId },
          })
        );
      }

      if (status === enums.requestStatusEnum.ACCEPTED) {
        const [receiverUser, senderUser] = await Promise.all([
          UserModel.findById(request.receiver),
          UserModel.findById(request.sender),
        ]);

        if (!receiverUser || !senderUser) {
          return socket.emit(
            "request:updateStatus:error",
            apiResponse({
              status: false,
              statusCode: StatusCodes.NOT_FOUND,
              message: "One of the users was not found.",
            })
          );
        }

        if (!receiverUser.iCareFor.includes(senderUser._id)) {
          receiverUser.iCareFor.push(senderUser._id);
        }
        if (!senderUser.myCaregivers.includes(receiverUser._id)) {
          senderUser.myCaregivers.push(receiverUser._id);
        }

        await Promise.all([
          receiverUser.save(),
          senderUser.save(),
          RequestModel.findByIdAndDelete(requestId),
        ]);

        io.to(request.sender.toString()).emit(
          "request:accepted:notify",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Your caregiver request has been accepted!",
            data: { acceptedBy: enrichUser(receiverUser) },
          })
        );

        return socket.emit(
          "request:updateStatus:success",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Request accepted successfully.",
            data: { requestId },
          })
        );
      }

      socket.emit(
        "request:updateStatus:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.BAD_REQUEST,
          message: "Invalid request status update.",
        })
      );
    } catch (err) {
      console.error("Error updating request status:", err);
      socket.emit(
        "request:updateStatus:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
          message: "Failed to update request status.",
        })
      );
    }
  });

  socket.on("request:getAllPending", async () => {
    try {
      const userId = socket.user._id;
      const requests = await RequestModel.find({
        receiver: userId,
        status: enums.requestStatusEnum.PENDING,
      })
        .populate({
          path: "sender",
          select: "_id email fullName profileImage inviteCode",
        })
        .lean();

      const enriched = requests.map((req) => ({
        _id: req._id,
        sender: req.sender,
        status: req.status,
        createdAt: req.createdAt,
      }));

      socket.emit(
        "request:getAllPending:success",
        apiResponse({
          status: true,
          statusCode: StatusCodes.OK,
          message: "Pending requests fetched successfully.",
          data: enriched,
        })
      );
    } catch (err) {
      console.error("Error fetching pending requests:", err);
      socket.emit(
        "request:getAllPending:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
          message: "Failed to fetch pending requests.",
        })
      );
    }
  });

  // socket.on("user:getSuggestedUsers", async (data) => {
  //   try {
  //     const currentUserId = socket.user._id;
  //     const search = data?.search || "";

  //     const currentUser = await UserModel.findById(currentUserId)
  //       .select("myCaregivers iCareFor")
  //       .lean();

  //     if (!currentUser) {
  //       return socket.emit(
  //         "user:getSuggestedUsers:error",
  //         apiResponse({
  //           status: false,
  //           statusCode: StatusCodes.NOT_FOUND,
  //           message: "User not found.",
  //         })
  //       );
  //     }

  //     const caregiverUserIds = new Set([
  //       ...(currentUser.myCaregivers || []).map((id) => String(id)),
  //       ...(currentUser.iCareFor || []).map((id) => String(id)),
  //     ]);

  //     const pendingRequests = await RequestModel.find({
  //       $or: [{ sender: currentUserId }, { receiver: currentUserId }],
  //       status: enums.requestStatusEnum.PENDING,
  //     }).lean();

  //     const pendingUserIds = new Set();
  //     pendingRequests.forEach((req) => {
  //       pendingUserIds.add(String(req.sender));
  //       pendingUserIds.add(String(req.receiver));
  //     });

  //     let query = {
  //       _id: { $ne: currentUserId },
  //       is_deleted: false,
  //     };

  //     if (search.trim()) {
  //       query = {
  //         ...query,
  //         $or: [
  //           { fullName: { $regex: search.trim(), $options: "i" } },
  //           { email: { $regex: search.trim(), $options: "i" } },
  //         ],
  //       };
  //     }

  //     const users = await UserModel.find(query)
  //       .select("_id email fullName profileImage")
  //       .lean();

  //     const userIdsInDb = new Set(users.map((u) => String(u._id)));

  //     const missingCaregiverIds = Array.from(caregiverUserIds).filter(
  //       (id) => !userIdsInDb.has(id)
  //     );

  //     const missingCaregivers = missingCaregiverIds.length
  //       ? await UserModel.find({ _id: { $in: missingCaregiverIds } })
  //           .select("_id email fullName profileImage")
  //           .lean()
  //       : [];

  //     const combined = [...users, ...missingCaregivers];
  //     const uniqueUserMap = {};
  //     combined.forEach((user) => {
  //       const userIdStr = String(user._id);
  //       uniqueUserMap[userIdStr] = user;
  //     });
  //     const allUsers = Object.values(uniqueUserMap);

  //     const suggestedUsers = allUsers.map((user) => {
  //       const userIdStr = String(user._id);
  //       let relationshipStatus = "none";

  //       if (caregiverUserIds.has(userIdStr)) {
  //         relationshipStatus = "connected";
  //       } else if (pendingUserIds.has(userIdStr)) {
  //         relationshipStatus = "pending";
  //       }

  //       return {
  //         ...user,
  //         relationshipStatus,
  //       };
  //     });

  //     socket.emit(
  //       "user:getSuggestedUsers:success",
  //       apiResponse({
  //         status: true,
  //         statusCode: StatusCodes.OK,
  //         message: "Suggested users fetched successfully.",
  //         data: suggestedUsers,
  //       })
  //     );
  //   } catch (err) {
  //     socket.emit(
  //       "user:getSuggestedUsers:error",
  //       apiResponse({
  //         status: false,
  //         statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
  //         message: "Failed to fetch suggested users.",
  //       })
  //     );
  //   }
  // });

  socket.on("user:getSuggestedUsers", async (data) => {
  try {
    const currentUserId = socket.user._id;
    const search = data?.search || "";

    const currentUser = await UserModel.findById(currentUserId)
      .select("myCaregivers")
      .lean();

    if (!currentUser) {
      return socket.emit(
        "user:getSuggestedUsers:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.NOT_FOUND,
          message: "User not found.",
        })
      );
    }

    // ✅ Use only myCaregivers for showing "connected"
    const myCaregiverIds = new Set(
      (currentUser.myCaregivers || []).map((id) => String(id))
    );

    const pendingRequests = await RequestModel.find({
      $or: [{ sender: currentUserId }, { receiver: currentUserId }],
      status: enums.requestStatusEnum.PENDING,
    }).lean();

    const pendingUserIds = new Set();
    pendingRequests.forEach((req) => {
      pendingUserIds.add(String(req.sender));
      pendingUserIds.add(String(req.receiver));
    });

    let query = {
      _id: { $ne: currentUserId },
      is_deleted: false,
    };

    if (search.trim()) {
      query = {
        ...query,
        $or: [
          { fullName: { $regex: search.trim(), $options: "i" } },
          { email: { $regex: search.trim(), $options: "i" } },
        ],
      };
    }

    const users = await UserModel.find(query)
      .select("_id email fullName profileImage")
      .lean();

    const userIdsInDb = new Set(users.map((u) => String(u._id)));

    const missingCaregiverIds = Array.from(myCaregiverIds).filter(
      (id) => !userIdsInDb.has(id)
    );

    const missingCaregivers = missingCaregiverIds.length
      ? await UserModel.find({ _id: { $in: missingCaregiverIds } })
          .select("_id email fullName profileImage")
          .lean()
      : [];

    const combined = [...users, ...missingCaregivers];

    const uniqueUserMap = {};
    combined.forEach((user) => {
      const userIdStr = String(user._id);
      uniqueUserMap[userIdStr] = user;
    });

    const allUsers = Object.values(uniqueUserMap);

    const suggestedUsers = allUsers.map((user) => {
      const userIdStr = String(user._id);
      let relationshipStatus = "none";

      if (myCaregiverIds.has(userIdStr)) {
        relationshipStatus = "connected";
      } else if (pendingUserIds.has(userIdStr)) {
        relationshipStatus = "pending";
      }

      return {
        ...user,
        relationshipStatus,
      };
    });

    socket.emit(
      "user:getSuggestedUsers:success",
      apiResponse({
        status: true,
        statusCode: StatusCodes.OK,
        message: "Suggested users fetched successfully.",
        data: suggestedUsers,
      })
    );
  } catch (err) {
    socket.emit(
      "user:getSuggestedUsers:error",
      apiResponse({
        status: false,
        statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
        message: "Failed to fetch suggested users.",
      })
    );
  }
});


  socket.on("request:removeCaregiver", async (data) => {
    try {
      const { caregiverId } = data;
      const userId = socket?.user?._id;

      if (!caregiverId || !userId) {
        return socket.emit(
          "request:removeCaregiver:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.BAD_REQUEST,
            message: "Invalid caregiver or user ID.",
          })
        );
      }

      if (caregiverId === String(userId)) {
        return socket.emit(
          "request:removeCaregiver:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.BAD_REQUEST,
            message: "You cannot remove yourself.",
          })
        );
      }

      const [user, caregiver] = await Promise.all([
        UserModel.findById(userId),
        UserModel.findById(caregiverId),
      ]);

      if (!user || !caregiver) {
        return socket.emit(
          "request:removeCaregiver:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.NOT_FOUND,
            message: "One of the users was not found.",
          })
        );
      }

      const originalMyCaregivers = [...(user.myCaregivers || [])];
      const originalICareFor = [...(caregiver.iCareFor || [])];

      user.myCaregivers = user.myCaregivers.filter(
        (id) => id.toString() !== caregiverId.toString()
      );

      caregiver.iCareFor = caregiver.iCareFor.filter(
        (id) => id.toString() !== userId.toString()
      );

      const noChange =
        originalMyCaregivers.length === user.myCaregivers.length &&
        originalICareFor.length === caregiver.iCareFor.length;

      if (noChange) {
        return socket.emit(
          "request:removeCaregiver:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.NOT_FOUND,
            message: "No caregiver relationship found to remove.",
            data: null,
          })
        );
      }

      await Promise.all([user.save(), caregiver.save()]);

      // Notify both users
      socket.emit(
        "request:removeCaregiver:success",
        apiResponse({
          status: true,
          statusCode: StatusCodes.OK,
          message: "Caregiver removed successfully.",
          data: { caregiverId },
        })
      );

      io.to(caregiverId.toString()).emit(
        "request:removedByUser",
        apiResponse({
          status: true,
          statusCode: StatusCodes.OK,
          message: "You have been removed as a caregiver.",
          data: { removedBy: enrichUser(user) },
        })
      );
    } catch (err) {
      console.error("Error removing caregiver:", err);
      socket.emit(
        "request:removeCaregiver:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
          message: "Failed to remove caregiver.",
        })
      );
    }
  });
};
