import { StatusCodes } from "http-status-codes";
import VaccineSchedule from "../models/vaccine.schedule.model.js";
import { apiResponse } from "../helper/api-response.helper.js";
import enumConfig from "../config/enum.config.js";
import caregiverAccessUser from "../middleware/caregiver-access.middleware.js";
import VaccineModel from "../models/vaccine.model.js";
import commonHelper from "../helper/common.helper.js";
import moment from "moment";

// --- schedule vaccine ---
const scheduleVaccine = async (req, res) => {
  try {
    console.log("📥 Incoming Request Body:", req.body);
    console.log("🧑‍💼 Authenticated User:", req.user);
    const { vaccineId, date, doseTime } = req.body;
    

    const isFutureDateTime = commonHelper.validateFutureDateTime(
      date,
      doseTime
    );
    if (isFutureDateTime) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Please select a valid future date and time.",
      });
    }

    const findVaccine = await VaccineModel.findById(vaccineId);
    if (!findVaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine not found.",
      });
    }

    const findSchedule = await VaccineSchedule.findOne({
      vaccineId,
      scheduleBy: req.user._id,
      date,
      doseTime,
      scheduleStatus: enumConfig.scheduleStatusEnums.PENDING,
    });

    if (findSchedule) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine is already schedule by this user.",
      });
    }

    const newSchedule = {
      vaccineId,
      scheduleBy: req.user._id,
      date,
      doseTime,
      scheduleStatus: enumConfig.scheduleStatusEnums.PENDING,
    };

    const vaccineSchedule = await VaccineSchedule.create(newSchedule);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: vaccineSchedule,
      message: "Vaccine schedule successfully.",
    });
  } catch (error) {
    console.log(error);

    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

// --- get vaccine schedule ---
const getVaccineSchedule = async (req, res) => {
  try {
    const requesterId = req.user.id;
    const targetUserId = req.params.userId || req.query.userId || requesterId;

    console.log("🔍 Requester ID:", requesterId);
    console.log("🎯 Target User ID:", targetUserId);

    const hasAccess = await caregiverAccessUser(requesterId, targetUserId);
    console.log("🔐 Caregiver Access Granted:", hasAccess);

    if (!hasAccess) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.FORBIDDEN,
        message: "Access denied. You are not authorized to view this data.",
      });
    }

    const filter = { scheduleBy: targetUserId };

    const vaccineSchedule = await VaccineSchedule.find(filter)
      .populate("vaccineId", "vaccineName provider")
      .populate("scheduleBy", "fullName email profileImage")
      .sort({ createdAt: -1 });

    if (!vaccineSchedule || vaccineSchedule.length === 0) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine schedule not found.",
      });
    }

    console.log("💉 Vaccine Schedule Count:", vaccineSchedule.length);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: vaccineSchedule,
      message: "Vaccine schedule retrieved successfully.",
    });
  } catch (error) {
    console.error("❌ Error fetching vaccine schedule:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

// --- update schedule status ---
const updateScheduleStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { scheduleStatus } = req.body;

    const vaccine = await VaccineSchedule.findById(id);
    if (!vaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine not found.",
      });
    }

    if (vaccine.scheduleStatus === enumConfig.scheduleStatusEnums.MISSED) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message:
          "This dose was missed. Please ensure to take it at the next scheduled time.",
        status: false,
        data: null,
      });
    } else if (
      vaccine.scheduleStatus === enumConfig.scheduleStatusEnums.TAKEN
    ) {
      return apiResponse({
        res,
        statusCode: StatusCodes.BAD_REQUEST,
        message:
          "This dose has already been taken. You cannot update the status again.",
        status: false,
        data: null,
      });
    }

    vaccine.scheduleStatus = scheduleStatus;
    await vaccine.save();

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: vaccine,
      message: "Schedule status updated successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      message: "Internal server error.",
    });
  }
};

// --- delete vaccine schedule ---
const deleteVaccineSchedule = async (req, res) => {
  try {
    const { id } = req.params;
    const vaccineSchedule = await VaccineSchedule.findById(id);
    if (!vaccineSchedule) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        data: null,
        message: "Vaccine schedule not found.",
      });
    }

    await VaccineSchedule.findByIdAndDelete(id);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: null,
      message: "Vaccine schedule deleted successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Failed to delete vaccine schedule.",
    });
  }
};

// --- update vaccine schedule ---
const updateVaccineSchedule = async (req, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    const vaccineSchedule = await VaccineSchedule.findById(id);
    if (!vaccineSchedule) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        data: null,
        message: "Vaccine schedule not found.",
      });
    }

    // Validate future date and time if provided
    const dateToCheck = data.date || vaccineSchedule.date;
    const doseTimeToCheck = data.doseTime || vaccineSchedule.doseTime;

    const isFutureDateTime = commonHelper.validateFutureDateTime(
      dateToCheck,
      doseTimeToCheck
    );
    if (isFutureDateTime) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.BAD_REQUEST,
        message: "Please select a valid future date and time.",
      });
    }

    const checkFields = ["vaccineId", "date", "doseTime"];
    const isRelevantFieldChanged = checkFields.some(
      (field) => data[field] && data[field] !== vaccineSchedule[field]
    );

    if (isRelevantFieldChanged) {
      const findSchedule = await VaccineSchedule.findOne({
        vaccineId: data.vaccineId || vaccineSchedule.vaccineId,
        scheduleBy: vaccineSchedule.scheduleBy,
        date: dateToCheck,
        doseTime: doseTimeToCheck,
        scheduleStatus: enumConfig.scheduleStatusEnums.PENDING,
        _id: { $ne: id },
      });

      if (findSchedule) {
        return apiResponse({
          res,
          status: false,
          statusCode: StatusCodes.BAD_REQUEST,
          data: null,
          message:
            "A schedule with the same vaccine, date, and time already exists.",
        });
      }
    }

    const updatedVaccineSchedule = await VaccineSchedule.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true }
    );

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: updatedVaccineSchedule,
      message: "Vaccine schedule updated successfully.",
    });
  } catch (error) {
    console.error(error);
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

const getVaccineScheduleByDate = async (req, res) => {
  try {
    const { date } = req.query;

    if (!date) {
      return apiResponse({
        res,
        status: false,
        statusCode: 400,
        message: "Query param 'date' is required in YYYY-MM-DD format.",
      });
    }

    const start = new Date(date);
    start.setUTCHours(0, 0, 0, 0);

    const end = new Date(start);
    end.setUTCDate(end.getUTCDate() + 1);

    const filter = {
      scheduleBy: req.user._id,
      date: { $gte: start, $lt: end },
    };

    const schedules = await VaccineSchedule.find(filter)
      .populate("vaccineId", "vaccineName provider")
      .populate("scheduleBy", "fullName email profileImage")
      .sort({ doseTime: 1 });

    return apiResponse({
      res,
      status: true,
      statusCode: 200,
      data: schedules,
      message: "Vaccine schedule fetched successfully for selected date.",
    });
  } catch (error) {
    console.error("❌ Error fetching vaccine schedule by date:", error);
    return apiResponse({
      res,
      status: false,
      statusCode: 500,
      data: null,
      message: "Internal server error.",
    });
  }
};

const scheduleVaccineByBot = async (req, res) => {
  try {
    const { vaccineName, date, doseTime } = req.body;

    const findVaccine = await VaccineModel.findOne({
      vaccineName: vaccineName,
    });
    if (!findVaccine) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine not found.",
      });
    }

    const findSchedule = await VaccineSchedule.findOne({
      vaccineId: findVaccine._id,
      scheduleBy: req.user._id,
      date,
      doseTime,
      scheduleStatus: enumConfig.scheduleStatusEnums.PENDING,
    });

    if (findSchedule) {
      return apiResponse({
        res,
        status: false,
        statusCode: StatusCodes.NOT_FOUND,
        message: "Vaccine is already schedule by this user.",
      });
    }

    const newSchedule = {
      vaccineId: findVaccine._id,
      scheduleBy: req.user._id,
      date,
      doseTime,
      scheduleStatus: enumConfig.scheduleStatusEnums.PENDING,
    };

    const vaccineSchedule = await VaccineSchedule.create(newSchedule);

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.CREATED,
      data: vaccineSchedule,
      message: "Vaccine schedule successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

const getTodayVaccineSchedules = async (req, res) => {
  try {
    const startOfDay = moment().startOf("day").toDate();
    const endOfDay = moment().endOf("day").toDate();

    const schedules = await VaccineSchedule.find({
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("vaccineId", "vaccineName provider")
      .populate("scheduleBy", "email fullName profileImage")
      .select("-isReminderSent -createdAt -updatedAt")
      .sort({ createdAt: -1 });

    return apiResponse({
      res,
      status: true,
      statusCode: StatusCodes.OK,
      data: schedules,
      message: "Today's vaccine schedules retrieved successfully.",
    });
  } catch (error) {
    return apiResponse({
      res,
      status: false,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      data: null,
      message: "Internal server error.",
    });
  }
};

export default {
  scheduleVaccine,
  getVaccineSchedule,
  updateScheduleStatus,
  updateVaccineSchedule,
  deleteVaccineSchedule,
  getVaccineScheduleByDate,
  scheduleVaccineByBot,
  getTodayVaccineSchedules,
};
