import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import UserModel from "../models/user.model.js";
import enumConfig from "../config/enum.config.js";
import moment from "moment";
import Telemedicine from "../models/telemedicine.model.js";
import MedicineScheduleModel from "../models/medicine.schedual.model.js";
import VaccineSchedule from "../models/vaccine.schedule.model.js";
import Supplement from "../models/supplement.model.js";

const getDashboard = async (req, res) => {
  try {
    const role = req.user.role;
    const loginUserId = req.user._id;

    const todayStart = moment().startOf("day").toDate(); // 2025-05-10T00:00:00.000Z
    const todayEnd = moment().endOf("day").toDate(); // 2025-05-10T23:59:59.999Z

    // --- Admin Dashboard ---
    if (role === role?.includes(enumConfig.userRoleEnum.ADMIN)) {
      const countActiveUsers = await UserModel.countDocuments({
        role: { $in: [enumConfig.userRoleEnum.USER] },
        is_deleted: false,
        is_verified: true,
      });

      const countInActiveUsers = await UserModel.countDocuments({
        role: { $in: [enumConfig.userRoleEnum.USER] },
        is_deleted: true,
      });

      const totalUsers = countActiveUsers + countInActiveUsers;

      const totalActiveCaregivers = await UserModel.countDocuments({
        role: { $in: [enumConfig.userRoleEnum.CAREGIVER] },
        is_deleted: false,
      });

      const totalDoctors = await UserModel.countDocuments({
        role: { $in: [enumConfig.userRoleEnum.DOCTOR] },
        is_deleted: false,
      });

      const todaysDoctorAppointments = await Telemedicine.find({
        appointmentDate: { $gte: todayStart, $lte: todayEnd },
      })
        .populate("doctorId", "fullName email")
        .populate("userId", "fullName");

      const totalAppointments = await Telemedicine.countDocuments({});
      const totalSuppliments = await Supplement.countDocuments({});

      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "Dashboard data fetched successfully",
        data: {
          totalUsers,
          countActiveUsers,
          countInActiveUsers,
          totalActiveCaregivers,
          totalDoctors,
          totalAppointments,
          totalSuppliments,
          todaysDoctorAppointments,
        },
      });
    }

    // --- User Dashboard ---
    if (role === role?.includes(enumConfig.userRoleEnum.USER)) {
      const [medicineSchedule, vaccineSchedule, appointmentSchedule] =
        await Promise.all([
          MedicineScheduleModel.find({
            userId: loginUserId,
            startDate: { $lte: todayEnd },
            endDate: { $gte: todayStart },
          }),
          VaccineSchedule.find({
            userId: loginUserId,
            date: { $gte: todayStart, $lte: todayEnd },
          }),
          Telemedicine.find({
            userId: loginUserId,
            appointmentDate: { $gte: todayStart, $lte: todayEnd },
          }).populate("doctorId", "fullName"),
        ]);

      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "Dashboard data fetched successfully",
        data: {
          medicineSchedule,
          vaccineSchedule,
          appointmentSchedule,
        },
      });
    }

    // --- Doctor Dashboard ---
    if (role === role?.includes(enumConfig.userRoleEnum.DOCTOR)) {
      const doctorAppointmentsToday = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        appointmentDate: { $gte: todayStart, $lte: todayEnd },
      });

      const schedualAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.SCHEDULED,
      });

      const confirmAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.CONFIRM,
      });

      const ongoingAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.STARTED,
      });

      const completedAppointment = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.COMPLETED,
      });

      const cancelledAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.CANCELLED,
      });

      const missedAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
        status: enumConfig.appointmentStatusEnums.MISSED,
      });

      const totalAppointments = await Telemedicine.countDocuments({
        doctorId: loginUserId,
      });

      const topMedicines = await MedicineScheduleModel.aggregate([
        {
          $group: {
            _id: "$medicineName",
            count: { $sum: 1 },
          },
        },
        {
          $sort: { count: -1 },
        },
        {
          $limit: 6,
        },
        {
          $lookup: {
            from: "supplements",
            localField: "_id",
            foreignField: "_id",
            as: "medicineData",
          },
        },
        {
          $unwind: "$medicineData",
        },
        {
          $project: {
            count: 1,
            medicineName: "$medicineData.medicineName",
            dosage: "$medicineData.dosage",
            description: "$medicineData.description",
            takenForSymptoms: "$medicineData.takenForSymptoms",
            associatedRisks: "$medicineData.associatedRisks",
            expDate: "$medicineData.expDate",
          },
        },
      ]);

      const todaysExpiringMedicines = await Supplement.find({
        expDate: {
          $gte: todayStart,
          $lte: todayEnd,
        },
      }).select(
        "medicineName dosage description takenForSymptoms associatedRisks expDate"
      );

      const todaysDoctorAppointments = await Telemedicine.find({
        doctorId: loginUserId,
        appointmentDate: { $gte: todayStart, $lte: todayEnd },
      })
        .populate("doctorId", "fullName email")
        .populate("userId", "fullName");

      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "Doctor dashboard data fetched successfully",
        data: {
          schedualAppointments,
          confirmAppointments,
          ongoingAppointments,
          doctorAppointmentsToday,
          completedAppointment,
          cancelledAppointments,
          missedAppointments,
          totalAppointments,
          mostPrescribedMedicine: topMedicines || [],
          todaysExpiringMedicines: todaysExpiringMedicines || [],
          todaysDoctorAppointments: todaysDoctorAppointments || [],
        },
      });
    }

    return apiResponse({
      res,
      statusCode: StatusCodes.FORBIDDEN,
      status: false,
      message: "Unauthorized role",
      data: null,
    });
  } catch (error) {
    console.log(error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
      data: null,
    });
  }
};

export const socketForGetDashboard = (io, socket) => {
  socket.on("dashboard:get", async () => {
    try {
      const role = socket?.user?.role;
      const loginUserId = socket?.user?._id;

      const todayStart = moment().startOf("day").toDate();
      const todayEnd = moment().endOf("day").toDate();

      if (!role || !loginUserId) {
        return socket.emit(
          "dashboard:get:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.UNAUTHORIZED,
            message: "Unauthorized access.",
          })
        );
      }

      const isExist = await UserModel.findOne({ _id: loginUserId, role: role });
      if (!isExist) {
        return socket.emit(
          "dashboard:get:error",
          apiResponse({
            status: false,
            statusCode: StatusCodes.NOT_FOUND,
            message: `${role} not found.`,
          })
        );
      }

      if (role === role?.includes(enumConfig.userRoleEnum.ADMIN)) {
        const [
          countActiveUsers,
          countInActiveUsers,
          totalActiveCaregivers,
          totalDoctors,
          totalAppointments,
          totalSuppliments,
          todaysDoctorAppointments,
        ] = await Promise.all([
          UserModel.countDocuments({
            role: { $in: [enumConfig.userRoleEnum.USER] },
            is_deleted: false,
            is_verified: true,
          }),
          UserModel.countDocuments({
            role: { $in: [enumConfig.userRoleEnum.USER] },
            is_deleted: true,
          }),
          UserModel.countDocuments({
            role: { $in: [enumConfig.userRoleEnum.CAREGIVER] },
            is_deleted: false,
          }),
          UserModel.countDocuments({
            role: { $in: [enumConfig.userRoleEnum.DOCTOR] },
            is_deleted: false,
          }),
          Telemedicine.countDocuments({}),
          Supplement.countDocuments({}),
          Telemedicine.find({
            appointmentDate: { $gte: todayStart, $lte: todayEnd },
          })
            .populate("doctorId", "fullName email")
            .populate("userId", "fullName"),
        ]);

        return socket.emit(
          "dashboard:get:success",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Dashboard data fetched successfully",
            data: {
              totalUsers: countActiveUsers + countInActiveUsers,
              countActiveUsers,
              countInActiveUsers,
              totalActiveCaregivers,
              totalDoctors,
              totalAppointments,
              totalSuppliments,
              todaysDoctorAppointments,
            },
          })
        );
      }

      if (role === role?.includes(enumConfig.userRoleEnum.USER)) {
        const [medicineSchedule, vaccineSchedule, appointmentSchedule] =
          await Promise.all([
            MedicineScheduleModel.find({
              userId: loginUserId,
              startDate: { $lte: todayEnd },
              endDate: { $gte: todayStart },
            }),
            VaccineSchedule.find({
              userId: loginUserId,
              date: { $gte: todayStart, $lte: todayEnd },
            }),
            Telemedicine.find({
              userId: loginUserId,
              appointmentDate: { $gte: todayStart, $lte: todayEnd },
            }).populate("doctorId", "fullName"),
          ]);

        return socket.emit(
          "dashboard:get:success",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Dashboard data fetched successfully",
            data: {
              medicineSchedule,
              vaccineSchedule,
              appointmentSchedule,
            },
          })
        );
      }

      if (role === role?.includes(enumConfig.userRoleEnum.DOCTOR)) {
        const [
          doctorAppointmentsToday,
          schedualAppointments,
          completedAppointment,
          cancelledAppointments,
          missedAppointments,
          totalAppointments,
          topMedicines,
          todaysExpiringMedicines,
          todaysDoctorAppointments,
        ] = await Promise.all([
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            appointmentDate: { $gte: todayStart, $lte: todayEnd },
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.SCHEDULED,
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.CONFIRM,
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.STARTED,
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.COMPLETED,
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.CANCELLED,
          }),
          Telemedicine.countDocuments({
            doctorId: loginUserId,
            status: enumConfig.appointmentStatusEnums.MISSED,
          }),
          Telemedicine.countDocuments({ doctorId: loginUserId }),
          MedicineScheduleModel.aggregate([
            {
              $group: {
                _id: "$medicineName",
                count: { $sum: 1 },
              },
            },
            { $sort: { count: -1 } },
            { $limit: 6 },
            {
              $lookup: {
                from: "supplements",
                localField: "_id",
                foreignField: "_id",
                as: "medicineData",
              },
            },
            { $unwind: "$medicineData" },
            {
              $project: {
                count: 1,
                medicineName: "$medicineData.medicineName",
                dosage: "$medicineData.dosage",
                description: "$medicineData.description",
                takenForSymptoms: "$medicineData.takenForSymptoms",
                associatedRisks: "$medicineData.associatedRisks",
                expDate: "$medicineData.expDate",
              },
            },
          ]),
          Supplement.find({
            expDate: { $gte: todayStart, $lte: todayEnd },
          }).select(
            "medicineName dosage description takenForSymptoms associatedRisks expDate"
          ),
          Telemedicine.find({
            doctorId: loginUserId,
            appointmentDate: { $gte: todayStart, $lte: todayEnd },
          })
            .populate("doctorId", "fullName email")
            .populate("userId", "fullName"),
        ]);

        return socket.emit(
          "dashboard:get:success",
          apiResponse({
            status: true,
            statusCode: StatusCodes.OK,
            message: "Doctor dashboard data fetched successfully",
            data: {
              schedualAppointments,
              doctorAppointmentsToday,
              completedAppointment,
              cancelledAppointments,
              missedAppointments,
              totalAppointments,
              mostPrescribedMedicine: topMedicines,
              todaysExpiringMedicines,
              todaysDoctorAppointments,
            },
          })
        );
      }

      return socket.emit(
        "dashboard:get:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.FORBIDDEN,
          message: "Unauthorized role",
        })
      );
    } catch (error) {
      console.error(error);
      return socket.emit(
        "dashboard:get:error",
        apiResponse({
          status: false,
          statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
          message: "Internal server error",
        })
      );
    }
  });
};

export default {
  getDashboard,
};
