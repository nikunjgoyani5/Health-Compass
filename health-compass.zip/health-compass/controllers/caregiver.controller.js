import { StatusCodes } from "http-status-codes";
import { apiResponse } from "../helper/api-response.helper.js";
import UserModel from "../models/user.model.js";
import helper from "../helper/common.helper.js";

// ------------------------ get my caregivers
// const getMyCaregivers = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { search = "", page = 1, limit = 10 } = req.query;

//     const user = await UserModel.findById(userId).lean();

//     if (!user || !user.myCaregivers?.length) {
//       return apiResponse({
//         res,
//         statusCode: StatusCodes.OK,
//         status: true,
//         message: "No caregivers found.",
//         data: [],
//         pagination: {
//           total: 0,
//           page: Number(page),
//           limit: Number(limit),
//         },
//       });
//     }

//     const searchQuery = {
//       _id: { $in: user.myCaregivers },
//       is_deleted: false,
//     };

//     if (search.trim()) {
//       searchQuery.$or = [
//         { fullName: { $regex: search.trim(), $options: "i" } },
//         { email: { $regex: search.trim(), $options: "i" } },
//         { phoneNumber: { $regex: search.trim(), $options: "i" } },
//       ];
//     }

//     const total = await UserModel.countDocuments(searchQuery);

//     let caregivers = await UserModel.find(searchQuery)
//       .sort({ createdAt: -1 })
//       .skip((page - 1) * limit)
//       .limit(Number(limit))
//       .lean();

//     for (let caregiver of caregivers) {
//       if (caregiver.iCareFor?.length) {
//         const enrichedICareFor = await UserModel.find({
//           _id: { $in: caregiver.iCareFor },
//         })
//           .select("_id email fullName profileImage inviteCode")
//           .lean();

//         caregiver.iCareFor = enrichedICareFor;
//       } else {
//         caregiver.iCareFor = [];
//       }

//       delete caregiver.password;
//       delete caregiver.recoveryCode;
//     }

//     return apiResponse({
//       res,
//       statusCode: StatusCodes.OK,
//       status: true,
//       message: "Caregivers fetched successfully.",
//       data: caregivers,
//       pagination: {
//         total,
//         page: Number(page),
//         limit: Number(limit),
//       },
//     });
//   } catch (error) {
//     console.error("Error fetching caregivers:", error);
//     return apiResponse({
//       res,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       status: false,
//       message: "Internal server error",
//     });
//   }
// };


const getMyCaregivers = async (req, res) => {
  try {
    const userId = req.user.id;
    const { search = "" } = req.query;

    const pagination = helper.paginationFun(req.query);

    const user = await UserModel.findById(userId).lean();

    if (!user || !user.myCaregivers?.length) {
      const paginationData = helper.paginationDetails({
        limit: pagination.limit,
        page: req.query.page,
        totalItems: 0,
      });

      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "No caregivers found.",
        data: [],
        pagination: paginationData,
      });
    }

    const searchQuery = {
      _id: { $in: user.myCaregivers },
      is_deleted: false,
    };

    if (search.trim()) {
      searchQuery.$or = [
        { fullName: { $regex: search.trim(), $options: "i" } },
        { email: { $regex: search.trim(), $options: "i" } },
        { phoneNumber: { $regex: search.trim(), $options: "i" } },
      ];
    }

    const total = await UserModel.countDocuments(searchQuery);

    const caregivers = await UserModel.find(searchQuery)
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit)
      .lean();

    for (let caregiver of caregivers) {
      if (caregiver.iCareFor?.length) {
        caregiver.iCareFor = await UserModel.find({
          _id: { $in: caregiver.iCareFor },
        }).select("_id email fullName profileImage inviteCode").lean();
      } else {
        caregiver.iCareFor = [];
      }

      delete caregiver.password;
      delete caregiver.recoveryCode;
    }

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: total,
    });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Caregivers fetched successfully.",
      data: caregivers,
      pagination: paginationData,
    });
  } catch (error) {
    console.error("Error fetching caregivers:", error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
    });
  }
};



// ------------------------ get i care for
// const getICareFor = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { search = "", page = 1, limit = 10 } = req.query;

//     const user = await UserModel.findById(userId).lean();

//     if (!user || !user.iCareFor?.length) {
//       return apiResponse({
//         res,
//         statusCode: StatusCodes.OK,
//         status: true,
//         message: "No users you care for found.",
//         data: [],
//         pagination: {
//           total: 0,
//           page: Number(page),
//           limit: Number(limit),
//         },
//       });
//     }

//     const searchQuery = {
//       _id: { $in: user.iCareFor },
//       is_deleted: false,
//     };

//     if (search.trim()) {
//       searchQuery.$or = [
//         { fullName: { $regex: search.trim(), $options: "i" } },
//         { email: { $regex: search.trim(), $options: "i" } },
//         { phoneNumber: { $regex: search.trim(), $options: "i" } },
//       ];
//     }

//     const total = await UserModel.countDocuments(searchQuery);

//     let caredUsers = await UserModel.find(searchQuery)
//       .sort({ createdAt: -1 })
//       .skip((page - 1) * limit)
//       .limit(Number(limit))
//       .lean();

//     for (let user of caredUsers) {
//       if (user.myCaregivers?.length) {
//         const enrichedCaregivers = await UserModel.find({
//           _id: { $in: user.myCaregivers },
//         })
//           .select("_id email fullName profileImage inviteCode")
//           .lean();

//         user.myCaregivers = enrichedCaregivers;
//       } else {
//         user.myCaregivers = [];
//       }

//       delete user.password;
//       delete user.recoveryCode;
//     }

//     return apiResponse({
//       res,
//       statusCode: StatusCodes.OK,
//       status: true,
//       message: "Users you care for fetched successfully.",
//       data: caredUsers,
//       pagination: {
//         total,
//         page: Number(page),
//         limit: Number(limit),
//       },
//     });
//   } catch (error) {
//     console.error("Error fetching iCareFor:", error);
//     return apiResponse({
//       res,
//       statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
//       status: false,
//       message: "Internal server error",
//     });
//   }
// };

const getICareFor = async (req, res) => {
  try {
    const userId = req.user.id;
    const { search = "" } = req.query;

    const pagination = helper.paginationFun(req.query);

    const user = await UserModel.findById(userId).lean();

    if (!user || !user.iCareFor?.length) {
      const paginationData = helper.paginationDetails({
        limit: pagination.limit,
        page: req.query.page,
        totalItems: 0,
      });

      return apiResponse({
        res,
        statusCode: StatusCodes.OK,
        status: true,
        message: "No users you care for found.",
        data: [],
        pagination: paginationData,
      });
    }

    const searchQuery = {
      _id: { $in: user.iCareFor },
      is_deleted: false,
    };

    if (search.trim()) {
      searchQuery.$or = [
        { fullName: { $regex: search.trim(), $options: "i" } },
        { email: { $regex: search.trim(), $options: "i" } },
        { phoneNumber: { $regex: search.trim(), $options: "i" } },
      ];
    }

    const total = await UserModel.countDocuments(searchQuery);

    const caredUsers = await UserModel.find(searchQuery)
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit)
      .lean();

    for (let user of caredUsers) {
      if (user.myCaregivers?.length) {
        user.myCaregivers = await UserModel.find({
          _id: { $in: user.myCaregivers },
        }).select("_id email fullName profileImage inviteCode").lean();
      } else {
        user.myCaregivers = [];
      }

      delete user.password;
      delete user.recoveryCode;
    }

    const paginationData = helper.paginationDetails({
      limit: pagination.limit,
      page: req.query.page,
      totalItems: total,
    });

    return apiResponse({
      res,
      statusCode: StatusCodes.OK,
      status: true,
      message: "Users you care for fetched successfully.",
      data: caredUsers,
      pagination: paginationData,
    });
  } catch (error) {
    console.error("Error fetching iCareFor:", error);
    return apiResponse({
      res,
      statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
      status: false,
      message: "Internal server error",
    });
  }
};



export default {
  getMyCaregivers,
  getICareFor,
};  
