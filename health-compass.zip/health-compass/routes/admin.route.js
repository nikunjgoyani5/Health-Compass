import express from "express";
import validate from "../middleware/validate.middleware.js";
import userValidation from "../validations/user.validation.js";
import { verifyToken } from "../middleware/verify-token.middleware.js";
import { checkPermission } from "../middleware/verify-role.middleware.js";
import enumConfig from "../config/enum.config.js";
import controller from "../controllers/admin.controller.js";

const route = express.Router();

// ---------------------------------------------- Profile Management For Users ----------------------------------------------
route.get(
  "/get-all-user-profile",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getAllUserProfile
);
route.patch(
  "/assigned-role",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  validate(userValidation.assignRoleToUser),
  controller.assignRoleToUser
);
route.delete(
  "/remove-role",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  validate(userValidation.removeRoleFromUser),
  controller.removeRoleFromUser
);
route.patch(
  "/:id/block",
  verifyToken,
  checkPermission([
    enumConfig.userRoleEnum.ADMIN,
    enumConfig.userRoleEnum.SUPERADMIN,
  ]),
  validate(userValidation.blockAndUnblockUser),
  controller.blockAndUnblockUserProfile
);

// ---------------------------------------------- Get Schedule By Admin ----------------------------------------------
route.get(
  "/medicine-schedules",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getUserMedicineSchedules
);
route.get(
  "/vaccine-schedules",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getUserVaccineSchedules
);

// ---------------------------------------------- Doctor Availability By Admin ----------------------------------------------
route.get(
  "/doctor-availability",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getDoctorAvailability
);

// ---------------------------------------------- Appointments By Admin ----------------------------------------------
route.get(
  "/telemedicine-appointments",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getTelemedicineAppointments
);

// ---------------------------------------------- Medicine Usage By Admin ----------------------------------------------
route.get(
  "/medicine-usage",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getMedicineUsageByAdmin
);

// ---------------------------------------------- Vaccine Usage By Admin ----------------------------------------------
route.get(
  "/vaccine-usage",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  controller.getVaccineUsageByAdmin
);

export default route;
