import express from "express";
import { verifyToken } from "../middleware/verify-token.middleware.js";
import controller from "../controllers/userActivity.controller.js";

const route = express.Router();

route.get("/",
    verifyToken,
    controller.getActivityByUser
);

export default route;