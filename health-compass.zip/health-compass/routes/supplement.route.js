import express from "express";
import supplementController from "../controllers/supplement.controller.js";
import supplementValidation from "../validations/supplement.validation.js";
import { verifyToken } from "../middleware/verify-token.middleware.js";
import validate from "../middleware/validate.middleware.js";
import multer from "multer";
import path from "path";
import { checkPermission } from "../middleware/verify-role.middleware.js";
import enumConfig from "../config/enum.config.js";

const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname);
  if (ext !== ".csv" && ext !== ".xls" && ext !== ".xlsx") {
    return cb(new Error("Only CSV, XLS, and XLSX files are allowed"), false);
  }
  cb(null, true);
};

const upload = multer({ storage, fileFilter });
const uploadJson = multer({ dest: "uploads/" });

const route = express.Router();

route.get("/list", verifyToken, supplementController.getAllSupplements);
route.get("/stock-status", verifyToken, supplementController.getStockStatus);
route.get("/:id", verifyToken, supplementController.getSingleSupplement);

route.post(
  "/add",
  verifyToken,
  checkPermission([
    enumConfig.userRoleEnum.ADMIN,
    enumConfig.userRoleEnum.USER,
  ]),
  validate(supplementValidation.addNewSupplementValidation),
  supplementController.createSupplement
);

route.put("/update/:id", verifyToken, supplementController.updateSupplement);

route.patch(
  "/add/:id/quantity",
  verifyToken,
  validate(supplementValidation.addQuantityValidation),
  supplementController.addQuantity
);

route.delete("/delete/:id", verifyToken, supplementController.deleteSupplement);

route.post(
  "/bulk-import",
  verifyToken,
  upload.single("file"),
  supplementController.bulkImportSupplements
);

route.post(
  "/import-json",
  verifyToken,
  uploadJson.single("file"),
  supplementController.importSupplimentFromJSON
);

route.delete(
  "/bulk-delete",
  verifyToken,
  checkPermission([enumConfig.userRoleEnum.ADMIN]),
  supplementController.bulkDeleteSupplements
);

export default route;
