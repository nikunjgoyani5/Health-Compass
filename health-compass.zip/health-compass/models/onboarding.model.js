import mongoose from "mongoose";
import enumConfig from "../config/enum.config.js";

const onboardingSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    age: { type: Number },
    gender: { type: String, enum: Object.values(enumConfig.genderEnums) },
    weightKg: { type: Number },
    heightCm: { type: Number },
    goal: {
      type: String,
      enum: Object.values(enumConfig.goalEnums),
    },
    activityLevel: {
      type: String,
      enum: Object.values(enumConfig.activityLevelEnums),
    },
  },
  { timestamps: true }
);

const Onboarding = mongoose.model("Onboarding", onboardingSchema);
export default Onboarding;
