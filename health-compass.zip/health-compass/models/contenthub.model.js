import mongoose from "mongoose";
import enumConfig from "../config/enum.config.js";

const contentHubSchema = new mongoose.Schema(
  {
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    type: {
      type: String,
      enum: Object.values(enumConfig.contentHubTypeEnums),
    },

    // Common Fields
    title: { type: String, default: null },
    description: { type: String, default: null },
    image: { type: String, default: null },
    video: { type: String, default: null },

    // LatestArticles Specific
    shortDescription: { type: String, default: null },
    blogBody: { type: String, default: null },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },

    // CommunitySuccessStories Specific
    communityName: { type: String, default: null },
    communityStatus: { type: String, default: null },

    // Health Q&A
    question: { type: String },
    answer: { type: String },
  },
  { timestamps: true }
);

const ContentHubModel = mongoose.model("ContentHub", contentHubSchema);
export default ContentHubModel;
