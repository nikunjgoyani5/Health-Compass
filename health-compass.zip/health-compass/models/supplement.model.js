import mongoose from "mongoose";

const SupplementSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    medicineName: { type: String, required: true },
    dosage: { type: String, required: true },
    description: { type: String },
    takenForSymptoms: { type: String },
    associatedRisks: { type: String },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
    singlePack: { type: String, required: true },
    mfgDate: { type: Date, required: true },
    expDate: { type: Date, required: true },
    createdByAdmin: {
      type: Boolean,
      default: false,
    }
  },
  { timestamps: true }
);

const Supplement = mongoose.model("Supplement", SupplementSchema);
export default Supplement;
