import moment from 'moment';
import mongoose from 'mongoose';

const singleActivitySchema = new mongoose.Schema(
  {
    activityType: {
      type: String,
      required: true
    },
    description: {
      type: String
    },
    activityData: {
      type: Object,
      default: {}
    },
    status: {
      type: Boolean,
      default: false
    },
    error: {
      type: String
    },
    errorMessage: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    },
    createdAt: {
      type: String,
      default: moment().format("YYYY-MM-DDTHH:mm:ss.SSSZ")
    }
  },
  { _id: false }
);

const activitySchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      default: null
    },
    email: {
      type: String,
      required: false,
      default: null
    },
    lastLogin: {
      type: String
    },
    activities: {
      type: Map,
      of: [singleActivitySchema],
      default: {}
    }
  },
  { timestamps: true }
);

const activityModel = mongoose.model('Activity', activitySchema);
export default activityModel;
