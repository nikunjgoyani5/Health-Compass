import Joi from "joi";

const createQuiz = {
  body: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().required(),
    totalQuestions: Joi.number().integer().min(1).required(),
    timeLimit: Joi.number().integer().min(1).required(), // in seconds
  }),
};

const updateQuiz = {
  body: Joi.object().keys({
    title: Joi.string(),
    description: Joi.string(),
    totalQuestions: Joi.number().integer().min(1),
    timeLimit: Joi.number().integer().min(1),
  }),
};

export default {
  createQuiz,
  updateQuiz,
};
