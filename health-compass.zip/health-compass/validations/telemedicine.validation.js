import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const createTelemedicineDetail = {
  body: Joi.object().keys({
    appointmentDate: Joi.date().required(),
    appointmentStartTime: Joi.string().required(),
    appointmentEndTime: Joi.string().required(),
    doctorId: Joi.string().required(),
    notes: Joi.string().allow(null, ""),
    videoCall: Joi.object().keys({
      link: Joi.string().allow(null, ""),
      startedAt: Joi.date().allow(null),
      endedAt: Joi.date().allow(null),
      durationMinutes: Joi.number().allow(null),
      wasSuccessful: Joi.boolean(),
    }),
    appointmentType: Joi.valid(
      ...Object.values(enumConfig.appointmentTypeEnums)
    ).required(),
    reasonForAppointment: Joi.valid(
      ...Object.values(enumConfig.reasonForAppointmentEnums)
    ).required(),
    status: Joi.valid(
      ...Object.values(enumConfig.appointmentStatusEnums)
    ).default(enumConfig.appointmentStatusEnums.SCHEDULED),
  }),
};

const updateTelemedicineDetail = {
  body: Joi.object().keys({
    appointmentDate: Joi.date(),
    appointmentStartTime: Joi.string(),
    appointmentEndTime: Joi.string(),
    doctorId: Joi.string(),
    notes: Joi.string().allow(null, ""),
    videoCall: Joi.object().keys({
      link: Joi.string().allow(null, ""),
      startedAt: Joi.date().allow(null),
      endedAt: Joi.date().allow(null),
      durationMinutes: Joi.number().allow(null),
      wasSuccessful: Joi.boolean(),
    }),
    appointmentType: Joi.valid(
      ...Object.values(enumConfig.appointmentTypeEnums)
    ),
    reasonForAppointment: Joi.valid(
      ...Object.values(enumConfig.reasonForAppointmentEnums)
    ),
    status: Joi.valid(...Object.values(enumConfig.appointmentStatusEnums)),
  }),
};

const updateStatus = {
  body: Joi.object().keys({
    status: Joi.valid(
      ...Object.values(enumConfig.appointmentStatusEnums)
    ).required(),
  }),
};

export default {
  createTelemedicineDetail,
  updateTelemedicineDetail,
  updateStatus,
};
