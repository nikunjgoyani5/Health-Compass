import Joi from "joi";

const saveHealthGoal = {
  body: Joi.object().keys({
    dailySteps: Joi.number().min(0).required(),
    calories: Joi.number().min(0).required(),
    waterIntake: Joi.number().min(0).required(),
    sleepTarget: Joi.number().min(0).max(24).required(),
    weightTarget: Joi.number().min(0).required(),
    enableGamification: Joi.boolean().required(),
  }),
};

export default {
    saveHealthGoal
};
