import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const scheduleVaccine = {
  body: Joi.object().keys({
    vaccineId: Joi.string().required(),
    date: Joi.date().required(),
    doseTime: Joi.string().required(),
    reactionDetail: Joi.string().allow(null, ""),
    scheduleStatus: Joi.string()
      .valid(...Object.values(enumConfig.scheduleStatusEnums))
      .default(enumConfig.scheduleStatusEnums.PENDING),
  }),
};

const updateSchedule = {
  body: Joi.object().keys({
    vaccineId: Joi.string(),
    date: Joi.date(),
    doseTime: Joi.string(),
    reactionDetail: Joi.string().allow(null),
    scheduleStatus: Joi.string().valid(
      ...Object.values(enumConfig.scheduleStatusEnums)
    ),
  }),
};

const updateScheduleStatus = {
  body: Joi.object().keys({
    scheduleStatus: Joi.string()
      .valid(...Object.values(enumConfig.scheduleStatusEnums))
      .required(),
  }),
};

export default {
  scheduleVaccine,
  updateSchedule,
  updateScheduleStatus,
};
