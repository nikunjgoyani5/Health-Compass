import Joi from "joi";

const createHealthCheck = {
  body: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().required(),
    prompts: Joi.array().items(
      Joi.object().keys({
        question: Joi.string(),
      })
    ),
  }),
};

const addPrompts = {
  body: Joi.object().keys({
    question: Joi.string().required(),
  }),
};

const updateData = {
  body: Joi.object().keys({
    title: Joi.string(),
    description: Joi.string(),
    prompts: Joi.array().items(
      Joi.object().keys({
        question: Joi.string(),
      })
    ),
  }),
};

const askQuestion = {
  body: Joi.object().keys({
    prompt: Joi.string().required(),
  }),
};

export default {
  createHealthCheck,
  addPrompts,
  updateData,
  askQuestion,
};
