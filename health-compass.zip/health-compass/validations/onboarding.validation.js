import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const onboardingSchema = {
  body: Joi.object().keys({
    age: Joi.number().strict().required(),
    gender: Joi.string()
      .valid(...Object.values(enumConfig.genderEnums))
      .required(),
    weightKg: Joi.number().strict(),
    heightCm: Joi.number().strict(),
    goal: Joi.string().valid(...Object.values(enumConfig.goalEnums)),
    activityLevel: Joi.string().valid(
      ...Object.values(enumConfig.activityLevelEnums)
    ),
  }),
};

export default {
  onboardingSchema,
};
