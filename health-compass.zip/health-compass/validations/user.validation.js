import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const updateUserProfile = {
  body: Joi.object().keys({
    fullName: Joi.string().min(1).max(100),
    profileImage: Joi.string().allow(null, ""),
    phoneNumber: Joi.string(),
    gender: Joi.string()
      .valid(...Object.values(enumConfig.genderEnums))
      .allow(null, ""),
  }),
};

const updateRole = {
  body: Joi.object().keys({
    role: Joi.string().valid(...Object.values(enumConfig.userRoleEnum)),
  }),
};

const deleteUserAccountValidation = {
  body: Joi.object().keys({
    isPermanentlyDelete: Joi.boolean().required(),
  }),
};

const changePassword = {
  body: Joi.object().keys({
    oldPassword: Joi.string().required(),
    newPassword: Joi.string().required(),
    conformNewPassword: Joi.string().valid(Joi.ref("newPassword")).required(),
  }),
};

const verify2faOtp = {
  body: Joi.object().keys({
    otp: Joi.number().strict().required(),
  }),
};

const updateUserFCMToken = {
  body: Joi.object().keys({
    fcmToken: Joi.string().required(),
  }),
};

const blockAndUnblockUser = {
  body: Joi.object().keys({
    isBlocked: Joi.boolean().required(),
  }),
};

const updateUserActiveStatus = {
  body: Joi.object().keys({
    is_active: Joi.boolean().required(),
  }),
};

const approveAndRejectValidation = {
  body: Joi.object().keys({
    registerAdminId: Joi.string().required(),
    status: Joi.string()
      .valid(...Object.values(enumConfig.superadminApproveStatusEnum))
      .required(),
  }),
};

const blockAndUnblockAdminValidation = {
  body: Joi.object().keys({
    adminId: Joi.string().required(),
    isBlocked: Joi.boolean().required(),
    blockedBy: Joi.string(),
  }),
};

const notificationPreferencesValidation = {
  body: Joi.object({
    preferences: Joi.object({
      medications: Joi.object({
        push: Joi.boolean().required(),
        email: Joi.boolean().required(),
        sms: Joi.boolean().required(),
      }).required(),
      waterIntake: Joi.object({
        push: Joi.boolean().required(),
        email: Joi.boolean().required(),
        sms: Joi.boolean().required(),
      }).required(),
      exercise: Joi.object({
        push: Joi.boolean().required(),
        email: Joi.boolean().required(),
        sms: Joi.boolean().required(),
      }).required(),
      other: Joi.object({
        push: Joi.boolean().required(),
        email: Joi.boolean().required(),
        sms: Joi.boolean().required(),
      }).required(),
    }).required(),
    reminderFrequency: Joi.string()
      .valid(...Object.values(enumConfig.notificationFrequencyEnum))
      .required(),
  }),
};

const setPasswordValidation = {
  body: Joi.object({
    password: Joi.string().required(),
    confirmPassword: Joi.string().valid(Joi.ref("password")).required(),
  }),
};

const assignRoleToUser = {
  body: Joi.object({
    userId: Joi.string().required(),
    role: Joi.string()
      .valid(...Object.values({ USER: "user", DOCTOR: "doctor" }))
      .required(),
  }),
};

const removeRoleFromUser = {
  body: Joi.object({
    userId: Joi.string().required(),
    role: Joi.string()
      .valid(...Object.values({ USER: "user", DOCTOR: "doctor" }))
      .required(),
  }),
};

export default {
  updateUserProfile,
  deleteUserAccountValidation,
  changePassword,
  updateRole,
  verify2faOtp,
  updateUserFCMToken,
  blockAndUnblockUser,
  updateUserActiveStatus,
  approveAndRejectValidation,
  blockAndUnblockAdminValidation,
  setPasswordValidation,
  assignRoleToUser,
  removeRoleFromUser,
  notificationPreferencesValidation,
  setPasswordValidation,
};
