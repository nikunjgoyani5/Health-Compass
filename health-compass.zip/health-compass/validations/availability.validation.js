import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const updateAvailability = {
  body: Joi.object().keys({
    availability: Joi.array().items(
      Joi.object().keys({
        day: Joi.string()
          .valid(...Object.values(enumConfig.doctorAvailabilityEnums))
          .required(),
        shift: Joi.array()
          .items(
            Joi.object().keys({
              startTime: Joi.string().required(),
              endTime: Joi.string().required(),
            })
          )
          .required(),
      })
    ),
  }),
};

export default {
  updateAvailability,
};
