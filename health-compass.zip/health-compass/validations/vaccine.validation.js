import Joi from "joi";

const createVaccine = {
  body: Joi.object().keys({
    vaccineName: Joi.string().required(),
    provider: Joi.string().required(),
    description: Joi.string().optional(),
  }),
};

const updateVaccine = {
  body: Joi.object().keys({
    vaccineName: Joi.string(),
    description: Joi.string(),
    provider: Joi.string(),
  }),
};

export default {
  createVaccine,
  updateVaccine,
};
