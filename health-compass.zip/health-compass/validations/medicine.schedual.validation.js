import Joi from "joi";
import enumConfig from "../config/enum.config.js";

const createMedicineSchedule = {
  body: Joi.object().keys({
    userId: Joi.string(),
    medicineName: Joi.string().required(),
    quantity: Joi.number().required(),
    startDate: Joi.date().required(),
    endDate: Joi.date().required(),
    doseTimes: Joi.array()
      .items(
        Joi.string().pattern(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]\s?(AM|PM)$/i)
      )
      .min(1)
      .required(),
    totalDosesPerDay: Joi.number().required(),
  }),
};

const updateDoseStatus = {
  body: Joi.object().keys({
    date: Joi.date().required(),
    time: Joi.string().required(),
    status: Joi.string()
      .valid(...Object.values(enumConfig.scheduleStatusEnums))
      .required(),
  }),
};

const addMedicineQuantity = {
  body: Joi.object().keys({
    quantity: Joi.number().strict().required(),
  }),
};

const updateStatus = {
  body: Joi.object().keys({
    status: Joi.string()
      .valid(...Object.values(enumConfig.medicineScheduleStatus))
      .required(),
  }),
};

export default {
  createMedicineSchedule,
  updateDoseStatus,
  addMedicineQuantity,
  updateStatus,
};
