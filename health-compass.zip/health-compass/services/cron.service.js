import cron from "node-cron";
import { updateMissedAppointmentByDoctor } from "./telemedicine.service.js";
import {
  sendDoseReminderNotifications,
  updateMissedMedicineDoses,
} from "./medicine.schedual.service.js";
import { autoSubmitExpiredQuizzes } from "./quiz.service.js";
import {
  checkAndUpdateMissedVaccineSchedules,
  sendVaccineScheduleReminder,
} from "./vaccine.service.js";

// Schedule the job to run every 1 minute
cron.schedule("*/1 * * * *", async () => {
  console.log("⏰ Cron job running...");
  const start = Date.now();
  await updateMissedAppointmentByDoctor();
  await sendDoseReminderNotifications();
  await updateMissedMedicineDoses();
  await autoSubmitExpiredQuizzes();
  await checkAndUpdateMissedVaccineSchedules();
  await sendVaccineScheduleReminder();

  console.log(">>>>>> Cron finished in", Date.now() - start, "ms");
});
