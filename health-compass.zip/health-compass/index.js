import express from "express";
import cors from "cors";
import config from "./config/config.js";
import connectDB from "./config/db.config.js";
import morgan from "morgan";
import http from "http";
import errorHandler from "./middleware/error-handler.middleware.js";
import router from "./router.js";
import initializeSocket from "./socket/socket.io.js";
import "./services/cron.service.js";

const app = express();
const server = http.createServer(app);

app.disable("x-powered-by");

// connect database
connectDB();

// middleware
app.use(morgan("dev"));
app.use(express.json());
app.use(cors({ origin: "*" }));

app.get("/", (req, res) => {
  res.send("Health Compass development server is running test");
});

// Users Routes
app.use("/api/v1/auth", router.authRoute);
app.use("/api/v1/user", router.userRoute);
app.use("/api/v1/medicine-schedule", router.medicineSchedualRoute);
app.use("/api/v1/quiz", router.quizRoute);
app.use("/api/v1/question", router.questionRoute);
app.use("/api/v1/quiz-start", router.resultRoute);
app.use("/api/v1/content-hub", router.contenthubRoute);
app.use("/api/v1/vaccine", router.vaccineRoute);
app.use("/api/v1/vaccine-schedule", router.vaccineScheduleRoute);
app.use("/api/v1/doctor", router.doctorRoute);
app.use("/api/v1/availability", router.availabilityRoute);
app.use("/api/v1/caregiver", router.caregiverRoute);
app.use("/api/v1/caregiver-notes", router.caregivernotesRoute);
app.use("/api/v1/telemedicine", router.telemedicineRoute);
app.use("/api/v1/supplement", router.supplementRoute);
app.use("/api/v1/bot", router.healthBotRoute);
// app.use("/api/v1/request", router.requestRoute);
app.use("/api/v1/notifications", router.notificationRoute);
app.use("/api/v1/onboarding", router.onboardingRoute);
app.use("/api/v1/static-bot", router.staticBotRoute);
app.use("/api/v1/support", router.supportRoute);
app.use("/api/v1/dashboard", router.dashboardRoute);
app.use("/api/v1/user-activity", router.userActivityRoute);
app.use("/api/v1/feedback", router.feedbackRoute);
app.use("/api/v1/health-goal", router.healthGoalRoute);
app.use("/api/v1/privacy-and-data", router.privacyAndDataRoute);
app.use("/api/v1/medicine-usage", router.medicineUsageRoute);
app.use("/api/v1/health-score", router.healthScoreRoute);

// Admin Routes
app.use("/api/v1/admin", router.adminRoute);
app.use("/api/v1/superadmin", router.superadminRoute);

// Initialize Socket.IO
initializeSocket(server);

// error handler
app.use(errorHandler);

// start server
server.listen(config.port, () => {
  console.log(`Server is running on port http://localhost:${config.port}`);
});

// uncaught exceptions and unhandled rejections
process.on("uncaughtException", function (err) {
  console.error("Uncaught Exception:", err);
});
process.on("unhandledRejection", function (err) {
  console.error("Unhandled Rejection:", err);
});
