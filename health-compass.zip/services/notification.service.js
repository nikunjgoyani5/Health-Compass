import admin from "../firebase/config.firebase.js";
import Notification from "../models/notification.model.js";

// -------- Send notification using firebase -----------
export const sendFCMNotification = async ({ token, title, message, image }) => {
  try {
    const messagePayload = {
      token,
      notification: { title, body: message, image },
      webpush: {
        headers: { Urgency: "high" },
        notification: { icon: image },
      },
    };

    const response = await admin.messaging().send(messagePayload);
    return { success: true, response };
  } catch (error) {
    console.error("FCM Notification Error:", error);
    return { success: false, message: error.message };
  }
};

export const sendPushNotificationAndSave = async ({
  user,
  message,
  title,
  type,
  image,
}) => {
  await sendFCMNotification({
    token: user?.fcmToken,
    title,
    message,
    image,
  });

  const notificationData = {
    title,
    message,
    type,
    actionUrl: "https://health-compass-60829.web.app/#/dashboard",
    image,
    isRead: false,
    createdAt: new Date(),
  };

  let userNotification = await Notification.findOne({
    userId: user._id || user,
  });

  console.log("Notification sent to user:", user._id);

  if (userNotification) {
    userNotification.notifications.push(notificationData);
    await userNotification.save();
  } else {
    await Notification.create({
      userId: user._id || user,
      notifications: [notificationData],
    });
  }
};
