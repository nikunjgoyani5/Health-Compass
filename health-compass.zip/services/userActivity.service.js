import activityModel from '../models/userActivity.model.js';
import UserModel from '../models/user.model.js';
import helper from '../helper/common.helper.js';
import moment from 'moment';

const createActivity = async (data) => {
    try {
        let {
            userId,
            email,
            category,
            activityType,
            description,
            activityData,
            status = false,
            error,
            errorMessage
        } = data;

        // Ensure userId from email or ID
        userId = await helper.ensureUserId(userId, email);
        const user = await UserModel.findById(userId);
        if (!user) throw new Error("User not found");

        email = email || user.email;

        // Get current local time in ISO 8601 format with timezone offset
        const currentTime = moment().format("YYYY-MM-DDTHH:mm:ss.SSSZ");

        // Create the activity entry
        const activityEntry = {
            activityType,
            description,
            activityData,
            status,
            error,
            errorMessage,
            createdAt: currentTime
        };

        // Find existing user activity doc
        let userActivity = await activityModel.findOne({ userId });

        if (!userActivity) {
            // New user, create document
            userActivity = new activityModel({
                userId,
                email,
                activities: new Map([[category, [activityEntry]]]),
                lastLogin: activityType === "login" ? currentTime : undefined
            });
        } else {
            // Existing user, update
            if (!userActivity.activities.has(category)) {
                userActivity.activities.set(category, []);
            }

            userActivity.activities.get(category).push(activityEntry);
            userActivity.markModified('activities');

            if (activityType === "login") {
                userActivity.lastLogin = currentTime;
            }
        }

        await userActivity.save();
        return userActivity;
    } catch (error) {
        console.error("Error creating activity:", error.message);
        try {
            const fallbackTime = moment().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
            await activityModel.create({
                userId: "System",
                email: "System",
                activities: new Map([[ 
                    "system", 
                    [{
                        activityType: "System Error",
                        description: "Failed to log activity",
                        status: false,
                        error: error.message,
                        createdAt: fallbackTime
                    }]
                ]])
            });
        } catch (finalError) {
            console.error("Failed to log system error activity:", finalError.message);
        }
    }
};

const getActivityByUserId = async (userId) => {
    return await activityModel.find({ userId });
}

const getActivityByCategory = async (userId, category) => {
    return await activityModel.findOne(
        { userId, [`activities.${category}`]: { $exists: true } },
        { [`activities.${category}`]: 1, _id: 0 }
    );
};

export default {
    createActivity,
    getActivityByUserId,
    getActivityByCategory
};
