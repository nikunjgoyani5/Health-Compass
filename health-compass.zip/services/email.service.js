import config from "../config/config.js";
import fs from "fs";
import path from "path";
import nodemailer from "nodemailer";
import dayjs from "dayjs";

const sendEmail = async ({
  from = config.email.from,
  to,
  subject,
  templateVariables,
  filename,
}) => {
  try {
    // Read html template
    let html = fs.readFileSync(
      path.join(process.cwd(), "html-templates", filename),
      "utf-8"
    );

    // Replace template variables with their values
    Object.keys(templateVariables).forEach((key) => {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, "g");
      html = html.replace(regex, templateVariables[key]);
    });

    // create transporter
    const mailTransport = nodemailer.createTransport({
      host: config.nodemailer.host,
      port: config.nodemailer.port,
      secure: false,
      auth: {
        user: config.nodemailer.auth.user,
        pass: config.nodemailer.auth.pass,
      },
    });

    // Send email
    const result = mailTransport.sendMail(
      {
        from: from,
        to,
        subject,
        html,
      },
      async (error, info) => {
        if (error) {
          return error;
        } else {
          console.log(`Email successfully sent to ${info.accepted.join(", ")}`);
          return info;
        }
      }
    );

    return result;
  } catch (error) {
    console.log(error);
  }
};

const sendOTPEmail = async ({ email, otp, otpExpiresAt, fullName }) => {
  return sendEmail({
    to: email,
    subject: "OTP verification",
    templateVariables: {
      otp: otp,
      otpExpiresAt: otpExpiresAt,
      fullName: fullName,
      year: dayjs().format("YYYY"),
    },
    filename: "verifyOTP.html",
  });
};

const sendDoctorCredentialsEmail = async ({ email, fullName, password }) => {
  return sendEmail({
    to: email,
    subject: "Doctor Account Created – Login Credentials",
    templateVariables: {
      email,
      fullName,
      password,
      year: dayjs().format("YYYY"),
    },
    filename: "doctorCredentials.html",
  });
};

const sendCaregiverCredentialsEmail = async ({ email, fullName, password }) => {
  return sendEmail({
    to: email,
    subject: "Caregiver Account Created – Login Credentials",
    templateVariables: {
      email,
      fullName,
      password,
      year: dayjs().format("YYYY"),
    },
    filename: "caregiverCredentials.html",
  });
};

const send2FaEmail = async ({ email, username, twofactorqr }) => {
  return sendEmail({
    to: email,
    subject: "Set Up Google Two-Step Authentication for Your VA-BOT Account",
    templateVariables: {
      username,
      twofactorqr,
      year: dayjs().format("YYYY"),
    },
    filename: "qrcode.html",
  });
};

const sendAdminApprovalEmail = async ({ email, fullName }) => {
  return sendEmail({
    to: email,
    subject: "Admin Account Approved",
    templateVariables: {
      email: email,
      fullName,
      year: dayjs().format("YYYY"),
    },
    filename: "admin-approve-email.html",
  });
};

const sendAdminRejectEmail = async ({ email, fullName }) => {
  return sendEmail({
    to: email,
    subject: "Admin Account Rejected",
    templateVariables: {
      email: email,
      fullName,
      year: dayjs().format("YYYY"),
    },
    filename: "admin-reject-email.html",
  });
};

const sendAdminBlockEmail = async ({ email, fullName }) => {
  return sendEmail({
    to: email,
    subject: "Admin Account Blocked",
    templateVariables: {
      email: email,
      fullName,
      year: dayjs().format("YYYY"),
    },
    filename: "admin-block-email.html",
  });
};

const sendAdminUnblockEmail = async ({ email, fullName }) => {
  return sendEmail({
    to: email,
    subject: "Admin Account Unblocked",
    templateVariables: {
      email: email,
      fullName,
      year: dayjs().format("YYYY"),
    },
    filename: "admin-unblock-email.html",
  });
};

const cancelledAppointmentByDoctorEmail = async ({
  email,
  fullName,
  doctorName,
  appointmentDate,
  appointmentTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Appointment Cancelled",
    templateVariables: {
      fullName,
      doctorName,
      appointmentDate,
      appointmentTime,
      year: dayjs().format("YYYY"),
    },
    filename: "cancelled-appointment-by-doctor-email.html",
  });
};

const missedMedicineAlertEmail = async ({
  email,
  fullName,
  medicineName,
  scheduledTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Missed Medicine Alert 🚨",
    templateVariables: {
      fullName,
      medicineName,
      scheduledTime,
      date: dayjs().format("DD/MM/YYYY"),
      year: dayjs().format("YYYY"),
    },
    filename: "missed-medicine-alert-email.html",
  });
};

const medicineReminderEmail = async ({
  email,
  fullName,
  medicineName,
  scheduledTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Medicine Reminder ⏰",
    templateVariables: {
      fullName,
      medicineName,
      scheduledTime,
      date: dayjs().format("DD/MM/YYYY"),
      year: dayjs().format("YYYY"),
    },
    filename: "medicine-reminder-email.html",
  });
};

const sendMissedAppointmentByDoctorEmail = async ({
  email,
  fullName,
  doctorName,
  appointmentDate,
  appointmentTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Missed Appointment Notification",
    templateVariables: {
      fullName,
      doctorName,
      appointmentDate: dayjs(appointmentDate).format("DD/MM/YYYY"),
      appointmentTime,
      year: dayjs().format("YYYY"),
    },
    filename: "appointment-missed-by-doctor-email.html",
  });
};

const missedVaccineScheduleEmail = async ({
  email,
  fullName,
  vaccineName,
  scheduledTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Missed Vaccine Dose Alert 🚨",
    templateVariables: {
      fullName,
      vaccineName,
      scheduledTime,
      date: dayjs().format("DD/MM/YYYY"),
      year: dayjs().format("YYYY"),
    },
    filename: "missed-vaccine-schedule-email.html",
  });
};

const vaccineReminderEmail = async ({
  email,
  fullName,
  vaccineName,
  scheduledTime,
}) => {
  return sendEmail({
    to: email,
    subject: "Vaccine Reminder ⏰",
    templateVariables: {
      fullName,
      vaccineName,
      scheduledTime,
      scheduledDate: dayjs().format("DD/MM/YYYY"),
      year: dayjs().format("YYYY"),
    },
    filename: "vaccine-reminder-email.html",
  });
};

export default {
  sendOTPEmail,
  sendEmail,
  sendDoctorCredentialsEmail,
  sendCaregiverCredentialsEmail,
  send2FaEmail,
  sendAdminApprovalEmail,
  sendAdminRejectEmail,
  sendAdminBlockEmail,
  sendAdminUnblockEmail,
  cancelledAppointmentByDoctorEmail,
  missedMedicineAlertEmail,
  medicineReminderEmail,
  sendMissedAppointmentByDoctorEmail,
  missedVaccineScheduleEmail,
  vaccineReminderEmail,
};
